"use strict";
/* タスク表の並べ替え・フィルター (Excel 風)。保存される行の順番は変えない。
   フィルター: 列ごとに {vals: チェックした値 | null, conds: [{op, v}], join: "and" | "or"}。列どうしは AND。
   並べ替え: [{id, dir}] の順に比べる (並べ替え条件ダイアログ・見出しクリック・▾ メニューは同じ状態を見る)。
   見出しクリックは今のレベルを置き換えない: 無い列は最後のレベルに追加 (昇順)、ある列はその位置のまま昇順⇔降順。
   ただし既定の並び (No. 昇順、ユーザーが決めていない) だけのときは、クリックした列に置き換える。
   保存した条件 (プリセット) は読み込むと作業中の条件に写すだけ。あとの変更は作業中だけで、保存は「上書き保存」「別名で保存」のときだけ */
window.TF = (() => {
  const DEFAULT_SORT = () => [{ id: "no", dir: 1 }];  // 既定の表示順は No. の昇順 (行そのものの順番は変えない)
  const F = { filters: {}, sort: DEFAULT_SORT(), sortDefault: true, pinned: new Set(), drop: null, preset: null, tabs: [], range: { mode: "auto", from: "", to: "" }, tree: [], recur: [] };  // recur = 開いた定期グループのコード (既定は閉じる)  // preset = 見ているタブ {name, base}。tabs = 開いているタブ [{name, snap, base}] (snap = 離れたときの作業中の条件)
  const isDefaultSort = () => F.sortDefault;
  const setUserSort = levels => {  // 空になったら既定 (No. 昇順) に戻す
    F.sortDefault = !levels.length;
    F.sort = levels.length ? levels : DEFAULT_SORT();
  };
  const cols = () => SPECS.tasksAll;
  const colId = c => c.k || c.id;
  const colBy = id => cols().find(c => colId(c) === id);
  const kindOf = c => (c.calc || ["int", "number", "percent"].includes(c.type) ? "num" : c.type === "date" ? "date" : c.o ? "list" : "text");
  const valOf = (r, c) => String(c.calc ? c.calc(r) : r[c.k] ?? "");
  const numOf = (v, c) => { const x = String(v).replace(/,/g, ""); return x === "" ? (c.k === "progress" ? 0 : null) : isNaN(+x) ? null : +x; };  // 進捗の空欄は 0。1,234.50 も数値
  const BLANK = "（空欄）";
  const labelOf = (c, v) => (!v ? BLANK : c.o ? c.o().find(([x]) => x === v)?.[1] ?? `${v}（定義外）` : v);

  /* ---------- 条件 ---------- */
  const OPS = {
    text: [["contains", "含む"], ["ncontains", "含まない"], ["eq", "等しい"], ["ne", "等しくない"], ["starts", "で始まる"], ["ends", "で終わる"], ["blank", "空欄"], ["nonblank", "空欄以外"]],
    cmp: [["ge", "≥"], ["le", "≤"], ["gt", ">"], ["lt", "<"], ["eq", "="], ["ne", "≠"], ["blank", "空欄"], ["nonblank", "空欄以外"]],
  };
  const opsOf = c => (["num", "date"].includes(kindOf(c)) ? OPS.cmp : OPS.text);
  const opLabel = (c, op) => opsOf(c).find(([o]) => o === op)?.[1] ?? op;
  const noValue = op => op === "blank" || op === "nonblank";
  const CMP = { ge: d => d >= 0, le: d => d <= 0, gt: d => d > 0, lt: d => d < 0, eq: d => d === 0, ne: d => d !== 0 };
  const TEXT = { contains: (s, q) => s.includes(q), ncontains: (s, q) => !s.includes(q), eq: (s, q) => s === q, ne: (s, q) => s !== q,
    starts: (s, q) => s.startsWith(q), ends: (s, q) => s.endsWith(q) };
  const test = (c, { op, v }, raw) => {
    if (noValue(op)) return (raw === "") === (op === "blank");
    const k = kindOf(c);
    if (k === "num") { const n = numOf(raw, c); return n !== null && CMP[op](n - +v); }
    if (k === "date") return raw !== "" && CMP[op](raw.localeCompare(v));
    const q = v.toLowerCase(), texts = k === "list" ? [raw, labelOf(c, raw)] : [raw];  // コードは名前でも探せる (表示は名前だけ。コードでも探せる)
    const neg = { ne: "eq", ncontains: "contains" }[op], hit = texts.some(t => TEXT[neg || op](t.toLowerCase(), q));
    return neg ? !hit : hit;
  };
  const pass = (c, f, raw, vs) => (!f.vals || (vs ? vs.has(raw) : f.vals.includes(raw))) &&
    (!f.conds?.length || (f.join === "or" ? f.conds.some(x => test(c, x, raw)) : f.conds.every(x => test(c, x, raw))));
  /* 絞り込みの準備 (1 回の表示につき 1 回): 列を探す・選んだ値の Set・マスタの選択肢 (c.o()) を覚えておく */
  const memoO = c => (c.o ? { ...c, o: (list => () => list)(c.o()) } : c);
  const prepFilters = except => Object.entries(F.filters).filter(([id]) => id !== except && colBy(id)).map(([id, f]) => { const c = colBy(id); return [memoO(c), f, f.vals && new Set(f.vals), c]; });
  const passes = (r, except, P = prepFilters(except)) => P.every(([c, f, vs, c0]) => pass(c, f, valOf(r, c0), vs));
  const cmp = (a, b, c) => {
    const [x, y] = [valOf(a, c), valOf(b, c)];
    if (!x || !y) return !x && !y ? 0 : !x ? 1 : -1;  // 空欄は常に最後
    if (c.type?.startsWith("code:")) {  // マスタの列はマスタの並び順で比べる (コードの文字順ではない)
      const order = c.o().map(([v]) => v), rank = v => (order.includes(v) ? order.indexOf(v) : 1e9);
      return rank(x) - rank(y) || x.localeCompare(y, "ja");
    }
    return kindOf(c) === "num" ? numOf(x, c) - numOf(y, c) : x.localeCompare(y, "ja");
  };
  /* 並べ替え: 行ごとのキーを先に 1 回だけ作ってから比べる (比べるたびに値・マスタの順を探さない)。結果は cmp と同じ順 */
  const COLL = new Intl.Collator("ja");
  const sorted = (rows, all, ov) => {  // ov = {sort} を渡すと、画面の条件ではなく保存した条件の並べ替えで並べる (画面は書き換えない。足した行の直後への寄せもしない)
    const sort = ov ? (ov.sort?.length ? ov.sort : DEFAULT_SORT()) : F.sort;
    const keys = sort.map(s => [s, colBy(s.id)]).filter(([, c]) => c);
    if (!keys.length) return rows;
    const idx = new Map(all.map((r, i) => [r, i]));
    const ext = keys.map(([s, c]) => ({ dir: s.dir, c, code: !!c.type?.startsWith("code:"), num: kindOf(c) === "num", order: c.type?.startsWith("code:") ? new Map(c.o().map(([v], i) => [v, i])) : null }));
    const keyOf = (e, x) => (!x ? null : e.code ? [e.order.has(x) ? e.order.get(x) : 1e9, x] : e.num ? numOf(x, e.c) : x);
    const one = (e, x, y) => {
      if (x === null || y === null) return x === null && y === null ? 0 : x === null ? 1 : -1;  // 空欄は常に最後
      return e.code ? x[0] - y[0] || COLL.compare(x[1], y[1]) : e.num ? x - y : COLL.compare(x, y);
    };
    const out = rows.map(r => ({ r, i: idx.get(r), k: ext.map(e => keyOf(e, valOf(r, e.c))) }))
      .sort((a, b) => ext.reduce((acc, e, j) => acc || e.dir * one(e, a.k[j], b.k[j]), 0) || a.i - b.i).map(x => x.r);
    return !ov && F.sortDefault ? placeAfter(out) : out;  // 既定の並び (利用者が決めていない) のときだけ、足した行を基準の行の直後に置く
  };
  /* 行の追加で足した行 → 直前の行 (基準の行、または直前に足した行)。画面の中だけの覚え (CSV には書かない)。足した順に Map へ入れるので連続追加は順に連なる。
     直前の行が表示に無い (削除・絞り込み) ときは普通の並べ替えの位置のまま */
  const AFT = new Map();
  const placeAfter = out => {
    if (!AFT.size) return out;
    const res = [...out];
    AFT.forEach((p, r) => {
      const i = res.indexOf(r), j = res.indexOf(p);
      i >= 0 && j >= 0 && (res.splice(i, 1), res.splice(res.indexOf(p) + 1, 0, r));
    });
    return res;
  };
  const afterSet = (r, prev) => AFT.set(r, prev);
  /* 行オブジェクトが作り直されるとき (取り消し・保存後の読み直し) に、No. で引き継ぐ。files = Map(ファイル名 → 行の配列) */
  const afterSnap = files => [...files].flatMap(([f, rows]) => rows.filter(r => AFT.has(r)).map(r => ({ f, no: r.no, prev: AFT.get(r).no, r })))
    .map(x => (AFT.delete(x.r), x));
  const afterRestore = (snap, files) => snap.forEach(({ f, no, prev }) => {
    const rows = files.get(f) || [], a = rows.find(r => r.no === no), b = rows.find(r => r.no === prev);
    a && b && AFT.set(a, b);
  });
  let PC = null;  // ガントから 1 行ずつ呼ぶとき: 準備は同じ処理の間 (マイクロタスクまで) 使い回す
  /* 条件のオブジェクトが替わったら作り直す (絞り込みを外した直後に同じ処理の中で描き直しても古い条件を使わない) */
  const cachedP = () => (PC && PC.of === F.filters ? PC.p : ((PC = { of: F.filters, p: prepFilters() }), queueMicrotask(() => (PC = null)), PC.p));
  const apply = rows => { const P = prepFilters(); return sorted(P.length || F.pinned.size ? rows.filter(r => F.pinned.has(r) || passes(r, undefined, P)) : rows, rows); };
  const active = () => Object.keys(F.filters).length > 0 || !isDefaultSort();
  const changed = () => { PC = null; F.pinned.clear(); renderGrid("tasks"); !$("#tab-gantt")?.hidden && window.Gantt?.render(); };  // ガントの一覧表示の ▾ からも使う
  /* 作業中の条件 (保存する形)。フィルターは列の名前順にそろえて比べる */
  /* 保存した条件に入るもの: フィルター・並べ替え・表示期間・表の見た目・ガントの表示・バー表示 (列ごとの bar_*) */
  const BAR_F = ["bar_pos", "bar_order", "bar_max", "bar_title", "bar_short"];
  const barOf = c => ({ bar_pos: c.bar_pos || "none", bar_order: c.bar_order || "", bar_max: c.bar_max || "", bar_title: c.bar_title === "no" ? "no" : "yes", bar_short: c.bar_short || "" });
  const viewState = () => ({ col_order: S.settings.grid_col_order || "", frozen: String(S.settings.grid_frozen || "0"), hidden: S.settings.grid_hidden || "",
    widths: S.settings.grid_widths || "", g_order: S.settings.gantt_col_order || "", g_hidden: S.settings.gantt_hidden || "", g_widths: S.settings.gantt_widths || "", g_flat_order: S.settings.gantt_flat_col_order || "", g_shown: S.settings.gantt_shown || "", g_tree_shown: S.settings.gantt_tree_shown || "",
    g_split_tree: S.settings.gantt_split_tree || "", g_split_flat: S.settings.gantt_split_flat || "", gf_split_tree: S.settings.gf_split_tree || "", gf_split_flat: S.settings.gf_split_flat || "",
    g_frz_tree: S.settings.gantt_frozen_tree || "0", g_frz_flat: S.settings.gantt_frozen_flat || "0", gf_frz_tree: S.settings.gf_frozen_tree || "0", gf_frz_flat: S.settings.gf_frozen_flat || "0",
    bar_layout: S.settings.bar_layout || "" });
  const ganttState = () => ({ zoom: $("#g-zoom").value, project: $("#g-project").value, usefilter: $("#g-usefilter").checked, inazuma: $("#g-inazuma").checked, inazuma_parents: $("#g-inazuma-parents").checked, inazuma_mode: $("#g-inazuma-mode").value,
    deps: $("#g-deps").checked, todayband: $("#g-todayband").checked, chain: $("#gf-scope").value, effort: $("#g-effort").checked, flat: $("#g-flat").checked, gf_flat: $("#gf-flat").checked, group: $("#g-group").value, gsort: $("#g-gsort").value, gf_group: $("#gf-group").value, gf_gsort: $("#gf-gsort").value, inazuma_w: String(S.params?.inazuma_width ?? "") });
  const barState = () => Object.fromEntries((S.data.columns || []).filter(c => c.key).map(c => [c.key, barOf(c)]).sort(([a], [b]) => a.localeCompare(b)));
  const state = () => ({ filters: Object.fromEntries(Object.entries(F.filters).sort(([a], [b]) => a.localeCompare(b))), sort: F.sortDefault ? [] : F.sort, range: F.range,
    view: viewState(), gantt: ganttState(), bars: barState(), tree: F.tree, recur: F.recur });
  /* ---------- ツリーの開閉 (共通条件): 折りたたんだ親のキー。いまのデータに無い道筋は黙って外す (件数だけ知らせる) ---------- */
  const applyTree = (keys, quiet = false) => {
    const kn = treeNodes(openTasks()), want = [...new Set(keys || [])], ok = want.filter(k => kn.has(k)).sort();
    F.tree = ok;
    const v = ok.join("\n");
    v !== (S.settings.gantt_collapsed || "") && ((S.settings.gantt_collapsed = v), putSettings({ gantt_collapsed: v }));  // ツリーの開閉は画面ごと
    want.length > ok.length && !quiet && msg(`ツリーの開閉: いまのデータに無い親 ${want.length - ok.length} 件は無視しました`);
    window.Gantt?.render(); window.GFooter?.refresh(); presetState();
    return want.length - ok.length;  // 外した件数
  };
  const setTree = keys => applyTree(keys, true);
  /* 定期グループの開閉 (共通条件 gantt_recur_open): 開いたコードだけを持つ。いまのデータに無いコードは外す */
  const applyRecur = codes => {
    const have = new Set(openTasks().map(t => String(t.recur_group ?? "").trim()).filter(Boolean));
    F.recur = [...new Set(codes || [])].filter(c => have.has(c)).sort();
    const v = F.recur.join("\n");
    v !== (S.settings.gantt_recur_open || "") && ((S.settings.gantt_recur_open = v), putSettings({ gantt_recur_open: v }));
    window.Gantt?.render(); window.GFooter?.refresh(); presetState();
  };
  const toggleRecur = c => applyRecur(F.recur.includes(c) ? F.recur.filter(x => x !== c) : [...F.recur, c]);
  const recurAll = open => applyRecur(open ? openTasks().map(t => String(t.recur_group ?? "").trim()) : []);
  const toggleTree = k => setTree(F.tree.includes(k) ? F.tree.filter(x => x !== k) : [...F.tree, k]);
  const treeLevel = d => setTree([...treeNodes(openTasks())].filter(([, dd]) => d === "all" || dd === d).map(([k]) => k));  // d 段の親をすべて折りたたむ
  const initTree = st => { F.tree = (st.gantt_collapsed || "").split("\n").filter(Boolean); F.recur = (st.gantt_recur_open || "").split("\n").filter(Boolean); applyTree(F.tree, true); };
  /* 読み込み: プリセットにある部分だけ当てる (古いプリセットに無い部分はいまのまま) */
  const applyView = v => saveView({ grid_col_order: v.col_order ?? S.settings.grid_col_order, grid_frozen: v.frozen ?? S.settings.grid_frozen, grid_hidden: v.hidden ?? S.settings.grid_hidden,
    grid_widths: v.widths ?? S.settings.grid_widths, gantt_col_order: v.g_order ?? S.settings.gantt_col_order, gantt_hidden: v.g_hidden ?? S.settings.gantt_hidden,
    gantt_widths: v.g_widths ?? S.settings.gantt_widths, gantt_flat_col_order: v.g_flat_order ?? S.settings.gantt_flat_col_order, gantt_shown: v.g_shown ?? S.settings.gantt_shown, gantt_tree_shown: v.g_tree_shown ?? S.settings.gantt_tree_shown,
    gantt_split_tree: v.g_split_tree ?? S.settings.gantt_split_tree, gantt_split_flat: v.g_split_flat ?? S.settings.gantt_split_flat, gf_split_tree: v.gf_split_tree ?? S.settings.gf_split_tree, gf_split_flat: v.gf_split_flat ?? S.settings.gf_split_flat,
    gantt_frozen_tree: v.g_frz_tree ?? S.settings.gantt_frozen_tree, gantt_frozen_flat: v.g_frz_flat ?? S.settings.gantt_frozen_flat, gf_frozen_tree: v.gf_frz_tree ?? S.settings.gf_frozen_tree, gf_frozen_flat: v.gf_frz_flat ?? S.settings.gf_frozen_flat, bar_layout: v.bar_layout ?? S.settings.bar_layout });
  const applyGantt = g => {
    const setSel = (s, v) => v !== undefined && [...$(s).options].some(o => o.value === v) && ($(s).value = v);
    const setChk = (s, v) => typeof v === "boolean" && ($(s).checked = v);
    setSel("#g-zoom", g.zoom); setSel("#g-project", g.project); setSel("#gf-scope", g.chain);
    $("#g-inazuma-mode").value = ["task", "chain"].includes(g.inazuma_mode) ? g.inazuma_mode : "task";  // 古いプリセット・不正値は既定 (行ごと)
    setSel("#g-group", g.group); setSel("#g-gsort", g.gsort); setSel("#gf-group", g.gf_group); setSel("#gf-gsort", g.gf_gsort);  // 古いプリセットに無い値は今のまま
    [["#g-usefilter", g.usefilter], ["#g-inazuma", g.inazuma], ["#g-inazuma-parents", g.inazuma_parents], ["#g-deps", g.deps], ["#g-todayband", g.todayband], ["#g-effort", g.effort], ["#g-flat", g.flat], ["#gf-flat", g.gf_flat ?? false]].forEach(([s, v]) => setChk(s, v));  // 古いプリセット・前回の表示に gf_flat が無いときは既定 (オフ)
    applyInz(g.inazuma_w);  // 線の太さ: 画面だけ (params.csv は「パラメータを保存」で)
    const flat = $("#g-flat").checked ? "on" : "off";
    const gf = $("#gf-flat").checked ? "on" : "off";
    const gr = { gantt_group: $("#g-group").value, gantt_gsort: $("#g-gsort").value, gf_group: $("#gf-group").value, gf_gsort: $("#gf-gsort").value };
    (flat !== S.settings.gantt_flat || gf !== S.settings.gf_flat || Object.entries(gr).some(([k, v]) => v !== S.settings[k])) && saveView({ gantt_flat: flat, gf_flat: gf, ...gr });
    const deps = $("#g-deps").checked ? "on" : "off";
    deps !== S.settings.gantt_deps && ((S.settings.gantt_deps = deps), putSettings({ gantt_deps: deps }));
    window.Gantt?.G.reveal.clear(); window.Gantt?.render(); window.GFooter?.refresh();
  };
  /* 画面だけの上書き (保存した条件のバー表示・イナズマ線の太さ)。columns.csv・params.csv は変えず、未保存の編集にもしない (表示の条件だけでページを離れる確認を出さない)。
     前回の表示に残して開き直しても同じにし、保存で読み直したときも当て直す (列定義・パラメータを保存したら、その中身が正) */
  const OV = { bars: {}, inz: null }, SAVED = { bars: {}, inz: "" };
  const applyBars = b => {  // 画面の列定義 (メモリ) に当てる。columns.csv は列定義の「保存」のときだけ変わる
    const hits = (S.data.columns || []).flatMap(c => (b[c.key] && typeof b[c.key] === "object" ? BAR_F.filter(f => typeof b[c.key][f] === "string" && barOf(c)[f] !== b[c.key][f]).map(f => [c, f, b[c.key][f]]) : []));
    hits.forEach(([c, f, v]) => { c[f] = v; const o = { ...OV.bars[c.key] }; v === SAVED.bars[c.key]?.[f] ? delete o[f] : (o[f] = v); OV.bars[c.key] = o; });
    hits.length && renderAll();
  };
  const applyInz = w => { if (typeof w !== "string" || !w) return; OV.inz = w === SAVED.inz ? null : w; w !== String(S.params?.inazuma_width) && (S.params = { ...S.params, inazuma_width: w }); };
  const applyOver = o => { o?.bars && typeof o.bars === "object" && applyBars(o.bars); applyInz(o?.inz); };
  const overState = () => ({ bars: Object.fromEntries(Object.entries(OV.bars).filter(([, o]) => Object.keys(o).length)), inz: OV.inz });
  const resetOver = (bars, inz) => { bars && ((OV.bars = {}), (SAVED.bars = barState())); inz && ((OV.inz = null), (SAVED.inz = String(S.params?.inazuma_width ?? ""))); };
  /* 読み直した直後 (列定義・パラメータはファイルの中身): 中身を覚え直し、保存しなかったほうの上書きを当て直す */
  const reloaded = (saved = []) => {
    const o = { bars: saved.includes("columns") ? {} : OV.bars, inz: saved.includes("params") ? null : OV.inz };
    resetOver(true, true); applyOver(o);
  };
  /* ---------- 初期状態に戻す (表示の条件だけ。presets.json・columns.csv は書かない。Ctrl+Z で 1 回で戻る) ---------- */
  const GANTT0 = { zoom: "28", project: "", usefilter: true, inazuma: true, inazuma_parents: false, inazuma_mode: "task", deps: true, todayband: true, chain: "all", effort: false, flat: false, gf_flat: false, group: "3", gsort: "no", gf_group: "3", gf_gsort: "no" };
  const RESET_ITEMS = [  // [キー, 表示, 既定でチェック, 戻し方]
    ["filters", "絞り込み（フィルター）", true, () => (F.filters = {})],
    ["sort", "並べ替え（No. 順に）", true, () => setUserSort([])],
    ["order", "列の並び（列定義の順に。表とガントの左の表）", true, v => { v.grid_col_order = ""; v.gantt_col_order = ""; v.gantt_flat_col_order = ""; }],
    ["frozen", "列の固定（なし。タスクの表とガントの左の表）", true, v => { v.grid_frozen = "0"; ["gantt_frozen_tree", "gantt_frozen_flat", "gf_frozen_tree", "gf_frozen_flat"].forEach(k => (v[k] = "0")); }],
    ["hidden", "非表示の列（すべて表示。表とガントの左の表）", true, v => { v.grid_hidden = ""; v.gantt_hidden = ""; v.gantt_shown = ""; v.gantt_tree_shown = ""; }],
    ["widths", "列の幅（列定義の幅に）", true, v => { v.grid_widths = ""; v.gantt_widths = ""; }],
    ["split", "表とチャートの仕切り（自動の幅に。上のガントと影響タスクの欄）", true, v => { v.gantt_split_tree = ""; v.gantt_split_flat = ""; v.gf_split_tree = ""; v.gf_split_flat = ""; }],
    ["tree", "ツリーの開閉（すべて展開。定期グループはまとめる）", true, () => { applyTree([], true); applyRecur([]); }],
    ["gantt", "ガント表示（週・表示期間 自動・各表示 オン・プロジェクト すべて・グループ化 中項目まで・グループ内 No.順）", false, () => null],
  ];
  const viewSnap = () => ({ ...structuredClone({ filters: F.filters, sort: F.sort, sortDefault: F.sortDefault, range: F.range }), view: viewState(), gantt: ganttState(), tree: [...F.tree], recur: [...F.recur], preset: F.preset });
  /* 検索条件 (フィルター・ガントのプロジェクトと「表の条件で絞り込む」): 変わったらチェックを全解除する */
  const condKey = () => canon({ filters: F.filters, project: $("#g-project").value, usefilter: $("#g-usefilter").checked });
  const restoreView = s => {
    const k0 = condKey();
    F.filters = s.filters; F.sort = s.sort; F.sortDefault = s.sortDefault;
    applyRange(s.range); applyView(s.view); applyGantt(s.gantt); applyTree(s.tree, true); applyRecur(s.recur || []);
    F.preset = s.preset; condKey() !== k0 && CK.condReset(); changed(); window.Gantt?.render(); presetState();
  };
  const resetView = keys => {
    closeReset();
    if (!keys.length) return;
    S.undo.push({ view: viewSnap() }); S.undo.splice(0, Math.max(0, S.undo.length - 50));
    const v = {}, k0 = condKey();
    RESET_ITEMS.filter(([k]) => keys.includes(k)).forEach(([, , , fn]) => fn(v));
    Object.keys(v).length && saveView(v);
    keys.includes("gantt") && (applyRange(RANGE0), applyGantt(GANTT0));
    F.preset = null;  // 初期状態はプリセットとは別 (選択表示を外す。Ctrl+Z で戻る)
    const ckd = condKey() !== k0 && CK.condReset();
    close(); changed(); window.Gantt?.render(); presetState();
    msg(`初期状態に戻しました: ${RESET_ITEMS.filter(([k]) => keys.includes(k)).map(([, t]) => t.replace(/（.*$/, "")).join("・")}（Ctrl+Z で取り消し）${ckd ? "。検索条件が変わったので選択を解除しました" : ""}`);
  };
  let resetPop = null;
  const closeReset = () => { resetPop?.remove(); resetPop = null; };
  const openReset = btn => {
    if (resetPop) return closeReset();
    const box = ([k, t, on]) => el("label", { class: "rv-item" }, el("input", { type: "checkbox", name: k, checked: on ? "checked" : null }), " ", t);
    resetPop = el("div", { class: "fdrop reset-pop", role: "dialog", "aria-label": "初期状態に戻す" },
      el("div", { class: "fd-title", text: "初期状態に戻す" }),
      el("p", { class: "muted", text: "チェックした表示の条件を初期状態に戻します（全タブ共通）。データ・列定義・保存した条件は変わりません。Ctrl+Z で取り消せます。" }),
      ...RESET_ITEMS.map(box),
      el("div", { class: "fd-row fd-actions" },
        el("button", { type: "button", class: "primary", text: "初期状態に戻す", onclick: () => resetView($$("input:checked", resetPop).map(i => i.name)) }),
        el("button", { type: "button", text: "キャンセル", onclick: closeReset })));
    document.body.append(resetPop);
    const r = btn.getBoundingClientRect();
    Object.assign(resetPop.style, { left: `${clamp(r.left, 8, innerWidth - resetPop.offsetWidth - 8)}px`, top: `${r.bottom + 2}px` });
  };
  document.addEventListener("pointerdown", e => resetPop && !resetPop.contains(e.target) && !e.target.closest(".btn-reset-view") && closeReset(), true);
  document.addEventListener("keydown", e => e.key === "Escape" && closeReset());
  /* ツールチップ用の中身の要約 */
  const describe = p => {
    if (!p) return "";
    const g = p.gantt, v = p.view, r = p.range, bars = Object.entries(p.bars || {}).filter(([, x]) => x.bar_pos && x.bar_pos !== "none");
    const lab = id => colBy(id)?.h || id, ZOOM = { 28: "週", 12: "月", 4: "年" }, onoff = x => (x ? "あり" : "なし");
    return [
      `フィルター: ${Object.keys(p.filters || {}).map(lab).join("、") || "なし"}`,
      `並べ替え: ${(p.sort || []).map(s => `${lab(s.id)}${s.dir > 0 ? "▲" : "▼"}`).join("、") || "No. 順"}`,
      r && `表示期間: ${r.mode === "fixed" ? `固定 ${fmtDate(r.from)}〜${fmtDate(r.to)}` : r.mode === "all" ? "全タスク" : "自動（検索条件）"}`,
      v && `表: 列の並び${v.col_order ? "変更あり" : "既定"}・固定 ${v.frozen || 0} 列・隠した列 ${v.hidden ? v.hidden.split(",").map(lab).join("、") : "なし"}`,
      g && `ガント: ${ZOOM[g.zoom] || g.zoom}表示・プロジェクト ${g.project ? S.data.projects.find(x => x.code === g.project)?.name || g.project : "すべて"}・表の条件で絞り込み ${onoff(g.usefilter)}・イナズマ線 ${onoff(g.inazuma)}${typeof g.inazuma_parents === "boolean" ? `（親にも引く ${onoff(g.inazuma_parents)}）` : ""}${g.inazuma_mode === "chain" ? "（点をつなぐ）" : ""}・影響線 ${onoff(g.deps)}・今日の帯 ${onoff(g.todayband)}・影響タスク欄 ${g.chain === "direct" ? "直接のみ" : "すべての連鎖"}${typeof g.gf_flat === "boolean" ? `（一覧表示 ${onoff(g.gf_flat)}）` : ""}${typeof g.effort === "boolean" ? `・工数・金額 ${onoff(g.effort)}` : ""}`,
      p.bars && `バー表示: ${bars.map(([k, x]) => `${lab(k)}=${Gantt.BAR_POS_JA[x.bar_pos] || x.bar_pos}`).join("、") || "なし"}`,
      Array.isArray(p.tree) && `ツリー: ${p.tree.length ? `折りたたみ ${p.tree.length} か所（${p.tree.map(k => k.split(TREE_SEP).at(-1)).slice(0, 5).join("、")}${p.tree.length > 5 ? "…" : ""}）` : "すべて展開"}`,
      !p.view && "（古い形式: フィルター・並べ替えだけ。ほかはいまの表示のまま）",
    ].filter(Boolean).join("\n");
  };
  /* 比べる形: キーの順をそろえた JSON (サーバーの JSON はキーを名前順に並べ替える。前回の表示から戻した形とも同じに) */
  const canon = v => JSON.stringify(v, (k, x) => (x && typeof x === "object" && !Array.isArray(x) ? Object.fromEntries(Object.entries(x).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))) : x));
  const modified = () => !!F.preset && canon(state()) !== F.preset.base;

  /* ---------- 見出し ---------- */
  const th = (c, j) => {
    const id = colId(c), si = F.sort.findIndex(s => s.id === id), s = F.sort[si];
    return el("th", { "data-j": j, "data-col": id, class: ["fth", F.filters[id] && "filtered", s && "sorted", s && F.sortDefault && "sort-default"].filter(Boolean).join(" "),
      title: s ? `並べ替え ${F.sortDefault ? "（既定）" : `レベル ${si + 1}`}: クリックで昇順⇔降順（レベルはそのまま）` : "クリックで並べ替えの最後のレベルに追加（昇順）" },
      el("span", { class: "th-l", text: c.h }),
      s && el("span", { class: "th-s", title: F.sortDefault ? "既定の並び（No. 昇順）" : `レベル ${si + 1}`, text: (s.dir > 0 ? "▲" : "▼") + (F.sortDefault ? "" : si + 1) }),
      el("button", { class: `fbtn${F.filters[id] ? " on" : ""}`, "data-fcol": id, title: "並べ替え・フィルター", text: "▾" }),
      el("span", { class: "col-rs", "data-rs": id, title: "ドラッグで幅を変更（ダブルクリックで既定の幅）" }));
  };
  /* 見出しクリック (Shift の有無は同じ): ある列 → その位置で向きを反転、無い列 → 最後に追加。既定だけなら置き換え */
  const toggleSort = id => {
    const cur = F.sort.find(s => s.id === id);
    setUserSort(cur ? F.sort.map(s => (s.id === id ? { id, dir: -s.dir } : s)) : F.sortDefault ? [{ id, dir: 1 }] : [...F.sort, { id, dir: 1 }]);
    changed();
  };
  /* ▾ メニュー: 昇順・降順はその列の向きを決める (無ければ追加・既定だけなら置き換え)。0 はこの列だけ外す */
  const setSort = (id, dir) => {
    const has = F.sort.some(s => s.id === id), base = F.sortDefault ? [] : F.sort;
    setUserSort(!dir ? base.filter(s => s.id !== id) : has && !F.sortDefault ? F.sort.map(s => (s.id === id ? { id, dir } : s)) : [...base.filter(s => s.id !== id), { id, dir }]);
  };
  /* 表示期間 (ガントの横軸): 共通条件。設定に残し、プリセットにも入る */
  const RANGE0 = { mode: "auto", from: "", to: "" };
  const applyRange = r => {
    F.range = { ...RANGE0, ...r };
    const s = { gantt_span: F.range.mode, gantt_span_from: F.range.from, gantt_span_to: F.range.to };
    Object.assign(S.settings, s); putSettings(s);  // 表示期間は画面ごと
    window.SpanCtl?.sync(); window.Gantt?.render();
  };
  const setRange = r => { applyRange(r); presetState(); };
  const initRange = st => { F.range = { mode: st.gantt_span || "auto", from: st.gantt_span_from || "", to: st.gantt_span_to || "" }; window.SpanCtl?.sync(); };
  const clearAll = () => { Object.keys(F.filters).length && CK.condReset(); F.filters = {}; setUserSort([]); close(); changed(); };  // 解除すると No. 順に戻る
  const clearFilters = () => { Object.keys(F.filters).length && CK.condReset(); F.filters = {}; close(); changed(); };  // 絞り込みだけ外す (並べ替えはそのまま)
  const clearSort = () => { setUserSort([]); close(); changed(); };  // 並べ替えだけ外す (No. 順。フィルターはそのまま)
  const pin = r => active() && F.pinned.add(r);

  /* ---------- チップ (適用中の条件。× で外す・クリックで編集) ---------- */
  const fmtV = (c, v) => (kindOf(c) === "date" ? fmtDate(v) : v);
  const condText = (c, x) => (noValue(x.op) ? opLabel(c, x.op) : kindOf(c) === "num" || kindOf(c) === "date" ? `${opLabel(c, x.op)} ${fmtV(c, x.v)}` : `「${x.v}」${opLabel(c, x.op)}`);
  const chipsOf = (id, f) => {
    const c = colBy(id);
    if (!c) return [];
    const vals = f.vals && [{ text: `${c.h}: ${f.vals.slice(0, 3).map(v => labelOf(c, v)).join(", ")}${f.vals.length > 3 ? ` 他${f.vals.length - 3}件` : ""}${f.vals.length ? "" : "（なし）"}`,
      drop: g => ({ ...g, vals: null }) }];
    const conds = !f.conds?.length ? [] : f.join === "or"
      ? [{ text: `${c.h}: ${f.conds.map(x => condText(c, x)).join(" または ")}`, drop: g => ({ ...g, conds: [] }) }]
      : f.conds.map((x, k) => ({ text: `${c.h} ${condText(c, x)}`, drop: g => ({ ...g, conds: g.conds.filter((_, n) => n !== k) }) }));
    return [...(vals || []), ...conds].map(ch => ({ ...ch, id }));
  };
  const removeChip = ch => {
    const g = ch.drop(F.filters[ch.id]);
    (g.vals || g.conds?.length) ? (F.filters[ch.id] = g) : delete F.filters[ch.id];
    CK.condReset(); changed();
  };
  const renderChips = () => {
    const sortChip = F.sort.length && !isDefaultSort() && el("span", { class: "chip sort" },
      el("button", { class: "chip-t", text: `並べ替え: ${F.sort.filter(s => colBy(s.id)).map((s, k) => `${k + 1}.${colBy(s.id).h}${s.dir > 0 ? "▲" : "▼"}`).join(" → ")}`, onclick: openSortDialog }),
      el("button", { class: "chip-x", title: "並べ替えを解除（No. 順に戻す）", text: "×", onclick: () => { setUserSort([]); changed(); } }));
    const chips = Object.entries(F.filters).flatMap(([id, f]) => chipsOf(id, f)).map(ch => el("span", { class: "chip", "data-col": ch.id },
      el("button", { class: "chip-t", text: ch.text, title: "クリックで条件を編集", onclick: () => open(ch.id, $(`#grid-tasks th[data-col="${CSS.escape(ch.id)}"] .fbtn`)) }),
      el("button", { class: "chip-x", title: "この条件を外す", text: "×", onclick: () => removeChip(ch) })));
    $("#filter-chips").replaceChildren(...[sortChip, ...chips].filter(Boolean));
    $("#filter-chips").hidden = !sortChip && !chips.length;
    presetState();
  };

  /* ---------- ドロップダウン (列ごと) ---------- */
  const valueList = c => {
    const P0 = prepFilters(colId(c)), base = S.data.tasks.filter(r => passes(r, colId(c), P0));  // ほかの列の条件で絞った行から候補を作る
    const counts = base.map(r => valOf(r, c)).reduce((m, v) => m.set(v, (m.get(v) || 0) + 1), new Map());
    const order = c.o ? c.o().map(([v]) => v) : [];
    const rank = v => (order.indexOf(v) + 1 || 1e9);
    return [...counts.entries()].sort(([a], [b]) => (!a) - (!b) || rank(a) - rank(b) || a.localeCompare(b, "ja"));
  };
  const listUI = (c, f) => {
    const box = el("div", { class: "fd-list" }, ...valueList(c).map(([v, n]) => el("label", { class: "fd-item", "data-label": labelOf(c, v).toLowerCase() },
      el("input", { type: "checkbox", value: v, checked: !f?.vals || f.vals.includes(v) ? "checked" : null }), ` ${labelOf(c, v)} `, el("span", { class: "muted", text: `(${n})` }))));
    const search = el("input", { type: "search", class: "fd-search", placeholder: "一覧から探す" });
    search.addEventListener("input", () => $$(".fd-item", box).forEach(l => (l.hidden = !l.dataset.label.includes(search.value.trim().toLowerCase()))));
    const setAll = on => () => $$(".fd-item:not([hidden]) input", box).forEach(i => (i.checked = on));
    return [el("div", { class: "fd-sub", text: "値の一覧" }), search,
      el("div", { class: "fd-row" }, el("button", { type: "button", text: "全選択", onclick: setAll(true) }), el("button", { type: "button", text: "解除", onclick: setAll(false) })), box];
  };
  const condRow = (c, x = {}) => {
    const ops = opsOf(c), op = x.op || ops[0][0];
    const inp = el("input", { class: "fd-v", value: fmtV(c, x.v ?? ""), placeholder: kindOf(c) === "date" ? "yyyy/mm/dd" : kindOf(c) === "num" ? "数値" : "文字",
      inputmode: kindOf(c) === "num" ? "decimal" : null, hidden: noValue(op) ? "hidden" : null });
    const sel = el("select", { class: "fd-op", onchange: () => (inp.hidden = noValue(sel.value)) }, ...ops.map(([v, t]) => el("option", { value: v, text: t, selected: v === op ? "selected" : null })));
    const row = el("div", { class: "fd-cond" }, sel, inp, el("button", { type: "button", class: "fd-del", title: "この条件を消す", text: "×", onclick: () => row.remove() }));
    return row;
  };
  const condUI = (c, f) => {
    const list = el("div", { class: "fd-conds" }, ...(f?.conds?.length ? f.conds : [{}]).map(x => condRow(c, x)));
    const join = f?.join || "and";
    const quick = c.k === "progress" && el("div", { class: "fd-row" }, el("span", { class: "muted", text: "クイック:" }),
      ...[["完了(100)", [{ op: "eq", v: "100" }]], ["未完了", [{ op: "lt", v: "100" }]], ["50%未満か空欄", [{ op: "lt", v: "50" }, { op: "blank", v: "" }]]].map(([t, conds]) =>
        el("button", { type: "button", text: t, onclick: () => { list.replaceChildren(...conds.map(x => condRow(c, x))); $$("[name=join]", F.drop).forEach(i => (i.checked = i.value === (conds.length > 1 ? "or" : "and"))); } })));
    return [el("div", { class: "fd-sub", text: "条件" }),
      el("div", { class: "fd-row" }, ...[["and", "すべて満たす (AND)"], ["or", "いずれか (OR)"]].map(([v, t]) =>
        el("label", {}, el("input", { type: "radio", name: "join", value: v, checked: join === v ? "checked" : null }), ` ${t}`))),
      list, el("div", { class: "fd-row" }, el("button", { type: "button", text: "＋ 条件を追加", onclick: () => list.append(condRow(c)) })), quick];
  };
  const readConds = (c, d) => $$(".fd-cond", d).map(row => {
    const op = $(".fd-op", row).value, raw = $(".fd-v", row).value.trim();
    const v = noValue(op) ? "" : kindOf(c) === "date" ? normDate(raw) : raw;
    if (!noValue(op) && v && kindOf(c) === "date" && dn(v) === null) throw new Error(`日付が読めません: ${raw}（yyyy/mm/dd）`);
    if (!noValue(op) && v && kindOf(c) === "num" && isNaN(+v)) throw new Error(`数値ではありません: ${raw}`);
    return { op, v };
  }).filter(x => noValue(x.op) || x.v !== "");
  const readFilter = (c, d) => {
    const boxes = $$(".fd-item input", d), on = boxes.filter(i => i.checked).map(i => i.value);
    const vals = boxes.length && on.length < boxes.length ? on : null, conds = readConds(c, d);
    return vals || conds.length ? { vals, conds, join: $("[name=join]:checked", d)?.value || "and" } : null;
  };
  const place = (d, btn) => {
    const r = btn.getBoundingClientRect(), w = d.offsetWidth, h = d.offsetHeight;
    const below = innerHeight - r.bottom - 8, above = r.top - 8, up = h > below && above > below;
    Object.assign(d.style, { left: `${clamp(r.left, 8, innerWidth - w - 8)}px`, top: `${up ? Math.max(8, r.top - Math.min(h, above) - 2) : r.bottom + 2}px`,
      maxHeight: `${Math.max(160, up ? above : below)}px` });
  };
  const close = () => { F.drop?.remove(); F.drop = null; };
  const open = (id, btn) => {
    const reopen = F.drop?.dataset.col === id;
    close();
    if (reopen || !btn) return;
    const c = colBy(id), f = F.filters[id];
    const ok = () => {
      try {
        const nf = readFilter(c, d);
        const k0 = condKey();
        nf ? (F.filters[id] = nf) : delete F.filters[id];
        condKey() !== k0 && CK.condReset(); close(); changed();
      } catch (err) { msg(err.message, false); }
    };
    const sortBtn = (dir, text) => el("button", { type: "button", class: F.sort.some(s => s.id === id && s.dir === dir) ? "on" : "", text,
      onclick: () => { setSort(id, dir); close(); changed(); } });
    const d = el("div", { class: "fdrop", "data-col": id, role: "dialog" },
      el("div", { class: "fd-title", text: c.h }),
      el("div", { class: "fd-row" }, sortBtn(1, "▲ 昇順"), sortBtn(-1, "▼ 降順"), sortBtn(0, "並べ替え解除（この列）"),
        el("button", { type: "button", text: "並べ替え条件…", onclick: () => { close(); openSortDialog(); } })),
      el("div", { class: "fd-row" }, el("span", { class: "muted", text: "列:" }),
        el("button", { type: "button", text: "ここまで固定", onclick: () => { close(); freezeTo(id); } }),
        el("button", { type: "button", text: "固定解除", disabled: frozenN() ? null : "disabled", onclick: () => { close(); unfreeze(); } }),
        el("button", { type: "button", text: "並びを元に戻す", disabled: viewOrder().length ? null : "disabled", onclick: () => { close(); resetColumns(); } }),
        el("button", { type: "button", text: "この列を隠す", title: "表示だけ（CSV は変わりません）", onclick: () => { close(); hideColumn(id); } })),
      el("hr"), ...condUI(c, f).filter(Boolean),
      ...(["list", "text"].includes(kindOf(c)) ? [el("hr"), ...listUI(c, f)] : []),
      el("div", { class: "fd-row fd-actions" },
        el("button", { type: "button", class: "primary", text: "OK", onclick: ok }),
        el("button", { type: "button", text: "この列のフィルター解除", onclick: () => { F.filters[id] && CK.condReset(); delete F.filters[id]; close(); changed(); } }),
        el("button", { type: "button", text: "閉じる", onclick: close })));
    d.addEventListener("keydown", e => e.key === "Enter" && e.target.tagName === "INPUT" && !["checkbox", "radio"].includes(e.target.type) && ok());
    F.drop = d;
    document.body.append(d);
    place(d, btn);
    $(".fd-v:not([hidden])", d)?.focus();
  };

  /* ---------- 並べ替え条件ダイアログ ---------- */
  const openSortDialog = () => {
    close();
    let draft = F.sortDefault ? [] : F.sort.filter(s => colBy(s.id)).map(s => ({ ...s }));
    const sortable = cols();
    const levelRow = (s, k) => el("tr", {},
      el("td", { class: "muted", text: k === 0 ? "最優先" : `次に ${k + 1}` }),
      el("td", {}, el("select", { "data-k": "id", onchange: e => (draft[k].id = e.target.value) },
        ...sortable.map(c => el("option", { value: colId(c), text: c.h, selected: colId(c) === s.id ? "selected" : null })))),
      el("td", {}, el("select", { "data-k": "dir", onchange: e => (draft[k].dir = +e.target.value) },
        el("option", { value: 1, text: "昇順 ▲", selected: s.dir > 0 ? "selected" : null }), el("option", { value: -1, text: "降順 ▼", selected: s.dir < 0 ? "selected" : null }))),
      el("td", {}, el("button", { type: "button", title: "上へ", text: "↑", disabled: k === 0 ? "disabled" : null, onclick: () => move(k, -1) }),
        el("button", { type: "button", title: "下へ", text: "↓", disabled: k === draft.length - 1 ? "disabled" : null, onclick: () => move(k, 1) }),
        el("button", { type: "button", title: "このレベルを削除", text: "削除", onclick: () => { draft.splice(k, 1); paint(); } })));
    const move = (k, dk) => { draft.splice(k + dk, 0, ...draft.splice(k, 1)); paint(); };
    const body = el("tbody");
    const paint = () => body.replaceChildren(...(draft.length ? draft.map(levelRow) : [el("tr", {}, el("td", { colspan: 4, class: "muted", text: "指定なし（既定: No. の昇順）" }))]));
    const unused = () => sortable.map(colId).find(id => !draft.some(s => s.id === id)) ?? colId(sortable[0]);
    const done = () => {
      const seen = new Set();
      setUserSort(draft.filter(s => !seen.has(s.id) && seen.add(s.id)));  // 同じ列は最初のレベルだけ
      shut(); changed();
    };
    const shut = () => { ov.remove(); document.removeEventListener("keydown", esc, true); };
    const esc = e => e.key === "Escape" && (e.stopPropagation(), shut());
    const ov = el("div", { class: "modal-ov", onpointerdown: e => e.target === ov && shut() },
      el("div", { class: "modal", role: "dialog", "aria-label": "並べ替え条件" },
        el("div", { class: "fd-title", text: "並べ替え条件" }),
        el("p", { class: "muted", text: "上のレベルから順に比べます。見出しのクリックとも連動します（無い列は最後のレベルに追加、ある列は昇順⇔降順）。" }),
        el("table", { class: "list sort-levels" }, el("thead", {}, el("tr", {}, ...["", "列", "順序", ""].map(t => el("th", { text: t })))), body),
        el("div", { class: "fd-row" }, el("button", { type: "button", text: "＋ レベルを追加", onclick: () => { draft.push({ id: unused(), dir: 1 }); paint(); } }),
          el("button", { type: "button", text: "すべて削除", onclick: () => { draft = []; paint(); } })),
        el("div", { class: "fd-row fd-actions" }, el("button", { type: "button", class: "primary", text: "OK", onclick: done }),
          el("button", { type: "button", text: "キャンセル", onclick: shut }))));
    paint();
    document.body.append(ov);
    document.addEventListener("keydown", esc, true);
  };

  /* ---------- 条件の保存 (名前を付けて presets.json に残す) ---------- */
  /* 呼び出し中のプリセットの表示: 名前（変更あり）・上書き保存は変更があるときだけ */
  /* ---------- 前回の表示を覚える (アプリを開き直しても同じ条件で始まる)。保存した条件 (プリセット) とは別。settings.json の last_view ---------- */
  const LAST_IDS = ["exp-calc"];  // ガント以外のチェック・選択 (ガントの表示は ganttState)
  const lastState = () => ({ v: 1, filters: F.filters, sort: F.sortDefault ? [] : F.sort, gantt: ganttState(), preset: F.preset, over: overState(),  // 呼び出し中のプリセット (名前と基準)・画面だけの上書き
    ctl: Object.fromEntries(LAST_IDS.map(id => document.getElementById(id)).filter(Boolean).map(e => [e.id, e.type === "checkbox" ? e.checked : e.value])) });
  let lastTimer = null, lastReady = false;
  const saveLast = () => {
    if (!lastReady) return;  // 起動して前回の表示を当てるまでは書かない
    clearTimeout(lastTimer);
    lastTimer = setTimeout(flushLast, 400);
  };
  const flushLast = (beacon = false) => {
    lastTimer = null;
    const v = JSON.stringify(lastState()), tv = JSON.stringify({ v: 1, tabs: tabsState().tabs });  // 開いているタブ (並び・各タブの条件) も一緒に覚える
    if (v === S.settings.last_view && tv === S.settings.cond_tabs) return;
    Object.assign(S.settings, { last_view: v, cond_tabs: tv });
    putSettings({ last_view: v, cond_tabs: tv });  // 前回の表示は画面ごと (ブラウザに同期で書くので、ページを離れる直前 (beacon) でも間に合う)
  };
  /* 古い基準にはあとで足したガントの項目が無い: GANTT0 の既定値で補ってから比べる (項目を足しても同じ)。読めなければ null */
  const normBase = s => { try { const b = JSON.parse(s); return canon(b?.gantt && typeof b.gantt === "object" ? { ...b, gantt: { ...GANTT0, ...b.gantt } } : b); } catch { return null; } };
  /* 起動時: 覚えていたタブを戻す。いまのプリセットに無い名前・読めないものは外す (作業中の条件はそのまま) */
  const readTabs = raw => {
    let t = null;
    try { t = raw ? JSON.parse(raw) : null; } catch { t = null; }
    return (Array.isArray(t?.tabs) ? t.tabs : []).filter(x => x && typeof x.name === "string" && S.presets[x.name])
      .map(x => ({ name: x.name, snap: x.snap && typeof x.snap === "object" ? x.snap : null, base: normBase(x.base) })).filter((x, i, a) => x.base && a.findIndex(y => y.name === x.name) === i);
  };
  addEventListener("pagehide", () => lastTimer && (clearTimeout(lastTimer), flushLast(true)));  // 変えた直後に再読み込み (F5) しても残す
  /* 起動時: 前回の絞り込み・並べ替え・ガントの表示・チェックを当てる (読めない・古い列の条件は黙って外す) */
  const restoreLast = (raw, tabsRaw) => {
    let s = null;
    try { s = raw ? JSON.parse(raw) : null; } catch { s = null; }
    if (s && typeof s === "object") {
      const fs = s.filters && typeof s.filters === "object" ? s.filters : {};
      F.filters = Object.fromEntries(Object.entries(fs).filter(([id, f]) => colBy(id) && f && typeof f === "object"));
      setUserSort(Array.isArray(s.sort) ? s.sort.filter(x => x && colBy(x.id) && (x.dir === 1 || x.dir === -1)) : []);
      Object.entries(s.ctl || {}).filter(([id]) => LAST_IDS.includes(id)).forEach(([id, v]) => {
        const e = document.getElementById(id);
        e && (e.type === "checkbox" ? typeof v === "boolean" && (e.checked = v) : [...(e.options || [])].some(o => o.value === v) && (e.value = v));
      });
      applyOver(s.over);  // 保存した条件のバー表示・線の太さ (画面だけ。ファイルの値は s.gantt.inazuma_w では上書きしない)
      s.gantt && typeof s.gantt === "object" && applyGantt({ ...s.gantt, inazuma_w: undefined });
      // 呼び出し中だったプリセット: いまも在るときだけ選択表示に戻す (基準と比べて「（変更あり）」)
      // 古い基準にはあとで足したガントの項目が無い: GANTT0 の既定値で補ってから比べる (項目を足しても同じ)
      const p = s.preset, base = p && normBase(p.base);
      F.preset = p && typeof p.name === "string" && base && S.presets[p.name] ? { name: p.name, base } : null;
      changed();
    }
    F.tabs = readTabs(tabsRaw);  // 見ているタブが並びに無ければ presetState が足す (snap なし)
    F.preset && F.tabs.forEach(t => t.name === F.preset.name && (t.base = F.preset.base));
    lastReady = true;
    presetState();
  };
  document.addEventListener("change", e => LAST_IDS.includes(e.target?.id) && saveLast());
  /* ---------- 条件のタブ (保存した条件ごと)。見ているタブ = F.preset、ほかのタブは離れたときの作業中の条件 snap を持つ。
     F.preset があれば必ずそのタブがある。タブが無いときは従来どおり条件なしの素の表示 ---------- */
  const tabOf = name => F.tabs.find(t => t.name === name);
  const tabMod = t => (t.name === F.preset?.name ? modified() : !!t.snap && canon(t.snap) !== t.base);
  const parkActive = () => { const t = tabOf(F.preset?.name); t && ((t.snap = structuredClone(state())), (t.base = F.preset.base)); };  // 離れるタブの作業中の条件を預ける
  const tabsState = () => (parkActive(), { tabs: F.tabs.map(({ name, snap, base }) => ({ name, snap, base })), active: F.preset?.name ?? null });  // 覚える形 (復元は後の段階)
  const renderTabs = () => {
    const bar = $("#cond-tabs"), act = F.preset?.name;
    if (!bar) return;
    const win = window.WinSync, extra = win?.extra() ?? [];  // 別ウィンドウに出しているタブの印・戻すボタン (別ウィンドウでは常に出す)
    const sig = canon([F.tabs.map(t => [t.name, tabMod(t)]), act, win?.sig()]);
    if (bar.dataset.sig === sig) return;
    bar.dataset.sig = sig; bar.hidden = !F.tabs.length && !extra.length;
    bar.replaceChildren(...F.tabs.map(t => el("div", { class: `ctab${t.name === act ? " active" : ""}${tabMod(t) ? " modified" : ""}`, "data-name": t.name, title: describe(S.presets[t.name]), draggable: "true",
      ondragstart: e => { dragTab = t.name; e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", t.name); },
      ondragover: e => dragTab && e.preventDefault(), ondragend: () => (dragTab = null),
      ondrop: e => { e.preventDefault(); dragTab && moveTab(dragTab, t.name); dragTab = null; } },
      el("button", { type: "button", class: "ctab-name", text: `${t.name}${tabMod(t) ? "（変更あり）" : ""}`, onclick: () => loadPreset(t.name) }),
      el("button", { type: "button", class: "ctab-pop", title: "別のウィンドウで開く", text: "⧉", onclick: () => win?.popOut(t.name) }),
      el("button", { type: "button", class: "ctab-x", title: "このタブを閉じる", text: "×", onclick: () => closeTab(t.name) })
    )).concat(extra));
  };
  /* タブのドラッグでの並べ替え (ドラッグしたタブをドロップしたタブの位置へ) */
  let dragTab = null;
  const moveTab = (from, to) => {
    const a = F.tabs.findIndex(t => t.name === from), b = F.tabs.findIndex(t => t.name === to);
    a < 0 || b < 0 || a === b || (F.tabs.splice(b, 0, F.tabs.splice(a, 1)[0]), presetState());
  };
  const presetState = () => {
    saveLast();
    F.preset && !tabOf(F.preset.name) && F.tabs.push({ name: F.preset.name, snap: null, base: F.preset.base });
    renderTabs();
    const name = F.preset?.name, mod = modified();
    $$(".preset-sel").forEach(sel => {  // タスク表とガントの欄 (同じ状態を出す)
      $$("option", sel).forEach(o => (o.textContent = o.value && o.value === name && mod ? `${o.value}（変更あり）` : o.value || "保存した条件…"));
      sel.value = name && S.presets[name] ? name : "";
      sel.classList.toggle("modified", mod);
      $$("option", sel).forEach(o => (o.title = o.value ? describe(S.presets[o.value]) : ""));
      sel.title = name ? `「${name}」の中身:\n${describe(S.presets[name])}${mod ? "\n\n（いまの表示はここから変更あり）" : ""}` : "保存した並べ替え・フィルター・表示の条件を呼び出す";
    });
    $$(".btn-preset-over").forEach(b => (b.disabled = !mod));
    $$(".btn-preset-del").forEach(b => (b.disabled = !name));
  };
  const fillPresets = () => {
    $$(".preset-sel").forEach(sel => sel.replaceChildren(el("option", { value: "", text: "保存した条件…" }), ...Object.keys(S.presets).map(n => el("option", { value: n, text: n }))));
    $$(".order-preset-sel").forEach(sel => { const v = sel.value; sel.replaceChildren(el("option", { value: "", text: "保存した条件…" }), ...Object.keys(S.presets).map(n => el("option", { value: n, text: n }))); sel.value = S.presets[v] ? v : ""; });  // 出力タブの「並びの元」の条件の選択欄 (選んでいた条件が消えたら空に)
    F.tabs = F.tabs.filter(t => S.presets[t.name]);  // 無くなったプリセットのタブは外す (作業中の条件はそのまま)
    F.preset = F.preset && S.presets[F.preset.name] ? F.preset : null;
    presetState();
  };
  const writePreset = async (name, verb) => {  // presets.json に書くのはここだけ (上書き保存・別名で保存)
    const snap = state(), prev = F.preset?.name, at = F.tabs.findIndex(t => t.name === prev), base = canon(snap);
    const r = await post("/api/presets", { name, preset: structuredClone(snap) });
    if (!r.ok) return msg(r.msg, false);
    S.presets = r.presets; F.preset = { name, base };
    F.tabs = F.tabs.filter(t => t.name !== prev && t.name !== name);  // 見ていたタブが保存した名前に替わる (同じ名前の別のタブは外す)
    F.tabs.splice(at < 0 ? F.tabs.length : Math.min(at, F.tabs.length), 0, { name, snap: null, base });
    fillPresets(); window.WinSync?.presetsChanged();
    msg(`条件「${name}」を${verb}しました`);
  };
  const saveAs = async () => {
    // 表示の設定 (列・ガント・バー表示) も入るので、フィルターが無くても保存できる
    const name = prompt("新しい名前でこの並べ替え・フィルター条件を保存", F.preset ? `${F.preset.name} のコピー` : "")?.trim();
    if (!name) return;
    if (S.presets[name] && !confirm(`「${name}」は既にあります。上書きしますか？`)) return;
    writePreset(name, "保存");
  };
  const overwrite = () => F.preset && modified() && confirm(`保存した条件「${F.preset.name}」をいまの条件で上書きしますか？`) && writePreset(F.preset.name, "上書き保存");
  const applyCond = copy => {  // 条件の写し (プリセットかタブの snap) を作業中の条件にする。外したツリーの件数を返す
    F.filters = Object.fromEntries(Object.entries(copy.filters || {}).filter(([id]) => colBy(id)));
    setUserSort((copy.sort || []).filter(s => colBy(s.id)));
    copy.range && applyRange(copy.range);  // 無い部分 (古いプリセット) はいまのまま
    copy.view && applyView(copy.view);
    copy.gantt && applyGantt(copy.gantt);
    copy.bars && applyBars(copy.bars);
    const dropped = Array.isArray(copy.tree) ? applyTree(copy.tree, true) : 0;
    Array.isArray(copy.recur) && applyRecur(copy.recur);  // 定期グループの開閉 (古いプリセットに無ければいまのまま)  // 無くなった親は外して当てる (その状態がこのプリセットの基準)
    return dropped;
  };
  /* 保存した条件を選ぶ / タブをクリック: 開いていなければタブを開き、開いていればそのタブへ切り替える (離れるタブの変更はタブに残るので確認は不要) */
  const loadPreset = (name, fromSel = false) => {  // fromSel = コンボボックスで選んだ (見ているタブの名前を選び直すと、保存した内容を呼び直す)
    if (!name) { F.tabs = F.tabs.filter(t => t.name !== F.preset?.name); F.preset = null; return presetState(); }  // 「保存した条件…」: 作業中の条件はそのまま、見ているタブを外す (変更は作業中の条件に残る)
    const p = S.presets[name], same = F.preset?.name === name;
    if (!p) return;
    if (same && !fromSel) return presetState();
    if (same && modified() && !confirm(`「${name}」の変更は保存されていません。破棄して保存した内容に戻しますか？`)) return presetState();
    parkActive();
    const tab = tabOf(name), fresh = same || !tab?.snap;
    const dropped = applyCond(structuredClone(fresh ? p : tab.snap));  // 写しを作業中の条件にする (プリセット自体は変えない)
    F.preset = { name, base: fresh ? canon(state()) : tab.base };
    tab ? (tab.base = F.preset.base) : F.tabs.push({ name, snap: null, base: F.preset.base });
    const ckd = CK.condReset();  // 条件の入れ替え: チェックは全解除
    changed(); msg(`${fresh ? `条件「${name}」を呼び出しました（変更しても保存するまでプリセットは変わりません）` : `タブ「${name}」に切り替えました`}${dropped ? `。ツリーの開閉: いまのデータに無い親 ${dropped} 件は無視しました` : ""}${ckd ? "。選択は解除しました" : ""}`);
  };
  const closeTab = (name, force = false) => {
    const t = tabOf(name);
    if (!t || (!force && tabMod(t) && !confirm(`「${name}」の変更は保存されていません。閉じますか？`))) return;
    const i = F.tabs.indexOf(t), next = F.tabs[i + 1] ?? F.tabs[i - 1], wasActive = name === F.preset?.name;
    F.tabs.splice(i, 1);
    wasActive && (F.preset = null);
    wasActive && next ? loadPreset(next.name) : presetState();  // 見ていたタブを閉じたら隣のタブへ (無ければ条件はそのまま・素の表示)
  };
  const deletePreset = async () => {
    const name = F.preset?.name;
    if (!name || !confirm(`保存した条件「${name}」を削除しますか？`)) return;
    const r = await post("/api/presets", { name, preset: null });
    if (r.ok) { S.presets = r.presets; F.tabs = F.tabs.filter(t => t.name !== name); F.preset = null; fillPresets(); window.WinSync?.presetsChanged(); msg(`条件「${name}」を削除しました（作業中の条件はそのまま）`); }
  };
  /* ---------- 別ウィンドウとのやりとり (WinSync が呼ぶ) ---------- */
  const popTab = name => {  // タブを外して、渡す形 {name, snap, base} を返す (変更はそのまま持たせる)。見ていたタブなら隣へ移る
    if (!tabOf(name)) return null;
    parkActive();
    const { snap, base } = tabOf(name);
    closeTab(name, true);
    return { name, snap, base };
  };
  const mergeTabs = (raw, fallback) => {  // 戻ってきたタブ (cond_tabs の JSON、無ければ渡したときの形) を後ろに足す。同じ名前がもうあれば今のタブを優先
    const list = readTabs(raw), got = list.length ? list : readTabs(JSON.stringify({ tabs: fallback ? [fallback] : [] }));
    const add = got.filter(t => !tabOf(t.name));
    F.tabs.push(...add); presetState();
    return add.map(t => t.name);
  };
  const adoptTab = t => {  // 別ウィンドウの最初: 渡されたタブ 1 つだけにして、その条件を当てる
    const p = S.presets[t?.name], base = t && normBase(t.base);
    if (!p || !base) return false;
    applyCond(structuredClone(t.snap && typeof t.snap === "object" ? t.snap : p));
    F.preset = { name: t.name, base }; F.tabs = [{ name: t.name, snap: null, base }];
    CK.condReset(); changed();
    return true;
  };
  const flushNow = () => (clearTimeout(lastTimer), flushLast());

  document.addEventListener("pointerdown", e => F.drop && !F.drop.contains(e.target) && !e.target.closest?.(".fbtn, .chip-t") && close(), true);
  document.addEventListener("keydown", e => e.key === "Escape" && F.drop && close());
  addEventListener("resize", close);
  document.addEventListener("DOMContentLoaded", () => {
    $("#btn-sort-dialog").addEventListener("click", openSortDialog);
    $("#btn-view-grid").addEventListener("click", e => CV.open("grid", e.currentTarget));
    $$(".btn-preset-save").forEach(b => b.addEventListener("click", saveAs));
    $$(".btn-preset-over").forEach(b => b.addEventListener("click", overwrite));
    $$(".btn-preset-del").forEach(b => b.addEventListener("click", deletePreset));
    $$(".preset-sel").forEach(s => s.addEventListener("change", e => loadPreset(e.target.value, true)));
  });
  /* 出力の「並びの元」: 保存した条件の名前 → 並べ方 {sort, sortDefault, group, gsort}。無い名前は null (呼ぶ側がエラーにする) */
  const condOf = name => { const p = S.presets[name]; return p ? { sort: (p.sort || []).filter(s => colBy(s.id)), sortDefault: !(p.sort || []).some(s => colBy(s.id)), group: p.gantt?.group || "3", gsort: p.gantt?.gsort || "no" } : null; };
  return { apply, reloaded, resetOver, condOf, sortTasks: (rows, all, ov) => sorted(rows, all, ov), passes: r => passes(r, undefined, cachedP()), active, th, toggleSort, setSort, open, close, clearAll, clearFilters, clearSort, resetView, restoreView, openReset, setTree, toggleTree, setRecur: applyRecur, toggleRecur, recurAll, treeLevel, initTree, setRange, initRange, presetState, describe, state, restoreLast, saveLast, lastState, pin, afterSet, afterSnap, afterRestore, renderChips, fillPresets, openSortDialog, modified, loadPreset, closeTab, tabsState, popTab, mergeTabs, adoptTab, flushNow, F };
})();
