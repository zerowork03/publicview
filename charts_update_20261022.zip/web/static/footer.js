/* 影響タスクの欄 (ガント編集の下): 選んだタスクの先行・後続だけのガント。
   データ・元に戻す・未保存の印は上のガントと共通 (同じ S.data.tasks を直接編集)。検索条件は使わない */
(() => {
  const FT = { pinned: new Set(), lastSrc: null, inited: false };
  const tasks = () => S.data.tasks;
  const open = () => !$("#gf-wrap").hidden;
  const idxOf = ts => ts.map(t => tasks().indexOf(t)).filter(i => i >= 0).sort((a, b) => a - b);
  /* 起点 (添字の配列): ピン留め → チェックしたタスク → 上のガントで選んだ 1 行 */
  const sources = () => {
    const pin = idxOf([...FT.pinned]), ck = idxOf([...CK.set()]), sel = window.Gantt?.G.sel ?? -1;
    return pin.length ? pin : ck.length ? ck : sel >= 0 && tasks()[sel] ? [sel] : [];
  };
  /* 先行 (preds) か後続 (succs) をたどって届くタスクすべて */
  const reach = (ti, next, seen = new Set()) => (next(ti).filter(x => !seen.has(x)).forEach(x => (seen.add(x), reach(x, next, seen))), seen);
  /* 依存の順 (トポロジカル)。表示の並びは上のガントと同じ階層 (gantt.js の tree) で、これは件数の数え用 */
  const topo = (set, dg) => {
    const no = i => (/^\d+$/.test(tasks()[i].no || "") ? +tasks()[i].no : 1e9), byNo = (a, b) => no(a) - no(b) || a - b;
    const indeg = new Map([...set].map(i => [i, dg.preds[i].filter(p => set.has(p)).length]));
    const out = [];
    while (indeg.size) {
      const pick = [...indeg].filter(([, d]) => d === 0).map(([i]) => i).sort(byNo)[0] ?? [...indeg.keys()].sort(byNo)[0];
      out.push(pick); indeg.delete(pick);
      dg.succs[pick].filter(s => indeg.has(s)).forEach(s => indeg.set(s, indeg.get(s) - 1));
    }
    return out;
  };
  /* 起点ごとの連鎖を合併 (起点は数でも配列でもよい) */
  const chainOf = (srcs, scope) => {
    const dg = depGraph(tasks()), ss = [].concat(srcs);
    const near = ss.flatMap(s => (scope === "direct" ? [...dg.preds[s], ...dg.succs[s]] : [...reach(s, i => dg.preds[i]), ...reach(s, i => dg.succs[i])]));
    return topo(new Set([...ss, ...near]), dg);
  };
  const rowsNow = () => { const s = sources(); FT.srcSet = new Set(s); return s.length ? chainOf(s, $("#gf-scope").value) : []; };  // srcSet: 行ごとの起点判定 (chain-src) 用に 1 回だけ作る

  const G2 = makeGantt({ id: "gf", edit: true, tasks, only: rowsNow, spanOwn: () => rowsNow().map(i => tasks()[i]), isSrc: ti => !!FT.srcSet?.has(ti), visible: open,
    peer: () => window.Gantt });
  const refresh = () => {
    if (!open()) return;
    const srcs = sources(), rows = rowsNow(), t = srcs.length ? tasks()[srcs[0]] : null;
    $("#gf-hint").hidden = !!t; $("#gf-gantt").hidden = !t;
    const sc0 = $("#gf-scope").value === "all" ? "すべての連鎖" : "直接のみ", near = `前後 ${rows.length - srcs.length} 件`;
    $("#gf-title").textContent = !t ? "" : srcs.length === 1 ? `No.${t.no} ${t.level3}（${sc0}: ${near}）` : `起点 ${srcs.length} 件（${sc0}: ${near}）`;
    $("#gf-pin").disabled = !t && !FT.pinned.size;
    if (!t) return (FT.lastSrc = null);
    const prev = FT.lastSrc, moved = !prev || !srcs.some(i => prev.includes(i));  // 前の起点と重ならない: 先頭へ戻す
    String(prev) !== String(srcs) && (G2.G.sel = srcs[0]);  // 起点が変わったときだけ (欄の中で選んだ行は動かさない)
    FT.lastSrc = srcs;
    G2.render(false, true);
    if (moved) {  // 新しいタスク: 先頭の行・最初のバーへ
      const sc = G2.D("scroll"), first = Math.min(...rows.map(i => dn(tasks()[i].plan_start)).filter(v => v !== null));
      sc.scrollTop = 0; Number.isFinite(first) && (sc.scrollLeft = Math.max(0, G2.X(first) - 40));
    }
  };
  const setOpen = on => {
    $("#gf-wrap").hidden = !on; $("#tab-gantt").classList.toggle("with-footer", on);
    $("#g-chainbtn").classList.toggle("on", on); $("#g-chainbtn").setAttribute("aria-pressed", on);
    on && !FT.inited && (G2.init(), (FT.inited = true));
    FT.lastSrc = null; refresh(); window.Gantt?.render();
  };
  const resize = e => {  // 境目をドラッグで高さを変える
    const tab = $("#tab-gantt"), y0 = e.clientY, h0 = $("#gf-wrap").getBoundingClientRect().height;
    const mv = ev => tab.style.setProperty("--gf-h", `${Math.round(Math.min(Math.max(h0 + y0 - ev.clientY, 160), innerHeight * 0.75))}px`);
    const end = () => { removeEventListener("pointermove", mv); removeEventListener("pointerup", end); window.Gantt?.render(); };
    addEventListener("pointermove", mv); addEventListener("pointerup", end); e.preventDefault();
  };
  document.addEventListener("DOMContentLoaded", () => {
    $("#g-chainbtn").addEventListener("click", () => setOpen(!open()));
    $("#gf-close").addEventListener("click", () => setOpen(false));
    $("#gf-scope").addEventListener("change", () => { FT.lastSrc = null; refresh(); TF.presetState(); });
    $("#gf-pin").addEventListener("change", e => { FT.pinned = new Set(e.target.checked ? sources().map(i => tasks()[i]) : []); e.target.checked = !!FT.pinned.size; refresh(); });
    $("#gf-split").addEventListener("pointerdown", resize);
    $("#gf-flat").addEventListener("change", e => { saveView({ gf_flat: e.target.checked ? "on" : "off" }); refresh(); });  // 一覧表示は下の欄だけの設定: 自分を保存して下だけ描き直す
    ["#gf-group", "#gf-gsort"].forEach(s => $(s).addEventListener("change", () => { saveView({ gf_group: $("#gf-group").value, gf_gsort: $("#gf-gsort").value }); refresh(); TF.presetState(); }));  // 下の欄だけのグループ化の深さ・グループ内の並び
    $("#gf-view").addEventListener("click", e => CV.open("gantt", e.currentTarget, G2));
  });
  window.GFooterPeer = { render: () => refresh() };  // 上のガントが描き直したら呼ばれる
  window.GFooter = { G: G2.G, gantt: G2, refresh, setOpen, chainOf, open, sources };
})();

/* 表示期間 (共通条件): 自動（検索条件）/ 固定 (yyyy/mm/dd〜) / 全タスク。ガント編集に置く */
(() => {
  const MODES = [["auto", "自動（検索条件）"], ["fixed", "固定"], ["all", "全タスク"]];
  const cur = () => TF.F.range || { mode: "auto", from: "", to: "" };
  const build = box => box.replaceChildren(
    el("label", { title: "ガントの横軸の期間。全タブで共通、保存した条件（プリセット）にも入ります" }, "表示期間 ",
      el("select", { class: "span-mode" }, ...MODES.map(([value, text]) => el("option", { value, text })))),
    el("span", { class: "span-fixed" }, el("input", { class: "span-from", placeholder: "yyyy/mm/dd", size: 10, "aria-label": "表示期間の開始" }), "〜",
      el("input", { class: "span-to", placeholder: "yyyy/mm/dd", size: 10, "aria-label": "表示期間の終了" })));
  const sync = () => document.querySelectorAll(".span-ctl").forEach(box => {
    const r = cur();
    box.querySelector(".span-mode").value = r.mode;
    box.querySelector(".span-fixed").hidden = r.mode !== "fixed";
    [["from", ".span-from"], ["to", ".span-to"]].forEach(([k, s]) => { const i = box.querySelector(s); document.activeElement !== i && (i.value = r[k] ? fmtDate(r[k]) : ""); });
  });
  const read = box => {
    const mode = box.querySelector(".span-mode").value, d = s => normDate(box.querySelector(s).value, "");
    let [from, to] = [d(".span-from"), d(".span-to")].map(v => (dn(v) !== null ? v : ""));
    if (mode === "fixed" && !from && !to) [from, to] = Gantt.span().map(ds);  // 固定にした直後: いま見えている期間
    if (from && to && to < from) [from, to] = [to, from];
    return { mode, from, to };
  };
  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".span-ctl").forEach(build);
    document.addEventListener("change", e => { const box = e.target.closest(".span-ctl"); box && TF.setRange(read(box)); });
  });
  window.SpanCtl = { sync, cur };
})();
