/* 保存の衝突の画面 (複数人の同時利用)。保存すると、ほかの人の変更と同じセルでぶつかった行だけがここに来る (ぶつからない行は保存済み)。
   行ごとに「他の人の値を使う」か「自分の値で上書き」かを選び、決めたら保存し直す。上のボタンで全部まとめても選べる。
   種類 (サーバーの conflicts[].kind): cells = 同じ列を別の値に変えた / edit_deleted = 自分が編集した行を他の人が削除 / deleted_edit = 自分が削除した行を他の人が編集 */
window.Conflicts = (() => {
  const label = k => S.data.columns?.find(c => c.key === k)?.label || k;
  const show = v => (v === "" || v == null ? "（空）" : String(v));
  const nameOf = c => (c.theirs_row || c.mine_row || {}).level3 || "";
  const newRid = () => `new-${S.newSeq = (S.newSeq || 0) + 1}`;

  /* 選んだとおりに行と基準 (f.base) を直す。mine で残る分は、基準を「他の人の行」にして送り直せば衝突しない */
  const resolve = (f, c, pick) => {
    const t = f.tasks.find(x => x._rid === c.key);
    f.theirs.delete(c.key); f.gone.delete(c.key);
    if (c.kind === "cells") {
      pick === "theirs" && Object.assign(t, c.theirs_row);
      f.base.set(c.key, baseOf(c.theirs_row));
    } else if (c.kind === "edit_deleted") {
      f.base.delete(c.key);
      pick === "theirs" ? f.tasks.splice(f.tasks.indexOf(t), 1) : t && (t._rid = newRid());  // 自分の内容で戻す = 新しい行として足す
    } else {  // deleted_edit
      pick === "mine" ? f.base.set(c.key, baseOf(c.theirs_row)) : f.base.delete(c.key);  // 他の人の編集を残す: 基準から外せば、最新の読み直しで普通の行として戻る
    }
  };

  const card = (c, i) => {
    const name = el("b", { text: `No.${c.no || c.key}` });
    const radios = (a, b) => el("div", { class: "cf-pick" },
      ...[["theirs", a], ["mine", b]].map(([v, t]) => el("label", {}, el("input", { type: "radio", name: `cf-${i}`, value: v, checked: v === "theirs" ? "checked" : null }), ` ${t}`)));
    const body = c.kind === "cells"
      ? [el("table", { class: "cf-table" }, el("thead", {}, el("tr", {}, ...["列", "元の値", "他の人の値", "自分の値"].map(h => el("th", { text: h })))),
        el("tbody", {}, ...c.cols.map(x => el("tr", {}, el("td", { text: label(x.col) }), el("td", { class: "muted", text: show(x.base) }), el("td", { class: "cf-theirs", text: show(x.theirs) }), el("td", { class: "cf-mine", text: show(x.mine) }))))),
      radios("他の人の値を使う", "自分の値で上書き")]
      : c.kind === "edit_deleted"
        ? [el("div", { class: "cf-note", text: "あなたが編集した行を、ほかの人が削除しました。" }), radios("削除のままにする（自分の編集は捨てる）", "自分の内容で行を戻す")]
        : [el("div", { class: "cf-note", text: `あなたが削除した行を、ほかの人が編集しました（${[c.theirs_row?.owner, c.theirs_row?.progress && `進捗 ${c.theirs_row.progress}`, c.theirs_row?.note].filter(Boolean).join(" / ") || "内容は行を残して確認してください"}）。` }), radios("他の人の編集を残す（削除を取り消す）", "削除する")];
    return el("div", { class: "cf-card", "data-i": i }, el("div", { class: "cf-head" }, name, `　${nameOf(c) || "（名前なし）"}`), ...body);
  };

  const open = (name, conflicts) => {
    const f = S.files.get(name);
    if (!f || !conflicts?.length) return;
    const shut = () => { ov.remove(); document.removeEventListener("keydown", esc, true); };
    const esc = e => e.key === "Escape" && (e.stopPropagation(), shut());
    const all = v => $$(`.cf-pick input[value=${v}]`, box).forEach(r => { r.checked = true; });
    const ok = async () => {
      const picks = conflicts.map((_, i) => box.querySelector(`input[name=cf-${i}]:checked`)?.value || "theirs");
      shut();
      conflicts.forEach((c, i) => resolve(f, c, picks[i]));
      await refreshOpenFiles().catch(() => {});  // 「他の人の編集を残す」の行は、最新の読み直しで戻る
      syncDirty(name); renderAll(); updateDirty();
      const n = picks.filter(p => p === "mine").length;
      if (dirtyFiles().length) { msg(`${conflicts.length} 行を選びました（自分の値 ${n} 行・他の人の値 ${conflicts.length - n} 行）。保存し直します…`); await saveAll(); }
      else msg(`${conflicts.length} 行は他の人の値を使いました（保存し直す変更はありません）`);
    };
    const box = el("div", { class: "modal bulk-dlg cf-dlg" },
      el("div", { class: "fd-title", text: `他の人の変更とぶつかった行（${conflicts.length} 件）` }),
      el("div", { class: "muted", text: `${name}: ぶつからなかった行は保存済みです。ぶつかった行は、どちらの値にするか行ごとに選んでください（初期は他の人の値）。` }),
      el("div", { class: "fd-row" }, el("button", { type: "button", text: "すべて他の人の値を使う", onclick: () => all("theirs") }), el("button", { type: "button", text: "すべて自分の値で上書き", onclick: () => all("mine") })),
      el("div", { class: "cf-list" }, ...conflicts.map(card)),
      el("div", { class: "fd-row fd-actions" }, el("button", { type: "button", class: "primary cf-ok", text: "決めて保存", onclick: ok }), el("button", { type: "button", class: "cf-later", text: "あとで（未保存のまま閉じる）", onclick: shut })));
    const ov = el("div", { class: "modal-ov", onpointerdown: e => e.target === ov && shut() }, box);
    document.body.append(ov); document.addEventListener("keydown", esc, true);
  };
  return { open, resolve };
})();

/* saveAll から: 衝突があった。最新の行と合流してから (自分の値は残る) 衝突の画面を開く */
const afterConflict = async err => {
  await refreshOpenFiles().catch(() => {});
  msg(`${err.message}\n衝突した行を選んで保存し直してください`, false);
  window.Conflicts.open(err.file, err.conflicts);
};
