/* ほかの人の変更に気づく (複数人の同時利用): 12 秒ごとに軽い問い合わせ (/api/poll = 版を返すだけ) をして、自分が読んだ内容と違えば帯を出す。
   編集中に勝手に読み直さない: 「反映」を押したときだけ、最新の行と合流する (保存していない自分の編集は残す。ほかの人も変えた行には印)。
   Access から書き出した CSV でファイルを置き換えたときも、ファイルの版が変わるので同じ帯が出る */
window.Sync = (() => {
  const INTERVAL = 12000;
  let timer = null, last = null, dismissed = "", busy = false;
  const names = () => [...S.files.entries()].filter(([, f]) => !f.error).map(([n]) => n);

  /* 自分が読んだ内容と違うもの (自分の保存は版・設定の値を更新するので、自分の変更では出ない) */
  const diffs = p => ({
    boot: !!S.boot && p.boot !== S.boot,
    files: names().filter(n => p.files[n] && p.files[n].version !== S.files.get(n).version),
    gone: names().filter(n => p.files[n] === null),
    shared: Object.keys(p.shared).filter(k => S.versions?.[k] !== undefined && p.shared[k] !== S.versions[k]),
    settings: !S.settingsBusy && VIEW_KEYS.some(k => k in p.settings && String(p.settings[k] ?? "") !== String(S.settings[k] ?? "")),
  });
  const any = d => d.boot || d.files.length || d.gone.length || d.shared.length || d.settings;
  const sigOf = d => JSON.stringify([d.boot, d.files, d.gone, d.shared, d.settings]);

  const render = d => {
    const b = $("#sync-banner");
    if (!b) return;
    if (!any(d) || sigOf(d) === dismissed) return void (b.hidden = true);
    const pending = S.dirty.size > 0;
    const parts = [d.files.length && `タスク（${d.files.join("・")}）`, d.gone.length && `${d.gone.join("・")} は削除されました`,
      d.shared.length && `マスタ・列定義（${d.shared.map(k => KIND_JA[k] || (k === "params" ? "パラメータ" : k)).join("・")}）`, d.settings && "表示設定"].filter(Boolean);
    b.replaceChildren(
      el("span", { class: "sync-text", text: d.boot ? "アプリが更新されました（サーバーが起動し直されました）。画面を再読み込み（F5）してください。" : `ほかの人が更新しました: ${parts.join("、")}。${pending ? "保存していない自分の変更は残します（ぶつかる行には印を付けます）。" : ""}` }),
      d.boot ? el("button", { type: "button", class: "sync-go", text: "再読み込み", onclick: () => location.reload() })
        : el("button", { type: "button", class: "sync-go", text: "反映", onclick: () => apply() }),
      el("button", { type: "button", class: "sync-later", text: "あとで", onclick: () => { dismissed = sigOf(d); b.hidden = true; } }));
    b.hidden = false;
  };

  const tick = async () => {
    if (!S.boot || busy || S.saving || document.hidden) return;
    busy = true;
    const seq = S.saveSeq || 0;
    try {
      const p = await api(`/api/poll?${names().map(n => `f=${enc(n)}`).join("&")}`);
      if (!p.ok || seq !== (S.saveSeq || 0) || S.saving) return;  // 問い合わせ中に自分が保存した: この結果は古い
      last = p;
      const known = S.fileList.map(f => f.name).sort().join("\n");
      if (p.list.slice().sort().join("\n") !== known) { await refreshFileList(); renderFileTabs(); fillOutFile(); }  // ほかの人が足した・消したファイル
      render(diffs(p));
    } catch { /* サーバーに届かない間は何もしない (次の問い合わせで) */ } finally { busy = false; }
  };

  /* 「反映」: 最新の行と合流 (未保存の編集は残す)。マスタに未保存の編集があるときはマスタを読み直さない */
  const apply = async () => {
    const masterDirty = KINDS.some(k => k !== "tasks" && S.dirty.has(k));
    S.saving = true;
    try {
      if (!masterDirty) await reload(false, [], true);
      else { await refreshOpenFiles(); msg("マスタに未保存の編集があるため、マスタ・列定義は読み直していません（先に保存してください）", false); }
      const f = curFile(), marked = f ? f.theirs.size + f.gone.size : 0;
      masterDirty || msg(`ほかの人の変更を反映しました${marked ? `（あなたも変えた行 ${marked} 件に印を付けました。保存するときに確認します）` : ""}`);
      dismissed = "";
      $("#sync-banner").hidden = true;
    } catch (e) { msg(`反映できませんでした: ${e.message}`, false); } finally { S.saving = false; S.saveSeq = (S.saveSeq || 0) + 1; }
    tick();
  };

  const start = () => {
    clearInterval(timer);
    timer = setInterval(tick, INTERVAL);
    document.addEventListener("visibilitychange", () => !document.hidden && tick());  // タブに戻ったらすぐ確かめる
  };
  document.addEventListener("DOMContentLoaded", start);
  return { tick, apply, diffs, last: () => last };
})();
