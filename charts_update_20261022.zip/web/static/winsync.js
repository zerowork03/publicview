"use strict";
/* 別ウィンドウ: 条件のタブ (taskfilter.js) を別のブラウザウィンドウに出す・戻す。ウィンドウどうしの連絡は localStorage (storage イベント) と BroadcastChannel だけ。
   出す: タブを外して {name, snap, base} を localStorage に預け (win_hand.<窓ID>)、/?w=<窓ID>#<いまの画面> を開く。開いた窓は預かったタブ 1 つの条件から始まり、画面は自由に切り替えられる。
   元の窓は一覧 (win_out) に残して、タブの場所に「別ウィンドウ」の印を出す。
   戻す: 別ウィンドウの「元のウィンドウに戻す」か窓を閉じる → 元の窓が (閉じたのを見つけて / 連絡を受けて) その窓の cond_tabs.<窓ID> のタブを自分に足す。
   窓の生存は、開いた窓の closed と、別ウィンドウが 1 秒ごとに書く印 (win_alive.<窓ID>) で見る。編集の衝突は既存の同時実行処理 (更新の帯・conflict.js) に任せる */
window.WinSync = (() => {
  const WID = LS.WID, REG = "win_out", ALIVE = w => `win_alive.${w}`, HAND = w => `win_hand.${w}`;
  const handles = new Map();  // 窓ID → この窓から開いた window (再読み込みで消える。その間は生存の印で見る)
  const bc = typeof BroadcastChannel === "function" ? new BroadcastChannel("gantt-win") : null;
  const readReg = () => { try { return JSON.parse(LS.gget(REG) || "{}") || {}; } catch { return {}; } };
  const writeReg = r => LS.gset(REG, JSON.stringify(r));
  const mine = () => Object.entries(readReg()).filter(([, e]) => e.from === WID);  // この窓から出したタブ
  const gone = (wid, e) => { const h = handles.get(wid); return h ? h.closed : Date.now() - Math.max(+LS.gget(ALIVE(wid)) || 0, e.t || 0) > 4000; };

  /* 別ウィンドウが閉じた / 戻すと言った: その窓のタブを自分に足して、預けたものを片づける */
  const collect = wid => {
    const reg = readReg(), e = reg[wid];
    if (!e || e.from !== WID) return;
    delete reg[wid]; writeReg(reg);
    let hand = null;
    try { hand = JSON.parse(LS.gget(HAND(wid)) || "null")?.tab; } catch { hand = null; }
    const names = TF.mergeTabs(LS.gget(`cond_tabs.${wid}`), hand);  // 窓で変えた条件ごと戻る (覚えが無ければ出したときの形)
    LS.gkeys().filter(k => k.endsWith(`.${wid}`)).forEach(LS.gdel);
    handles.delete(wid);
    names.length && msg(`別ウィンドウのタブを戻しました: ${names.join("、")}`);
  };

  const popOut = name => {
    const t = TF.popTab(name);
    if (!t) return;
    const wid = Math.random().toString(36).slice(2, 8);
    LS.gset(HAND(wid), JSON.stringify({ tab: t, from: WID }));
    writeReg({ ...readReg(), [wid]: { names: [name], from: WID, t: Date.now() } });
    const w = window.open(`/?w=${wid}${location.hash || "#tasks"}`, `gantt_${wid}`, "popup,width=1300,height=800");
    if (w) handles.set(wid, w);
    else { collect(wid); msg("別ウィンドウを開けませんでした（ポップアップがブロックされています）", false); }
    TF.presetState();
  };

  /* 別ウィンドウ側: 戻す (未保存のセル編集があれば確認。窓を閉じるだけの場合は既存の beforeunload が確認する) */
  const giveBack = () => {
    if (S.dirty.size && !confirm("この窓には未保存の編集があります。戻すと破棄されます。戻しますか？")) return;
    S.dirty.clear();  // 閉じるときの確認を重ねない
    TF.flushNow();
    bc?.postMessage({ type: "back", wid: WID });
    window.close();
  };

  /* タブバーに足す部品: 出しているタブの印 (元の窓)・戻すボタン (別ウィンドウ) */
  const extra = () => [
    ...mine().map(([wid, e]) => el("div", { class: "ctab out", "data-wid": wid, title: "別のウィンドウで開いています（クリックでそのウィンドウを前面へ）。そのウィンドウの「元のウィンドウに戻す」か、閉じると、ここに戻ります" },
      el("button", { type: "button", class: "ctab-name", text: `⧉ ${e.names.join("、")}（別ウィンドウ）`, onclick: () => handles.get(wid)?.focus() }))),
    WID && el("button", { type: "button", id: "btn-win-back", class: "ctab-back", text: "↩ 元のウィンドウに戻す", title: "この窓のタブを元のウィンドウに戻して閉じます", onclick: giveBack }),
  ].filter(Boolean);
  const sig = () => JSON.stringify([mine().map(([w, e]) => [w, e.names]), !!WID]);

  /* 起動時 (restoreLast のあと): 別ウィンドウなら預かったタブから始める (再読み込みのときは自分の覚えを使う)。生存の印を出し始める */
  let booted = false;
  const boot = () => {
    if (!WID || booted) return;
    booted = true;
    document.title = `${document.title}（別ウィンドウ）`;
    if (LS.gget(`cond_tabs.${WID}`) === null) { try { TF.adoptTab(JSON.parse(LS.gget(HAND(WID)) || "null")?.tab); } catch { /* 預かったタブが読めない: 条件なしで始める */ } }
    const beat = () => LS.gset(ALIVE(WID), Date.now());
    beat(); setInterval(beat, 1000);
    TF.presetState();
  };

  const presetsChanged = () => bc?.postMessage({ type: "presets", presets: S.presets });
  bc && (bc.onmessage = ({ data: m }) => {
    m?.type === "back" && collect(m.wid);
    m?.type === "presets" && m.presets && typeof m.presets === "object" && (S.presets = m.presets, TF.fillPresets());  // 保存・削除は全窓の選択欄とタブに届く
  });
  addEventListener("storage", e => e.key?.endsWith(REG) && TF.presetState());
  setInterval(() => mine().filter(([w, e]) => gone(w, e)).forEach(([w]) => collect(w)), 1000);
  return { WID, popOut, extra, sig, boot, presetsChanged, collect, giveBack };
})();
