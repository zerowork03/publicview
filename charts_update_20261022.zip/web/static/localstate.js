/* 画面ごと (ブラウザごと) の一時的な状態の置き場: localStorage。複数人が同じサーバーを開いても、開閉・タブ・前回の表示などが互いに混ざらない。
   サーバーの settings.json は共有の設定 (列の並び・幅・固定・仕切り・保存した条件・出力の条件・週末) だけ。KEYS は app.py の LOCAL_KEYS と同じ。
   ブラウザに値が無い初回だけ、サーバーの settings.json の値を既定として読む (reload の LS.overlay)。localStorage はオリジン (http://アドレス:ポート) ごと */
window.LS = (() => {
  const P = "gantt.ui.";
  const KEYS = ["last_view", "cond_tabs", "gantt_collapsed", "gantt_recur_open", "open_files", "cur_file", "out_file", "today", "gantt_deps", "gantt_span", "gantt_span_from", "gantt_span_to"];
  /* 窓ID (?w=…): 別ウィンドウは開いているファイル・前回の表示・タブなどを取り合わないよう、キーを <キー>.<窓ID> に分ける (基準日 today だけ全窓で共通)。窓IDが無い通常の画面は従来のキー。
     窓ごとのキーに値が無い間は、通常の画面の値を引き継ぐ (開いたときの状態から始める)。ただし last_view・cond_tabs は引き継がない (別ウィンドウは渡されたタブの条件から始まる) */
  const WID = new URLSearchParams(location.search).get("w") || "";
  const OWN_ONLY = ["last_view", "cond_tabs"];
  const kn = k => (WID && k !== "today" ? `${k}.${WID}` : k);
  const rd = k => { try { return localStorage.getItem(P + k); } catch { return null; } };
  const raw = k => rd(kn(k)) ?? (WID && !OWN_ONLY.includes(k) ? rd(k) : null);
  const has = k => raw(k) !== null;
  const get = (k, d = "") => (has(k) ? raw(k) : d);
  const set = (k, v) => { try { localStorage.setItem(P + kn(k), String(v ?? "")); } catch { /* 容量いっぱい・保存禁止: 画面の中だけで続ける */ } };
  /* サーバーの設定 s のうち画面ごとのキーを、ブラウザにある値で置き換える (無いキーはサーバーの値 = 初回の既定のまま) */
  const overlay = s => Object.assign(s, Object.fromEntries(KEYS.filter(has).map(k => [k, raw(k)])));
  /* 窓の間の連絡用 (窓IDで分けない生のキー): 別ウィンドウの一覧・生存の印・渡すタブ */
  const gget = k => rd(k);
  const gset = (k, v) => { try { localStorage.setItem(P + k, String(v ?? "")); } catch { /* 同上 */ } };
  const gdel = k => { try { localStorage.removeItem(P + k); } catch { /* 同上 */ } };
  const gkeys = () => { try { return Object.keys(localStorage).filter(k => k.startsWith(P)).map(k => k.slice(P.length)); } catch { return []; } };
  return { KEYS, WID, has, get, set, overlay, gget, gset, gdel, gkeys };
})();
