/* 列の表示設定 (タスクの表・ガントの左の表): 表示/非表示・並び (▲▼・先頭/末尾)・左の固定 (表だけ)・幅。
   見出しの右端をドラッグして幅を変える。どれも表示だけ (共通条件 settings.json・プリセットに入る)。
   「幅を列定義に保存」で列定義 (columns.csv) の width / gantt_width に書き、既定の幅にする */
const CV = (() => {
  /* ---------- 幅のドラッグ: 見出しの右端 (.col-rs / .gt-rs)。動かしている間もすぐ反映、離したら保存 ---------- */
  const bindResize = (root, { get, live, done, reset }) => {
    let d = null;
    const handle = e => e.target.closest?.(".col-rs, .gt-rs");
    root.addEventListener("pointerdown", e => {
      const h = handle(e);
      if (!h || e.button > 0) return;
      e.preventDefault(); e.stopPropagation();
      d = { id: h.dataset.rs, x: e.clientX, w0: get(h.dataset.rs, h), w: 0 };
      try { root.setPointerCapture(e.pointerId); } catch { /* 合成イベント */ }
      document.body.classList.add("col-resizing");
    }, true);
    root.addEventListener("pointermove", e => {
      if (!d) return;
      e.stopPropagation();
      const w = clamp(Math.round(d.w0 + e.clientX - d.x), 20, 600);
      w !== d.w && ((d.w = w), live(d.id, w));
    }, true);
    const end = e => {
      if (!d) return;
      e.stopPropagation();
      const g = d; d = null; S.colDragJustEnded = Date.now();  // 直後の click (並べ替え) を無視
      document.body.classList.remove("col-resizing");
      g.w && done(g.id, g.w);
    };
    root.addEventListener("pointerup", end, true);
    root.addEventListener("pointercancel", end, true);
    root.addEventListener("dblclick", e => { const h = handle(e); h && (e.stopPropagation(), reset(h.dataset.rs)); }, true);
    root.addEventListener("click", e => (handle(e) || Date.now() - (S.colDragJustEnded || 0) < 300) && e.stopPropagation(), true);
  };
  let raf = 0;
  const soon = fn => { cancelAnimationFrame(raf); raf = requestAnimationFrame(fn); };
  const setW = (key, id, w) => { const m = parseW(S.settings[key]); w ? (m[id] = w) : delete m[id]; S.settings[key] = fmtW(m); };
  const resizedMsg = () => msg("列の幅を変えました（表示だけ。既定の幅にするには「表示設定」→「幅を列定義に保存」）");
  const bindGridResize = tbl => bindResize(tbl, {
    get: (id, h) => SPECS.tasksAll.find(c => colKey(c) === id)?.w || h.closest("th").offsetWidth,
    live: (id, w) => { setW("grid_widths", id, w); soon(() => { S.taskSpec = null; renderGrid("tasks"); }); },
    done: () => { saveView({}); resizedMsg(); },
    reset: id => { setW("grid_widths", id, 0); saveView({}); },
  });
  const bindGanttResize = (box, gantt) => bindResize(box, {
    get: (id, h) => h.parentElement.offsetWidth,
    live: (id, w) => { setW("gantt_widths", id, w); soon(() => renderGantts()); },
    done: () => { saveView({}); renderGantts(); resizedMsg(); },
    reset: id => { setW("gantt_widths", id, 0); saveView({}); renderGantts(); },
  });
  const renderGantts = () => { window.Gantt?.render(); window.GFooter?.refresh?.(); window.Compare?.render?.(); };

  /* ---------- 表示設定のダイアログ ---------- */
  let pop = null;
  const close = () => { pop?.remove(); pop = null; document.removeEventListener("keydown", onKey, true); };
  const onKey = e => e.key === "Escape" && (e.stopPropagation(), close());
  /* 対象ごとの読み書き。items = [{ id, h, hidden, w, w0, must }] (いまの並び) */
  const TARGETS = {
    grid: {
      title: "表示設定（タスクの表）", frozen: true,
      items: () => { const hid = viewHidden(); return SPECS.tasksAll.map(c => ({ id: colKey(c), h: c.h, hidden: hid.includes(colKey(c)), w: viewWidths()[colKey(c)] || "", w0: buildTaskSpec().find(x => colKey(x) === colKey(c))?.w || "" })); },
      defaults: () => buildTaskSpec().map(c => ({ id: colKey(c), h: c.h, hidden: false, w: "", w0: c.w || "" })),
      frozenN: () => +S.settings.grid_frozen || 0,
      apply: (items, fz) => saveView({ grid_col_order: items.map(x => x.id).join(","), grid_hidden: items.filter(x => x.hidden).map(x => x.id).join(","),
        grid_widths: fmtW(Object.fromEntries(items.filter(x => +x.w).map(x => [x.id, +x.w]))), grid_frozen: String(fz) }),
      schemaField: "width",
    },
    gantt: {
      get title() { return window.Gantt?.flatOn() ? "表示設定（ガントの左の表・一覧表示）" : "表示設定（ガントの左の表）"; }, frozen: false,
      items: () => { const vw = parseW(S.settings.gantt_widths);
        return window.Gantt.viewCols().map(c => ({ id: c.k, h: c.h, hidden: !c.shown, x: !!c.x, w: vw[c.k] || "", w0: c.wDef, must: c.must, note: c.note })); },
      defaults: () => window.Gantt.viewCols(true).map(c => ({ id: c.k, h: c.h, hidden: !c.shown, x: !!c.x, w: "", w0: c.wDef, must: c.must, note: c.note })),
      apply: items => {  // 隠した / 出した列: ダイアログにない列 (ツリーと一覧表示で違う列) の分は残す
        const ids = new Set(items.map(x => x.id)), keep = k => (S.settings[k] || "").split(",").filter(id => id && !ids.has(id));
        saveView({ [window.Gantt.flatOn() ? "gantt_flat_col_order" : "gantt_col_order"]: items.map(x => x.id).join(","),
          gantt_hidden: [...keep("gantt_hidden"), ...items.filter(x => x.hidden && !x.must).map(x => x.id)].join(","),
          gantt_shown: [...keep("gantt_shown"), ...items.filter(x => !x.hidden && x.x).map(x => x.id)].join(","),
          gantt_widths: fmtW({ ...parseW(S.settings.gantt_widths), ...Object.fromEntries(items.map(x => [x.id, +x.w || 0])) }) });
        renderGantts();
      },
      schemaField: "gantt_width",
      flatOrder: () => window.Gantt.flatOn(),  // 一覧表示: 並びを列定義の gantt_flat_order に保存できる
    },
  };
  const open = (which, btn) => {
    if (pop) return close();
    const T = TARGETS[which];
    let items = T.items(), fz = T.frozenN?.() || 0, sel = null;
    const move = (i, to) => { const [x] = items.splice(i, 1); items.splice(clamp(to, 0, items.length), 0, x); sel = x.id; draw(); };
    const list = el("div", { class: "cv-list" });
    /* ⋮⋮ をドラッグして行を並べ替え (⤒▲▼⤓ と同じ。列定義の表と同じ操作) */
    let dg = null;
    const rowAt = e => document.elementFromPoint(e.clientX, e.clientY)?.closest?.(".cv-row");
    const markRow = (r, after) => { list.querySelectorAll(".cv-drop-b, .cv-drop-a").forEach(x => x.classList.remove("cv-drop-b", "cv-drop-a")); r?.classList.add(after ? "cv-drop-a" : "cv-drop-b"); };
    list.addEventListener("pointerdown", e => { const h = e.target.closest(".cv-handle"); if (!h) return; e.preventDefault(); dg = { i: +h.closest(".cv-row").dataset.i }; try { list.setPointerCapture(e.pointerId); } catch { /* */ } });
    list.addEventListener("pointermove", e => { if (!dg) return; const r = rowAt(e), b = r?.getBoundingClientRect(); dg.to = r ? +r.dataset.i : null; dg.after = !!b && e.clientY > b.top + b.height / 2; markRow(r, dg.after); });
    const dragEnd = e => {
      const g = dg; dg = null; markRow(null);
      if (!g || e.type !== "pointerup" || g.to === null || g.to === undefined) return;
      const to = g.to + (g.after ? 1 : 0) - (g.to + (g.after ? 1 : 0) > g.i ? 1 : 0);
      to !== g.i && move(g.i, to);
    };
    list.addEventListener("pointerup", dragEnd); list.addEventListener("pointercancel", dragEnd);
    const fzSel = T.frozen ? el("select", { title: "左から何列目までを固定するか (横にスクロールしても見える)" }) : null;
    const draw = () => {
      const vis = items.filter(x => !x.hidden);
      list.replaceChildren(...items.map((x, i) => el("div", { class: `cv-row${x.id === sel ? " sel" : ""}${T.frozen && fz && vis[fz - 1] === x ? " frz-line" : ""}`, "data-i": i, onclick: () => { sel = x.id; } },
        el("span", { class: "cv-handle", "aria-label": "ドラッグで並べ替え", text: "⋮⋮" }),
        el("input", { type: "checkbox", checked: x.hidden ? null : "checked", disabled: x.must ? "disabled" : null, title: x.must ? "この列は隠せません" : "表示する",
          onchange: e => { x.hidden = !e.target.checked; draw(); } }),
        el("span", { text: x.h + (x.note ? `（${x.note}）` : ""), title: x.id }),
        el("button", { type: "button", text: "⤒", title: "先頭へ", disabled: i ? null : "disabled", onclick: () => move(i, 0) }),
        el("button", { type: "button", text: "▲", title: "上へ", disabled: i ? null : "disabled", onclick: () => move(i, i - 1) }),
        el("button", { type: "button", text: "▼", title: "下へ", disabled: i < items.length - 1 ? null : "disabled", onclick: () => move(i, i + 1) }),
        el("button", { type: "button", text: "⤓", title: "末尾へ", disabled: i < items.length - 1 ? null : "disabled", onclick: () => move(i, items.length - 1) }),
        el("input", { type: "number", min: 20, max: 600, step: 1, value: x.w, placeholder: x.w0 ? String(x.w0) : "自動", title: "幅 (px)。空欄 = 列定義の幅",
          onchange: e => { x.w = e.target.value && clamp(+e.target.value, 20, 600); } }))));
      fzSel && fzSel.replaceChildren(el("option", { value: 0, text: "固定しない" }), ...vis.map((x, k) => el("option", { value: k + 1, text: `${k + 1} 列目「${x.h}」まで` })));
      fzSel && (fzSel.value = String(Math.min(fz, vis.length)));
    };
    fzSel?.addEventListener("change", () => { fz = +fzSel.value; draw(); });
    const saveDefault = async () => {  // 幅を列定義に保存: いまダイアログにある幅を columns.csv の width / gantt_width へ
      const ws = Object.fromEntries(items.filter(x => +x.w).map(x => [x.id, String(+x.w)]));
      const cols = S.data.columns.filter(c => ws[c.key] !== undefined);
      if (!cols.length) return msg("保存する幅がありません（幅を入力するか、見出しの右端をドラッグして変えてください）", false);
      if (S.dirty.has("columns") && !confirm("列定義に未保存の変更があります。幅と一緒に保存されます。続けますか？")) return;
      pushUndo("columns"); cols.forEach(c => (c[T.schemaField] = ws[c.key])); markDirty("columns");
      try { await saveKind("columns"); } catch (err) { return msg("列定義に保存できませんでした\n" + err.message, false); } finally { updateDirty(); }
      items.forEach(x => S.data.columns.some(c => c.key === x.id) && (x.w0 = +ws[x.id] || x.w0, ws[x.id] && (x.w = "")));
      T.apply(items, fz); draw();
      const skipped = Object.keys(ws).filter(k => !S.data.columns.some(c => c.key === k));
      msg(`列定義に既定の幅を保存しました（${cols.map(c => c.label).join("・")}）` + (skipped.length ? `。${skipped.join("・")} は列定義にない列なので表示だけの幅です` : ""));
    };
    const saveFlatOrder = async () => {  // 一覧表示の並び・表示を列定義に: gantt_flat_order = いまの位置 1..N、gantt_flat_visible = 追加の列は yes/no、組み込みの列は隠したときだけ no
      const pos = Object.fromEntries(items.map((x, i) => [x.id, String(i + 1)])), byId = Object.fromEntries(items.map(x => [x.id, x]));
      const cols = S.data.columns.filter(c => pos[c.key] !== undefined);
      if (S.dirty.has("columns") && !confirm("列定義に未保存の変更があります。並びと一緒に保存されます。続けますか？")) return;
      pushUndo("columns");
      cols.forEach(c => { const x = byId[c.key]; c.gantt_flat_order = pos[c.key]; c.gantt_flat_visible = x.x ? (x.hidden ? "no" : "yes") : x.hidden && !x.must ? "no" : ""; });
      markDirty("columns");
      try { await saveKind("columns"); } catch (err) { return msg("列定義に保存できませんでした\n" + err.message, false); } finally { updateDirty(); }
      const saved = new Set(cols.map(c => c.key)), drop = k => (S.settings[k] || "").split(",").filter(id => id && !(saved.has(id) && byId[id]?.x)).join(",");
      saveView({ gantt_flat_col_order: "", gantt_shown: drop("gantt_shown"), gantt_hidden: drop("gantt_hidden") }); renderGantts(); close();
      const viewOnly = items.filter(x => !S.data.columns.some(c => c.key === x.id)).map(x => x.h);
      msg("一覧表示の列の並び・表示を列定義に保存しました" + (viewOnly.length ? `（${viewOnly.join("・")} は列定義にない列なので、通常の並びの位置になります）` : ""));
    };
    pop = el("div", { class: "cv-pop", role: "dialog" },
      el("h3", { text: T.title }),
      el("div", { class: "hint", text: "チェックで表示、▲▼ で並び替え。幅は空欄なら列定義の幅。どれも表示だけで、CSV の列の順番は変わりません。" }),
      list,
      fzSel && el("label", {}, "列の固定: ", fzSel),
      el("div", { class: "cv-foot" },
        el("button", { type: "button", text: "既定に戻す", title: "列定義の順・すべて表示・列定義の幅・固定なし（適用するまで反映しません）", onclick: () => { items = T.defaults(); fz = 0; draw(); } }),
        el("button", { type: "button", text: "幅を列定義に保存", title: "入力した幅を列定義 (columns.csv) に書いて、既定の幅にします", onclick: saveDefault }),
        T.flatOrder?.() && el("button", { type: "button", text: "並び・表示を列定義に保存", title: "この並びと表示/非表示を列定義の「一覧表示の並び」(gantt_flat_order)・「一覧表示に表示」(gantt_flat_visible) に書いて、一覧表示の既定にします（稼働日数の列は列定義にないので表示だけ）", onclick: saveFlatOrder }),
        el("span", { class: "sp" }),
        el("button", { type: "button", text: "キャンセル", onclick: close }),
        el("button", { type: "button", class: "primary", text: "適用", onclick: () => { T.apply(items, fz); close(); msg(`${T.title.replace(/^表示設定/, "表示設定")} を適用しました（表示だけ）`); } })));
    document.body.append(pop);
    draw();
    const r = btn.getBoundingClientRect();
    Object.assign(pop.style, { left: `${clamp(r.left, 8, innerWidth - pop.offsetWidth - 8)}px`, top: `${Math.min(r.bottom + 4, innerHeight - pop.offsetHeight - 8)}px` });
    document.addEventListener("keydown", onKey, true);
  };
  return { open, close, bindGridResize, bindGanttResize, isOpen: () => !!pop };
})();
