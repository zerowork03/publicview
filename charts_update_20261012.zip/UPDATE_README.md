# ガントチャート Web アプリ 更新パッケージ（20261012 版）

## 対象バージョン

- **更新前**: 2026-10-11 に配布した charts_release.zip（「状況」マスタ・「表示設定…」・「ファイルを削除」が**ない**版）を `C:\gantt` に入れて使っている環境
- **更新後**: 20261012 版（下の変更点をすべて含む。新しい charts_release.zip と同じ内容）
- 見分け方: 画面の上のタブに「状況」があれば、すでに新しい版です（この更新は不要）。

この zip には **変わった・増えたアプリのファイルだけ** が入っています。タスクのデータ・マスタ（master フォルダの CSV）・設定は上書きしません。

## 変更点一覧

### 画面（タスク・ガント編集）
- 表の見出しをスクロールしても上に固定（左の固定列も）。見出しの列の間に区切り線
- すべての表（タスク・ガントの左の表・影響タスク・比較・各マスタ・設定・列定義・表示設定）のデータのセルにも縦横の罫線。ガントのバーの欄にも行の境目の薄い線（PDF も同じ）
- 修正: ガントを右端まで横スクロールすると日付の見出しとバーの欄が数 px ずれる不具合
- 「表示設定…」（タスクの表・ガントの左の表）: 列の表示/非表示・並び（▲▼・先頭へ/末尾へ）・左の固定・幅を一覧で設定。「既定に戻す」「幅を列定義に保存」
- 列の幅を見出しの右端のドラッグで変更（ダブルクリックで既定の幅）
- 列定義の行の並びを保存すると、それがタスクの表・ガントの表の既定の列順になる
- ガント編集の「一覧表示」: ツリーではなく作業（末端のタスク）だけを並べ、見出しのクリックで並べ替え。プロジェクト・大項目・中項目は列で表示。一覧表示用の列の並び（列定義の「一覧表示の並び」）
- 一覧表示では、列定義のほかの列（カテゴリ・担当・状況・優先順位・重要度・備考・追加の列など）も「表示設定…」で選んで出せる（既定は非表示・読み取りだけ・見出しのクリックで並べ替え・幅の変更可）。「並び・表示を列定義に保存」で既定にできる（列定義の「一覧表示に表示」）。ツリー表示・影響タスクの欄は従来どおり
- 「バー表示」の設定画面を広く。ラベルの並べ方（横に「・」でつなぐ / 縦に積む）を位置ごとに選べる
- 「ファイルを削除」: 表示中のタスクのファイルを data\trash\日時\ へ移す（完全には消さない。ファイル名の入力で確認）
- 画面全体はスクロールせず、表・ガントだけがスクロール（スクロールバーが常に見える）

### データ・列
- 新しいコア列「状況」(status) と「状況」マスタ (master\statuses.csv: 未着手・進行中・完了・保留・中止)。状況の「イナズマ線から除く」が yes のタスク（保留・中止）はイナズマ線で今日の位置のまま
- 「改行あり」(列定義 multiline): yes にした文字の列はセルで Enter が改行（確定は Ctrl+Enter・Tab・外をクリック、Esc で取り消し）。CSV ではセル内の改行を `</br>` と書く（`<br>` などや本当の改行も読める）
- イナズマ線の太さ（設定 → パラメータ「inazuma_width」、既定 1.4 px。PDF にも反映）
- マスタの名前・色・並び順は、使用中のコードでも変更できるように修正（使用中のコードの削除・コード変更だけ止め、どのファイルの何番で使っているかを表示）

### PDF（出力）
- 表の日付を yyyy/mm/dd に統一。タスク名は 1 行（長いと …）。備考などは列の幅で 2 行まで折り返し → 入らなければ文字を小さく → それでも入らなければ …
- 状況マスタ・イナズマ線の太さ・セル内の改行に対応

### Access 用の資料
- docs\ と templates\ / templates_sjis\ / templates_sample\ を更新（status 列・statuses.csv・列定義の新しい項目・`</br>` の決まり）

## 手順

1. **サーバーを止める**: アプリを起動している黒い画面（start.bat の画面）を閉じる。
2. **バックアップ**: `C:\gantt\master` と `C:\gantt\data` を、別の場所（例 `C:\gantt_backup\20261012\`）へフォルダごとコピーする。`C:\gantt\web\settings.json` と `C:\gantt\web\presets.json` もあれば一緒にコピーする。
   （同梱の `update.bat` を使う場合は、このバックアップを自動で `C:\gantt\update_backup\日時\` に取ります。`data\backup`（以前のバックアップ）は量が多いので除きます）
3. **上書きで展開**: 次のどちらかで行います。
   - **A. update.bat を使う（おすすめ）**: zip を任意の場所（例 デスクトップ）に展開し、中の `update.bat` をダブルクリック（入れ先が `C:\gantt` 以外なら `update.bat D:\別の場所` のように指定）。サーバーが動いていると止まります。バックアップ → ファイルのコピーの順に行い、ファイルは**消しません**。
   - **B. 手で上書き**: zip の中身（`chart.py`・`web`・`docs`・`templates…` のフォルダ）を `C:\gantt` に上書きでコピーする。Windows の「すべて展開」を使うときは展開先を `C:\gantt` にして「ファイルを置き換える」を選ぶ（zip 名のフォルダが作られた場合は、その中身を `C:\gantt` へ移す）。
4. **起動**: いつもどおり `start.bat` で起動する（ライブラリは前回と同じなので、追加のインストールはありません）。
5. 画面の上に「自動で更新しました」のお知らせが出ます。内容を確認して × で閉じてください。

## 自動移行の内容とバックアップ先

最初の起動のときに、次を自動で行います（元のファイルは先にバックアップします）。2 回目以降は何もしません。

| 対象 | 内容 | 元のファイルのバックアップ |
|---|---|---|
| `master\columns.csv`（列定義） | 項目 `gantt_width`・`gantt_flat_order`・`multiline`・`gantt_flat_visible` を追加（空欄 / no）。コア列「状況」(status) の定義を追加。それ以外（表示名・幅・並び・バーのラベル）はそのまま | `data\backup\日時-schema\columns.csv` |
| `data\tasks\*.csv`（タスク） | 「status」列を空欄で追加（ほかの列・値はそのまま） | `data\backup\日時-migrate\tasks\` |
| `master\statuses.csv` | ないときだけ見本の内容で作る（未着手・進行中・完了・保留(イナズマ線から除く)・中止(同)） | （新しいファイル） |
| `master\params.csv` | 書き換えません。`inazuma_width` がないときは既定の 1.4 を使います（「パラメータを保存」で書かれます） | — |
| `web\settings.json`・`web\presets.json` | 書き換えません。新しい表示の設定は既定の値で始まります。保存した条件はそのまま読めます | — |

Access からタスクの CSV を書き出している場合は、次から `status` 列も出してください（空欄でも可。docs\EXPORT_FROM_ACCESS.md・templates\tasks.csv）。出さなくても、取り込んだときに空欄で補います。

## ロールバック（元に戻す）

1. サーバーを止める。
2. 手順 2 のバックアップ（または `C:\gantt\update_backup\日時\`）の `master` と `data` を `C:\gantt` に戻す（いまの `C:\gantt\master`・`C:\gantt\data` は名前を変えて退避しておくと安全）。settings.json・presets.json も戻す。
3. 前回の charts_release.zip の `chart.py`・`web` フォルダ・`docs`・`templates…` を `C:\gantt` に上書きする。前の版にない `web\static\colview.js` は残っていても動作に影響しません（気になる場合は削除）。
4. `start.bat` で起動する。

※ 更新後に入力したデータ（状況・改行など）は、古い版に戻すと状況の列が「追加の列」として扱われます。消えはしませんが、古い版では編集できません。

## ファイル一覧

### 追加（4）
- `templates/statuses.csv`
- `templates_sample/statuses.csv`
- `templates_sjis/statuses.csv`
- `web/static/colview.js`

### 変更（26）
- `chart.py`
- `docs/ACCESS_TABLE_DEFINITION.md`
- `docs/EXPORT_FROM_ACCESS.md`
- `docs/OPERATIONS.md`
- `docs/access_table_spec.csv`
- `docs/access_table_spec.xlsx`
- `docs/images/01_tasks.png`
- `docs/images/02_gantt_week.png`
- `docs/images/17_file_tabs.png`
- `docs/images/19_compare_diff.png`
- `docs/images/28_effort_columns.png`
- `docs/images/29_settings_params.png`
- `docs/vba/ExportForGantt.bas`
- `templates/columns.csv`
- `templates/tasks.csv`
- `templates_sample/columns.csv`
- `templates_sample/params.csv`
- `templates_sample/tasks.csv`
- `templates_sjis/columns.csv`
- `templates_sjis/tasks.csv`
- `web/app.py`
- `web/static/app.css`
- `web/static/app.js`
- `web/static/gantt.js`
- `web/static/index.html`
- `web/static/taskfilter.js`

### 削除（0）
- （なし）
削除するファイルはありません（古いファイルを消す必要はありません）。

### 入っていないもの（上書きしません）
- `master/*.csv`（列定義 columns.csv・パラメータ params.csv・休日・各マスタ）: 起動時に自動で移行します（上の「自動移行」）
- `data/`（タスク・バックアップ・ごみ箱）、`web/output/`、`web/settings.json`、`web/presets.json`: 利用者のデータ
- `start.bat`・`requirements.txt`・`README_INSTALL.md`・`python/`・`.venv/`: 前回から変わっていません（必要なライブラリも同じ）
