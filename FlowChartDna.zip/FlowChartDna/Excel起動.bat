@echo off
rem ============================================================
rem  Launch Excel with FlowChartDna packed xll in this folder.
rem  Usage: double-click this file. 64bit Office by default.
rem ============================================================

cd /d "%~dp0"

set "XLL=%~dp0FlowChartDna-AddIn64-packed.xll"
set "EXCEL=C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE"

if not exist "%XLL%" (
    echo [ERROR] xll not found: %XLL%
    goto :error
)

if not exist "%EXCEL%" (
    echo [ERROR] Excel not found: %EXCEL%
    echo Edit the EXCEL variable in this file.
    goto :error
)

start "" "%EXCEL%" "%XLL%"
echo Excel started with the add-in loaded.
pause
exit /b 0

:error
pause
exit /b 1
