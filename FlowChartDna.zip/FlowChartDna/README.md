# FlowChartDna

Excel-DNA アドインです。フローチャートの経路列挙、横カレンダー＋ガント、Access 連携をまとめています。

## 動作環境

- Windows 11（.NET Framework 4.8.1。追加インストール不要）
- デスクトップ版 Excel（64bit / 32bit）
- Access 連携には Microsoft Access Database Engine（ACE OLEDB 12.0）が Office と同じビット数で必要

## 使い方

1. zip を展開する
2. Excel のビット数に合う `.xll` を Excel にドラッグ＆ドロップする
   - 64bit Office → `FlowChartDna-AddIn64-packed.xll`
   - 32bit Office → `FlowChartDna-AddIn-packed.xll`
3. または `Excel起動.bat` をダブルクリック（64bit Office 用。パスが違う場合は bat 内の `EXCEL` を直す）
4. `Alt+F8` でマクロ一覧。例:
   - `BuildFlowChart` … 定義シートからフローを描き、経路をシートと Access へ出力
   - `BuildStyledCalendar` … Access のタスクからスタイル付きカレンダー＋ガントを生成
   - `EnsureTaskDatabase` … `db\task.accdb` とテーブルが無ければ作成

VBA からは次のように呼べます。

```vb
Application.Run "FC_BuildFlowChart"
Application.Run "FC_BuildStyledCalendar", "スケジュール"
Application.Run "FC_LoadAccessTable", "route_nodes", "ケース縦持ち"
```

## 同梱 Access（`db\task.accdb`）

| テーブル | 内容 |
|---|---|
| `tasks` | ガント用タスク（デモ 18 件） |
| `parameters` / `weekdays` / `holidays` | 期間・土日・2026 年の祝日 |
| `routes` / `route_nodes` / `connectors` / `shapes` | 経路表示用（定義例のサンプル 2 経路） |

接続先は `.xll` と同じフォルダの `FlowChartDna.settings.json`（`taskDbPath` は `db\task.accdb`）。
`tasks` はテーブルでも保存クエリでもよい（必須列 ID / 開始日 / 完了日があれば出力できる）。
