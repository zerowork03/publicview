/* 定期タスクの回を作成: 繰り返しの条件から各回の日付を作り、取り込み用の CSV をダウンロードする。
   タスク CSV には書かない (各回はふつうのタスクの行。Access に取り込み → いつもどおり書き出す)。休日は画面の休日カレンダー (calendar().isOff) */
const RecurGen = (() => {
  const LIMIT = 500;  // 1 度に作る回の上限
  const ymd = n => { const d = new Date(n * 864e5); return [d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()]; };
  const dayOf = (y, m, d) => Date.UTC(y, m, d) / 864e5;  // m は 0 始まり。範囲外は繰り上がる
  const lastDay = (y, m) => new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  const monOff = w => (w + 6) % 7;  // 月曜 = 0 … 日曜 = 6 (週の始まりは月曜)
  const seek = (n, step, isOff, cap = 400) => (isOff(n) && cap > 0 ? seek(n + step, step, isOff, cap - 1) : n);  // 稼働日まで進む/戻る
  /* その月の基準日 (無い月は null: 第5曜日など) */
  const monthDay = (y, m, r, isOff) => {
    const L = lastDay(y, m), first = dayOf(y, m, 1), last = dayOf(y, m, L);
    const inMonth = n => (n >= first && n <= last ? n : null);
    return {
      day: () => dayOf(y, m, Math.min(Math.max(1, +r.day || 1), L)),  // 31 日など無い日は月末にそろえる
      first: () => first,
      firstwork: () => inMonth(seek(first, 1, isOff)),
      last: () => last,
      lastwork: () => inMonth(seek(last, -1, isOff)),
      nth: () => {
        const wd = +r.wd, n = +r.nth;
        const f = first + ((wd - new Date(first * 864e5).getUTCDay() + 7) % 7);  // その月の最初のその曜日
        const l = last - ((new Date(last * 864e5).getUTCDay() - wd + 7) % 7);  // 最後のその曜日
        return n === -1 ? l : inMonth(f + (n - 1) * 7);
      },
    }[r.mode || "day"]();
  };
  /* 基準日の列 (昇順・無限)。workdayBased = 稼働日だけを選ぶ規則 (休日の扱いは不要) */
  function* bases(r, isOff) {
    const N = Math.max(1, Math.floor(+r.every || 1)), from = dn(r.from);
    if (r.freq === "daily" && r.workdays) {
      for (let n = from, k = 0; ; n++) if (!isOff(n) && k++ % N === 0) yield n;
    } else if (r.freq === "daily") {
      for (let n = from; ; n += N) yield n;
    } else if (r.freq === "weekly") {
      const w0 = from - monOff(new Date(from * 864e5).getUTCDay()), wds = [...new Set(r.weekdays || [])].map(Number).sort((a, b) => monOff(a) - monOff(b));
      if (!wds.length) return;
      for (let w = 0; ; w += N) for (const wd of wds) { const n = w0 + w * 7 + monOff(wd); n >= from && (yield n); }
    } else {
      const [y0, m0] = ymd(from);
      for (let k = 0; ; k += N) { const n = monthDay(y0 + Math.floor((m0 + k) / 12), (m0 + k) % 12, r, isOff); n !== null && n >= from && (yield n); }
    }
  }
  const workdayBased = r => (r.freq === "daily" && r.workdays) || (r.freq === "monthly" && ["firstwork", "lastwork"].includes(r.mode));
  /* 休日に当たった回: keep そのまま / before 前の稼働日 / after 次の稼働日 / skip 作らない */
  const shift = (n, how, isOff) => (!isOff(n) || how === "keep" ? n : how === "skip" ? null : seek(n, how === "before" ? -1 : 1, isOff));
  /* 1 回の終わり: 暦日なら開始＋日数−1、稼働日なら開始から数えて「日数」番目の稼働日 (開始が休日ならその次の稼働日から数える) */
  const endOf = (s, d, unit, isOff) => {
    const D = Math.max(1, Math.floor(+d || 1));
    if (unit === "cal") return s + D - 1;
    const go = (n, k) => (!isOff(n) && k + 1 >= D ? n : go(n + 1, k + (isOff(n) ? 0 : 1)));
    return D === 1 ? s : go(s, 0);
  };
  const errors = r => [
    !dn(r.from) && "開始日（期間の始まり）を入れてください",
    !dn(r.to) && !(+r.count > 0) && "終了日か回数のどちらかを入れてください",
    r.to && !dn(r.to) && "終了日の形が正しくありません",
    dn(r.to) !== null && dn(r.from) !== null && dn(r.to) < dn(r.from) && "終了日が開始日より前です",
    r.count && !(Number.isInteger(+r.count) && +r.count >= 1 && +r.count <= LIMIT) && `回数は 1〜${LIMIT}`,
    !(Number.isInteger(+r.every) && +r.every >= 1 && +r.every <= 99) && "間隔は 1〜99",
    r.freq === "weekly" && !(r.weekdays || []).length && "曜日を 1 つ以上選んでください",
    r.freq === "monthly" && r.mode === "day" && !(Number.isInteger(+r.day) && +r.day >= 1 && +r.day <= 31) && "日は 1〜31",
    !(Number.isInteger(+r.dur || 1) && +(r.dur || 1) >= 1 && +(r.dur || 1) <= 366) && "1 回の日数は 1〜366",
  ].filter(Boolean);
  /* 各回: [{ n: 回, start, end, base (休日で動かす前), moved }] */
  const dates = (r, isOff = n => [0, 6].includes(new Date(n * 864e5).getUTCDay())) => {
    if (errors(r).length) return [];
    const to = dn(r.to), cnt = +r.count > 0 ? Math.min(+r.count, LIMIT) : LIMIT, how = workdayBased(r) ? "keep" : r.holiday || "keep";
    const out = [], seen = new Set(), it = bases(r, isOff);
    for (let guard = 0; out.length < cnt && guard < 20000; guard++) {
      const { value: b, done } = it.next();
      if (done || (to !== null && b > to) || b > dn(r.from) + 366 * 30) break;
      const s = shift(b, how, isOff);
      if (s === null || seen.has(s)) continue;  // 飛ばす・前後へ動かして同じ日になった回は 1 つ
      seen.add(s);
      out.push({ n: out.length + 1, start: ds(s), end: ds(endOf(s, r.dur, r.durUnit, isOff)), base: ds(b), moved: s !== b });
    }
    return out;
  };
  return { dates, errors, LIMIT, endOf, monthDay };
})();
window.RecurGen = RecurGen;

/* ---------- ダイアログ ---------- */
const openRecurDialog = () => {
  const WD = ["日", "月", "火", "水", "木", "金", "土"], cal = calendar();
  const offNow = () => cal.offOf({ calendar: val("calendar").value, exclude_weekdays: val("exwd")?.value || "" });
  const tasks = S.data.tasks || [];
  const nextNo = Math.max(0, ...tasks.map(t => +t.no || 0)) + 1;
  const opt = (v, t, sel) => el("option", { value: v, text: t, selected: sel ? "selected" : null });
  const inp = (k, attrs = {}) => el("input", { "data-r": k, ...attrs });
  const sel = (k, opts) => el("select", { "data-r": k }, ...opts);
  const master = kind => [opt("", "（なし）"), ...(S.data[kind] || []).map(m => opt(m.code, m.name))];
  const lab = (t, ...kids) => el("label", { class: "rg-f" }, el("span", { text: t }), ...kids);
  const box = el("div", { class: "modal rg-dlg", role: "dialog", "aria-label": "定期タスクの回を作成" });
  const prev = el("div", { class: "rg-prev" }), err = el("div", { class: "rg-err", role: "alert" });
  const val = k => box.querySelector(`[data-r="${k}"]`);
  const rule = () => ({
    freq: val("freq").value, every: val("every").value, workdays: val("workdays").checked,
    weekdays: [...box.querySelectorAll("[data-wd]:checked")].map(c => +c.dataset.wd),
    mode: val("mode").value, day: val("day").value, nth: val("nth").value, wd: val("wd").value,
    holiday: val("holiday").value, dur: val("dur").value || "1", durUnit: val("durUnit").value,
    from: normDate(val("from").value), to: normDate(val("to").value), count: val("count").value,
  });
  const fill = (tpl, o) => tpl.replace(/\{date\}/g, fmtDate(o.start).slice(5)).replace(/\{ymd\}/g, fmtDate(o.start)).replace(/\{n\}/g, o.n);
  const rowsOf = occ => occ.map((o, k) => ({
    no: String(+val("no").value + k), project: val("project").value, level1: val("level1").value.trim(), level2: val("level2").value.trim(),
    level3: fill(val("name").value.trim() || "定期タスク", o), category: val("category").value, owner: val("owner").value,
    plan_start: o.start, plan_end: o.end, actual_start: "", actual_end: "", progress: "0", note: val("note").value.trim(),
    priority: "", importance: "", depends: "", calendar: val("calendar").value, actual_effort: "", unit_price: "", status: "", recur_group: val("code").value.trim(),
    exclude_weekdays: val("calendar").value === CAL.WD ? wdNorm(val("exwd").value) : "",
  }));
  let occ = [];
  const paint = () => {
    const r = rule(), es = [...RecurGen.errors(r), ...(val("code").value.trim() ? [] : ["定期グループを入れてください（自由な文字、例 月次報告）"]),
      ...(val("project").value ? [] : ["プロジェクトを選んでください"]), ...(+val("no").value >= 1 ? [] : ["No. の開始は 1 以上"])];
    ["daily", "weekly", "monthly"].forEach(f => box.querySelectorAll(`.rg-${f}`).forEach(x => (x.hidden = r.freq !== f)));
    box.querySelectorAll(".rg-m-day").forEach(x => (x.hidden = r.freq !== "monthly" || r.mode !== "day"));
    box.querySelectorAll(".rg-m-nth").forEach(x => (x.hidden = r.freq !== "monthly" || r.mode !== "nth"));
    box.querySelectorAll(".rg-exwd").forEach(x => (x.hidden = calOf({ calendar: val("calendar").value }) !== CAL.WD));
    const off = offNow();  // 選んだ稼働カレンダーの休み (指定曜日除外ならその曜日だけ、除外しないなら休みなし)
    wdParse(val("exwd").value) === false && es.push("除外する曜日は 月火水木金土日 の組み合わせ（例 土日・日）");
    occ = RecurGen.dates(r, off);
    const used = new Set(tasks.map(t => String(t.no))), clash = rowsOf(occ).filter(x => used.has(x.no)).length;
    clash && es.push(`No. がいまのファイルと ${clash} 件重なります（No. の開始を ${nextNo} 以上に）`);
    const COLJ = Object.fromEntries((S.data.columns || []).map(c => [c.key, c.label || c.key]));
    occ.length && !es.length && es.push(...[...new Map(taskErrors(rowsOf(occ)[0]))].map(([k, m]) => `${COLJ[k] || k}: ${m}`));  // 必須 (担当など) はタスクと同じ検証
    err.replaceChildren(...es.map(e => el("div", { text: e })));
    box.querySelectorAll(".rg-dl").forEach(b => (b.disabled = !!es.length || !occ.length));
    const rows = rowsOf(occ);
    prev.replaceChildren(el("div", { class: "muted", text: occ.length ? `${occ.length} 回（${fmtDate(occ[0].start)}〜${fmtDate(occ.at(-1).end)}）${occ.length >= RecurGen.LIMIT ? `。上限 ${RecurGen.LIMIT} 回` : ""}` : "条件に合う日がありません" }),
      el("table", { class: "list rg-tbl" }, el("thead", {}, el("tr", {}, ...["回", "No.", "タスク", "開始", "終了", "曜日", ""].map(t => el("th", { text: t })))),
        el("tbody", {}, ...occ.map((o, k) => el("tr", { class: o.moved ? "moved" : "" },
          el("td", { class: "num", text: o.n }), el("td", { class: "num", text: rows[k].no }), el("td", { text: rows[k].level3 }),
          el("td", { class: "date", text: fmtDate(o.start) }), el("td", { class: "date", text: fmtDate(o.end) }), el("td", { text: WD[wday(dn(o.start))] }),
          el("td", { class: "muted", text: o.moved ? `休日のため ${fmtDate(o.base).slice(5)} から移動` : off(dn(o.start)) ? "休日" : "" }))))));
  };
  const download = async enc => {
    const res = await fetch("/api/recur/csv", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rows: rowsOf(occ), enc }) });
    if (!res.ok) { const j = await res.json().catch(() => ({})); return err.replaceChildren(el("div", { text: j.msg || `エラー ${res.status}` })); }
    const name = decodeURIComponent((res.headers.get("Content-Disposition") || "").match(/filename\*=UTF-8''([^;]+)/)?.[1] || "recur.csv");
    const a = el("a", { href: URL.createObjectURL(await res.blob()), download: name });
    document.body.append(a); a.click(); a.remove();
    msg(`${occ.length} 回分の CSV をダウンロードしました（${name}）。Access のタスク表に追加で取り込み、いつもどおり書き出してください（このファイルには書いていません）`);
  };
  const shut = () => { ov.remove(); document.removeEventListener("keydown", esc, true); };
  const esc = e => e.key === "Escape" && (e.stopPropagation(), shut());
  const today = baseDay();
  box.append(
    el("div", { class: "fd-title", text: "定期タスクの回を作成" }),
    el("p", { class: "muted", text: "繰り返しの条件から各回の日付を作り、取り込み用の CSV（タスクのテンプレートと同じ見出し）をダウンロードします。このファイルには書きません。休日は選んだ稼働カレンダー（空欄は設定の既定）と「設定」の休日マスタで判定します。" }),
    el("div", { class: "rg-grid" },
      el("fieldset", {}, el("legend", { text: "繰り返し" }),
        lab("頻度", sel("freq", [opt("daily", "毎日"), opt("weekly", "毎週", true), opt("monthly", "毎月")])),
        lab("間隔", inp("every", { type: "number", min: 1, max: 99, value: 1, class: "rg-n" }), el("span", { class: "rg-unit" })),
        el("label", { class: "rg-f rg-daily" }, inp("workdays", { type: "checkbox" }), el("span", { text: "稼働日だけ数える（N 稼働日ごと）" })),
        el("div", { class: "rg-f rg-weekly" }, el("span", { text: "曜日" }), ...[1, 2, 3, 4, 5, 6, 0].map(w => el("label", { class: "rg-wd" }, el("input", { type: "checkbox", "data-wd": w, checked: w === 1 ? "checked" : null }), WD[w]))),
        el("label", { class: "rg-f rg-monthly" }, el("span", { text: "日" }), sel("mode", [opt("day", "毎月 x 日"), opt("first", "月初（1 日）"), opt("firstwork", "月初の稼働日"), opt("last", "月末"), opt("lastwork", "月末の稼働日"), opt("nth", "第 N 曜日")])),
        el("label", { class: "rg-f rg-m-day" }, el("span", { text: "x" }), inp("day", { type: "number", min: 1, max: 31, value: 1, class: "rg-n" }), el("span", { class: "muted", text: "日（無い月は月末）" })),
        el("label", { class: "rg-f rg-m-nth" }, el("span", { text: "第" }), sel("nth", [1, 2, 3, 4, 5].map(n => opt(n, `第${n}`)).concat([opt(-1, "最終")])), sel("wd", [1, 2, 3, 4, 5, 6, 0].map(w => opt(w, `${WD[w]}曜日`)))),
        lab("休日に当たったら", sel("holiday", [opt("after", "次の稼働日へ", true), opt("before", "前の稼働日へ"), opt("skip", "その回は作らない"), opt("keep", "そのまま（休日に置く）")])),
        lab("1 回の日数", inp("dur", { type: "number", min: 1, max: 366, value: 1, class: "rg-n" }), sel("durUnit", [opt("work", "稼働日"), opt("cal", "日（休日も含む）")]))),
      el("fieldset", {}, el("legend", { text: "期間" }),
        lab("開始日", inp("from", { type: "text", placeholder: "yyyy/mm/dd", value: fmtDate(today), class: "rg-d" })),
        lab("終了日", inp("to", { type: "text", placeholder: "yyyy/mm/dd（空欄可）", value: "", class: "rg-d" })),
        lab("回数", inp("count", { type: "number", min: 1, max: RecurGen.LIMIT, value: 12, class: "rg-n" }), el("span", { class: "muted", text: "（両方あれば先に来たほう）" }))),
      el("fieldset", {}, el("legend", { text: "タスクの内容（各回に同じ値）" }),
        lab("定期グループ", inp("code", { type: "text", placeholder: "例 月次報告", value: "", class: "rg-g", list: "rg-codes", title: "同じ値の回をガントで 1 行にまとめます（自由な文字。この値がまとめ行の名前）" }),
          el("datalist", { id: "rg-codes" }, ...[...new Set(tasks.map(t => t.recur_group).filter(Boolean))].map(g => opt(g, g)))),  // 使っているグループから選べる
        lab("No. の開始", inp("no", { type: "number", min: 1, value: nextNo, class: "rg-n" })),
        lab("プロジェクト", sel("project", master("projects"))),
        lab("大項目", inp("level1", { type: "text" })), lab("中項目", inp("level2", { type: "text" })),
        lab("タスク名", inp("name", { type: "text", value: "定例（{date}）", title: "{date} = mm/dd、{ymd} = yyyy/mm/dd、{n} = 回の番号" })),
        lab("カテゴリ", sel("category", master("categories"))), lab("担当", sel("owner", master("owners"))),
        lab("稼働カレンダー", sel("calendar", [opt("", `空欄（既定: ${calOf({})}）`), ...CAL_OPTIONS.map(o => opt(o, o))])),
        el("label", { class: "rg-f rg-exwd" }, el("span", { text: "除外する曜日" }), inp("exwd", { type: "text", placeholder: `例 土日・日（空欄 = ${wdNorm(S.params?.exclude_weekdays_default) || "土日"}）`, class: "rg-c" })),
        lab("備考", inp("note", { type: "text" })))),
    err, prev,
    el("div", { class: "fd-row fd-actions" },
      el("button", { type: "button", class: "primary rg-dl", "data-enc": "utf8", text: "CSV ダウンロード（UTF-8）", onclick: () => download("utf8") }),
      el("button", { type: "button", class: "rg-dl", "data-enc": "sjis", text: "CSV（Shift_JIS）", onclick: () => download("sjis") }),
      el("button", { type: "button", text: "閉じる", onclick: shut })));
  const ov = el("div", { class: "modal-ov", onpointerdown: e => e.target === ov && shut() }, box);
  box.addEventListener("input", paint); box.addEventListener("change", paint);
  const unit = () => (box.querySelector(".rg-unit").textContent = { daily: "日ごと", weekly: "週ごと", monthly: "か月ごと" }[val("freq").value]);
  box.addEventListener("change", unit); unit();
  document.body.append(ov); document.addEventListener("keydown", esc, true);
  paint();
  return box;
};
window.openRecurDialog = openRecurDialog;
