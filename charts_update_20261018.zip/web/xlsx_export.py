"""Excel 出力: 利用者のテンプレート (web/excel/Progress_Sheet_template.xlsx) に行モデル (chart.py --dump-json) を流し込んで .xlsx を作る。
標準ライブラリだけ (zipfile ＋ 文字列の差し替え)。openpyxl などで保存し直さない (条件付き書式の拡張 extLst・データバー・webextensions が消えるため)。
条件付き書式は足さない: 範囲 (sqref) と式の中の列の文字だけを直す。1 タスク = 予定の行 ＋ 実績の行 (6 行目から 2 行ずつ)。
左の表の列は、ガントの一覧表示の設定 (gantt.js の ALL_COLS・flatDefault・ordered・defShown・colW) と同じ規則 (gantt_columns)。"""
import bisect
import datetime as dt
import io
import math
import re
import unicodedata
import zipfile
from itertools import accumulate
from pathlib import Path
from xml.sax.saxutils import escape

TEMPLATE = Path(__file__).resolve().parent / "excel" / "Progress_Sheet_template.xlsx"
SHEET_OF = {"week": ("sheet1", "スケジュール（週）", "rId1"), "month": ("sheet2", "スケジュール（月）", "rId2"), "year": ("sheet3", "スケジュール（年）", "rId3")}
HOLIDAY_SHEET = "休日"
EFFORT_KEYS, CALC_KEYS = ("actual_effort", "unit_price"), ("plan_effort", "plan_amount", "actual_amount")
# 一覧表示の組み込みの列: (キー, 見出し, 既定の幅 px, 一覧表示だけか)。gantt.js の ALL_COLS と同じ
BASE_COLS = [("no", "No.", 30, 0), ("level3", "タスク", 180, 0), ("project", "プロジェクト", 96, 1), ("level1", "大項目", 84, 1), ("level2", "中項目", 84, 1),
             ("plan_start", "予定開始", 72, 0), ("plan_end", "予定終了", 72, 0), ("pw", "稼働(予)", 40, 0), ("actual_start", "実績開始", 72, 0),
             ("actual_end", "実績終了", 72, 0), ("aw", "稼働(実)", 40, 0), ("progress", "進捗%", 42, 0), ("depends", "影響", 54, 0)]
PLAN_ONLY = {"plan_start", "plan_end", "pw", "progress", "cd", "plan_effort", "plan_amount", "unit_price", "__status", "__prog"}  # 予定の行だけ
ACTUAL_ONLY = {"actual_start", "actual_end", "aw", "actual_effort", "actual_amount"}  # 実績の行だけ (ほかは両方の行に同じ値)
DATE_KEYS = {"plan_start", "plan_end", "actual_start", "actual_end", "__start", "__end"}
NUM_KEYS = {"no", "pw", "aw", "cd", "progress", *EFFORT_KEYS, *CALC_KEYS}  # 数値の列 (最小幅 6 文字)
GRID_W = {"week": 6.25, "month": 6.625, "year": 6.25}  # 日付の列の幅 (テンプレートのまま)
HEAD_ST = {"week": {1: (16, 17, 18), 2: (19, 38, 20), 3: (21, 39, 22), 4: (23, 24, 3)}, "month": {1: (16, 17, 18), 2: (19, 38, 20), 3: (21, 39, 22), 4: (25, 26, 7)},
           "year": {1: (16, 17, 18), 2: (27, 28, 8)}}  # 日付の見出し (行 → 先頭・途中・最後の書式 s)
THICK_ROWS = {"week": {4, 5}, "month": {4, 5}, "year": {2, 4, 5}}  # テンプレートで太い下線 (高さ 19.5) の見出しの行
NEW_XFS = [(176, b) for b in (5, 8, 10, 7, 9, 1)]  # 日付の書式 + 左端・右端の罫線 (styles.xml に足す。42〜47)
RANGE_ST = 42 + len(NEW_XFS)  # 日付範囲の文字 (D3): 左揃え。右の E3・F3 が空なので結合せず、はみ出して表示される (styles.xml に足す。48)
iso_slash = lambda iso: iso.replace("-", "/")  # noqa: E731  2026-10-18 → 2026/10/18
TXT_ST = {"first": (14, 13, 15), "mid": (34, 9, 10), "last": (12, 11, 2)}  # 行の位置 → (途中の列, 左端, 右端) の書式 s
DAT_ST = {"first": (31, 42, 45), "mid": (40, 43, 46), "last": (32, 44, 47)}
CEN_ST = {"first": (29, 13, 15), "mid": (33, 9, 10), "last": (30, 11, 2)}
STATUS_LABEL = {"DONE": "完了", "HOLD": "保留", "STOP": "中止"}  # 状況のコード → テンプレートの「進捗入力」 (式が見る 3 つ)
MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

col_letter = lambda n: "" if n <= 0 else col_letter((n - 1) // 26) + chr(65 + (n - 1) % 26)  # noqa: E731  1 → A, 27 → AA
serial = lambda iso: (dt.date.fromisoformat(iso) - dt.date(1899, 12, 30)).days  # noqa: E731  Excel の日付 (シリアル値)
px_w = lambda px: round(max(2.0, (px - 5) / 7), 3)  # noqa: E731  px → 列幅 (文字数)
wide = lambda s: sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in s)  # noqa: E731  文字列の表示幅 (全角 = 2)


def col_width(c, is_date):
    """列幅 (文字数)。設定の px を基準に、Excel の文字は画面より大きいので ### や見出しの欠けが出ない最小幅を保つ (日付 11 文字・見出し + 1.5・No. など数値 6 文字)"""
    return round(max(px_w(c["w"]), 0 if not c["h"] else wide(c["h"]) + 1.5, 11 if is_date else 0, 6 if c["k"] in NUM_KEYS else 0), 3)


def _num(v):
    s = str(v if v is not None else "").strip()
    return float(s) if re.fullmatch(r"-?\d+(\.\d+)?", s) else 0.0  # JS の「+x || 0」


def _parse_w(v):
    """"key:px,key:px" → {key: px} (gantt.js の parseW)"""
    pairs = [(x[:x.rfind(":")], _num(x[x.rfind(":") + 1:])) for x in (v or "").split(",") if ":" in x]
    return {k: w for k, w in pairs if k and w > 0}


def gantt_columns(settings, columns_def, csv_keys, effort):
    """ガントの一覧表示の左の表の列 [{k, h, w(px), x(追加の列か)}]。設定: gantt_flat・gantt_flat_col_order・gantt_col_order・gantt_shown・gantt_hidden・gantt_widths と
    列定義の gantt_width・gantt_flat_order・gantt_flat_visible (gantt.js の colsNow と同じ。追加の列の元は grid_col_order・grid_widths 順のタスク表の列)"""
    flat = settings.get("gantt_flat") == "on"
    lst = lambda k: [x for x in (settings.get(k) or "").split(",") if x]  # noqa: E731
    cdef = dict(reversed([(c["key"], c) for c in columns_def if c.get("key")]))  # 同じキーは先のもの
    sch = sorted(columns_def, key=lambda c: _num(c.get("order")))  # 並び順 → 列定義の位置 (sorted は安定)
    spec = [dict(k=c["key"], h=c.get("label") or c["key"], w=int(_num(c.get("width"))) or None) for i, c in enumerate(sch)
            if c.get("key") and c.get("visible") != "no" and next(j for j, x in enumerate(sch) if x.get("key") == c["key"]) == i]  # タスク表の列 (表に出さない列は除く)
    spec += [dict(k=k, h=k, w=110) for k in dict.fromkeys(csv_keys) if k not in cdef and k != "_rid"] + [dict(k="cd", h="日数(予)", w=None)]  # CSV にだけある列・日数(予)
    order, vw = lst("grid_col_order"), _parse_w(settings.get("grid_widths"))
    rank = lambda p: order.index(p[1]["k"]) if p[1]["k"] in order else len(order) + p[0]  # noqa: E731
    spec = [dict(c, w=vw[c["k"]]) if vw.get(c["k"]) else c for _, c in sorted(enumerate(spec), key=rank)]
    builtin = {c[0] for c in BASE_COLS} | set(EFFORT_KEYS) | set(CALC_KEYS)
    extras = [dict(k=c["k"], h=c["h"], w0=min(max(c["w"] or 90, 50), 200), x=True) for c in spec if c["k"] not in builtin] if flat else []
    base = [dict(k=k, h=h, w0=w0, flat=bool(f), must=k == "level3") for k, h, w0, f in BASE_COLS]
    eff = [dict(k=k, h=cdef.get(k, {}).get("label") or k, w0=78, eff=True) for k in (*EFFORT_KEYS, *CALC_KEYS)]
    all_ = base + extras + eff
    fo = lambda c: _num(cdef.get(c["k"], {}).get("gantt_flat_order"))  # noqa: E731
    flat_default = [c for _, c in sorted(enumerate(all_), key=lambda p: (fo(p[1]) or p[0] + 1, 0 if fo(p[1]) else 1, p[0]))]  # 並び: 列定義の gantt_flat_order (空欄は通常の位置。同じ位置なら指定した列が先)
    order2, lst_ = lst("gantt_flat_col_order" if flat else "gantt_col_order"), (flat_default if flat else all_)
    ordered = sorted(lst_, key=lambda c: order2.index(c["k"]) if c["k"] in order2 else len(order2) + lst_.index(c))

    def shown(c):  # 必須 → 隠した → 出した → 既定 (一覧表示: 列定義の gantt_flat_visible、空欄なら組み込みの列だけ)
        gv = cdef.get(c["k"], {}).get("gantt_flat_visible") if flat else ""
        dflt = True if gv == "yes" else False if gv == "no" else not c.get("x")
        return bool(c.get("must")) or (c["k"] not in lst("gantt_hidden") and (c["k"] in lst("gantt_shown") or dflt))
    wm = _parse_w(settings.get("gantt_widths"))
    return [dict(k=c["k"], h=c["h"], x=bool(c.get("x")), w=wm.get(c["k"]) or int(_num(cdef.get(c["k"], {}).get("gantt_width"))) or c["w0"])
            for c in ordered if shown(c) and (not c.get("flat") or flat) and (not c.get("eff") or effort)]


# ---------------- セルの値 ----------------
_d = lambda iso: ("d", serial(iso)) if iso else None  # noqa: E731
_s = lambda v: ("s", str(v)) if v not in (None, "") else None  # noqa: E731
_i = lambda v: ("n", v) if v is not None else None  # noqa: E731


def _money(s):
    s2 = str(s or "").replace(",", "")
    return ("n", float(s2)) if re.fullmatch(r"-?\d+(\.\d+)?", s2) else None


def _status_label(r):  # 完了・保留・中止だけテンプレートの式が見る。コードで見て、無ければ名前
    st = r["status"]
    return STATUS_LABEL.get(st["code"]) or (st["name"] if st["name"] in STATUS_LABEL.values() else "")


VAL = {  # 列キー → (side, 行モデル, タスク(親は None), 共通) → ("s"|"n"|"d", 値) か None
    "kubun": lambda s, r, t, X: ("s", "予定" if s == "plan" else "実績"),
    "no": lambda s, r, t, X: ("n", int(r["no"])) if str(r.get("no") or "").isdigit() else _s(r.get("no")),
    "level3": lambda s, r, t, X: ("s", X["indent"](r) + r["name"]),
    "project": lambda s, r, t, X: _s(X["masters"].get("projects", {}).get(t.get("project"), t.get("project"))) if t else None,
    "level1": lambda s, r, t, X: _s(t.get("level1")) if t else None,
    "level2": lambda s, r, t, X: _s(t.get("level2")) if t else None,
    "plan_start": lambda s, r, t, X: _d(r["plan"]["start"]),
    "plan_end": lambda s, r, t, X: None if r["plan"]["open"] else _d(r["plan"]["end"]),  # 完了日未定は空欄 (バーは補助列の基準日まで)
    "pw": lambda s, r, t, X: _i(r["plan"]["days"]),
    "cd": lambda s, r, t, X: ("n", (dt.date.fromisoformat(r["plan"]["end"]) - dt.date.fromisoformat(r["plan"]["start"])).days + 1) if r["plan"]["start"] and r["plan"]["end"] else None,
    "actual_start": lambda s, r, t, X: _d(r["actual"]["start"]),
    "actual_end": lambda s, r, t, X: ("s", "進行中") if r["actual"]["running"] else (_d(r["actual"]["end"]) if r["actual"]["done"] else None),
    "aw": lambda s, r, t, X: _i(r["actual"]["days"]),
    "progress": lambda s, r, t, X: ("n", math.floor(r["plan"]["progress"] + 0.5)),  # JS の Math.round と同じ (.5 は切り上げ)
    "depends": lambda s, r, t, X: _s(t.get("depends")) if t else None,
    "__start": lambda s, r, t, X: _d(r["plan"]["start"] if s == "plan" else r["actual"]["start"]),  # 式が見る補助列 (非表示): 予定の行は予定、実績の行は実績の日付
    "__end": lambda s, r, t, X: _d(r["plan"]["end"] if s == "plan" else r["actual"]["end"]),  # 実績が進行中なら基準日まで
    "__status": lambda s, r, t, X: _s(_status_label(r)),
    "__prog": lambda s, r, t, X: ("n", math.floor(r["plan"]["progress"] + 0.5)),
}
VAL |= {k: (lambda s, r, t, X, k=k: _money((r.get("effort") or {}).get(k))) for k in (*EFFORT_KEYS, *CALC_KEYS)}


def _extra(k, t, X):
    """一覧表示の追加の列 (読み取りだけ。親の行は空欄): マスタは名前、日付は日付、数値は数値"""
    v = str((t or {}).get(k) or "").strip()
    typ = X["cdef"].get(k, {}).get("type", "")
    return (None if not v else ("s", X["masters"].get(typ[5:], {}).get(v, v)) if typ.startswith("code:")
            else ("d", serial(v)) if typ == "date" and re.fullmatch(r"\d{4}-\d{2}-\d{2}", v)
            else ("n", float(v.replace(",", ""))) if typ in ("int", "number", "percent") and re.fullmatch(r"-?[\d,]*\.?\d+", v)
            else ("s", {"1": "はい", "0": "いいえ"}.get(v, v)) if typ == "bool" else ("s", v))


def cell_value(k, side, r, t, X):
    if (side == "actual" and k in PLAN_ONLY) or (side == "plan" and k in ACTUAL_ONLY):
        return None
    return VAL[k](side, r, t, X) if k in VAL else (_extra(k, t, X) if k in X["extras"] else None)


# ---------------- XML の部品 ----------------
def _text(v):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]", "", str(v).replace("\r\n", "\n").replace("\r", "\n"))


def _c(ref, st, v=None):
    if v is None:
        return f'<c r="{ref}" s="{st}"/>'
    kind, x = v
    if kind == "s":
        return f'<c r="{ref}" s="{st}" t="inlineStr"><is><t xml:space="preserve">{escape(_text(x))}</t></is></c>'
    return f'<c r="{ref}" s="{st}"><v>{x if isinstance(x, int) else format(x, ".15g")}</v></c>'


def _row(n, cells, kind="plain"):
    attrs = {"plain": 'x14ac:dyDescent="0.4"', "thick": 'ht="19.5" thickBot="1" x14ac:dyDescent="0.45"'}[kind]
    return f'<row r="{n}" {attrs}>{"".join(cells)}</row>' if cells else f'<row r="{n}" {attrs}/>'


def grid_dates(model):
    """日付の列: 週シート = 日ごと / 月シート = 週ごと (月曜始まり) / 年シート = 月ごと (1 日)"""
    a, b = (dt.date.fromisoformat(model["window"][k]) for k in ("start", "end"))
    if model["step"] == "day":
        return [a + dt.timedelta(n) for n in range((b - a).days + 1)]
    if model["step"] == "week":
        m = a - dt.timedelta(a.weekday())
        return [m + dt.timedelta(7 * n) for n in range((b - m).days // 7 + 1)]
    return [dt.date(y + m // 12, m % 12 + 1, 1) for y, m in [divmod(a.year * 12 + a.month - 1 + n, 12) for n in range((b.year * 12 + b.month) - (a.year * 12 + a.month) + 1)]]


def _holiday_sheet(model):
    """隠しシート「休日」: 休日_曜日設定 (B2:B8)・休日_週末パターン (D2)・祝日リスト (F)・祝日名称 (G)。出勤日は祝日リストから外す"""
    wk, work = set(model["weekend"]), set(model["work"])
    hol = sorted({h["date"]: h["name"] for h in model["holidays"] if h["date"] not in work}.items())
    n = max(8, 1 + len(hol))
    head = {1: [("A", ("s", "曜日"), 0), ("B", ("s", "休日"), 0), ("D", ("s", "週末パターン"), 0), ("F", ("s", "祝日"), 0), ("G", ("s", "名称"), 0)]}
    cells = {r: head.get(r, []) + ([("A", ("s", "月火水木金土日"[r - 2]), 0)] + ([("B", ("s", "休み"), 0)] if r - 2 in wk else []) if 2 <= r <= 8 else [])
             + ([("D", ("s", "".join("1" if i in wk else "0" for i in range(7))), 0)] if r == 2 else [])
             + ([("F", ("d", serial(hol[r - 2][0])), 1), ("G", ("s", hol[r - 2][1]), 0)] if 0 <= r - 2 < len(hol) else []) for r in range(1, n + 1)}  # 1 行目は見出し (hol[-1] を拾って F1・G1 が二重になるのを防ぐ)
    rows = "".join(f'<row r="{r}">{"".join(_c(f"{c}{r}", st, v) for c, v, st in cs)}</row>' for r, cs in cells.items())
    xml = f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="{MAIN_NS}"><cols><col min="1" max="7" width="14" customWidth="1"/></cols><sheetData>{rows}</sheetData></worksheet>'
    return xml, max(1, len(hol))


def _app_xml(src, sheets, names):
    vec = "".join(f"<vt:lpstr>{escape(n)}</vt:lpstr>" for n in [*sheets, *names])
    src = re.sub(r"<HeadingPairs>.*?</HeadingPairs>", f'<HeadingPairs><vt:vector size="4" baseType="variant"><vt:variant><vt:lpstr>ワークシート</vt:lpstr></vt:variant><vt:variant><vt:i4>{len(sheets)}</vt:i4></vt:variant>'
                 f'<vt:variant><vt:lpstr>名前付き一覧</vt:lpstr></vt:variant><vt:variant><vt:i4>{len(names)}</vt:i4></vt:variant></vt:vector></HeadingPairs>', src, flags=re.S)
    return re.sub(r"<TitlesOfParts>.*?</TitlesOfParts>", lambda m: f'<TitlesOfParts><vt:vector size="{len(sheets) + len(names)}" baseType="lpstr">{vec}</vt:vector></TitlesOfParts>', src, flags=re.S)


def _fix_cf(x, P):
    """条件付き書式: 範囲 (sqref) を広げ、式の中の列の文字 ($B/$C/$G/$H・$C$2/$D$2・N$1) を付け替える。規則は足さない・消さない"""
    sub = {"$B6": f"${P['b']}6", "$C6": f"${P['c']}6", "$G6": f"${P['g']}6", "$H6": f"${P['h']}6"}
    roles = lambda f: re.sub(r"\$[BCGH]6(?!\d)", lambda m: sub[m.group()], f).replace("$C$2", "$F$2").replace("$D$2", "$G$2")  # noqa: E731
    plain_h = lambda f: re.sub(r"(?<![A-Za-z$])H6(?!\d)", f"{P['h']}6", f)  # noqa: E731
    first_col = lambda f: re.sub(r"(?<![A-Za-z])N\$1", f"{P['g0']}$1", f)  # noqa: E731
    on_formula = lambda fn, body: re.sub(r"<formula>(.*?)</formula>", lambda m: f"<formula>{fn(m.group(1))}</formula>", body, flags=re.S)  # noqa: E731

    def one(m):
        sq, body = m.group(1), m.group(2)
        new, body = (f"A6:{P['left']}{P['R']}", on_formula(roles, body)) if sq.startswith("A6:") else \
                    (f"B6:{P['gN']}{P['R']}", on_formula(roles, body)) if sq.startswith("B6:") else \
                    (f"{P['h']}6:{P['h']}{P['R']}", body if "dataBar" in body else on_formula(plain_h, body)) if sq.startswith("H6:") else \
                    (f"{P['g0']}1:{P['gN']}1048576", on_formula(first_col, body))
        return f'<conditionalFormatting sqref="{new}">{body}</conditionalFormatting>'
    x = re.sub(r'<conditionalFormatting sqref="([^"]+)">(.*?)</conditionalFormatting>', one, x, flags=re.S)
    return x.replace("<xm:sqref>H6:H7</xm:sqref>", f"<xm:sqref>{P['h']}6:{P['h']}{P['R']}</xm:sqref>")  # x14 のデータバーの範囲


EMU = 9525  # 1px (倍率 100%)
col_px = lambda w: int((256 * w + 16) / 32)  # noqa: E731  列幅 (文字数) → px。既定フォントの最大数字幅 8 (游ゴシック 11): テンプレートの日付の列 6.25 → 50px = 476250 EMU (シェイプの線の幅と同じ)


def _lightning(tpl, model, xs, cpx, L, dates, R, rng, line_w):
    """イナズマ線のオートシェイプ (drawing の XML)。テンプレートの「イナズマ線シェイプ」と同じグループ: 点 = ellipse (イナズマ線_P{n})、線 = cxnSp (イナズマ線_L{n} = 前の点 (最初は見出しの下の今日の線) → この点)、
    最後に今日の線へ戻る線。点は予定の行の縦の中心 (タスクごと。間隔は 2 行)。x は xs (Excel のシリアル値。今日の線のままの行は今日の位置)。今日が表示期間の外なら描かない (PDF と同じ)"""
    nxt = {"day": lambda d: d + dt.timedelta(1), "week": lambda d: d + dt.timedelta(7), "month": lambda d: (d.replace(day=28) + dt.timedelta(4)).replace(day=1)}[model["step"]]
    bounds = [serial(d.isoformat()) for d in dates] + [serial(nxt(dates[-1]).isoformat())]  # 日付の列の境目 (シリアル値)
    today = serial(model["today"]) + 0.5
    if not bounds[0] <= today <= bounds[-1]:
        return None
    lefts = [0, *accumulate(cpx)]  # 列の左端 (px)
    hts = [0, *accumulate(26 if (n in THICK_ROWS[rng] or n == R) else 25 for n in range(1, R + 1))]  # 行の上端 (px): hts[n - 1] = 行 n の上端 (太い下線の行は 19.5pt = 26px)

    def xpx(d):  # シリアル値 → px (列の中は日・週・月の割合。期間の外は端に寄せる)
        d = min(max(d, bounds[0]), bounds[-1])
        i = min(bisect.bisect_right(bounds, d) - 1, len(dates) - 1)
        return lefts[L + i] + (d - bounds[i]) / (bounds[i + 1] - bounds[i]) * cpx[L + i]
    emu = lambda v: round(v * EMU)  # noqa: E731
    today_x = emu(xpx(today))
    pts = [(emu(xpx(x)), emu(hts[5 + 2 * k] + 12.5)) for k, x in enumerate(xs)]  # 予定の行 (6 + 2k 行) の縦の中心
    segs = [(today_x, emu(hts[4] + 13), *pts[0])] + [(*a, *b) for a, b in zip(pts, pts[1:])] + [(*pts[-1], today_x, emu(hts[R]))]  # 見出し(5 行目の中ほど) → 各点 → 表の下端
    sp_t = re.search(r'<xdr:sp macro="" textlink="">.*?</xdr:sp>', tpl, re.S).group(0)
    cx_t = re.search(r'<xdr:cxnSp macro="">.*?</xdr:cxnSp>', tpl, re.S).group(0)
    named = lambda t, i, name: re.sub(r"<xdr:cNvPr .*?</xdr:cNvPr>", lambda m: f'<xdr:cNvPr id="{i}" name="{name}"/>', t, count=1, flags=re.S)  # noqa: E731
    xfrm = lambda t, tag: re.sub(r"<a:xfrm.*?</a:xfrm>", lambda m: tag, t, count=1, flags=re.S)  # noqa: E731

    def line(i, n, x1, y1, x2, y2):  # 線 L{n}: 左上 → 右下 (左下へ向かう線は flipH)
        t = xfrm(named(cx_t, i, f"イナズマ線_L{n}"), f'<a:xfrm{" flipH=" + chr(34) + "1" + chr(34) if x2 < x1 else ""}><a:off x="{min(x1, x2)}" y="{y1}"/><a:ext cx="{abs(x2 - x1)}" cy="{y2 - y1}"/></a:xfrm>')
        return re.sub(r'<a:ln w="\d+">', f'<a:ln w="{line_w}">', t, count=1)

    def dot(i, n, x, y):  # 点 P{n}: 76200 EMU (8px) の円
        return xfrm(named(sp_t, i, f"イナズマ線_P{n}"), f'<a:xfrm><a:off x="{x - 38100}" y="{y - 38100}"/><a:ext cx="76200" cy="76200"/></a:xfrm>')
    kids = [s for k, (sg, p) in enumerate(zip(segs, pts)) for s in (line(3 + 2 * k, k + 1, *sg), dot(4 + 2 * k, k + 1, *p))] + [line(3 + 2 * len(pts), len(pts) + 1, *segs[-1])]
    xs_all = [v for sg in segs for v in (sg[0], sg[2])] + [p[0] + d for p in pts for d in (-38100, 38100)]
    ys_all = [v for sg in segs for v in (sg[1], sg[3])] + [p[1] + d for p in pts for d in (-38100, 38100)]
    x0, y0, x1, y1 = min(xs_all), min(ys_all), max(xs_all), max(ys_all)
    cum_c, cum_r = [emu(v) for v in lefts], [emu(v) for v in hts]

    def anchor(tag, xe, ye):
        c, r = min(bisect.bisect_right(cum_c, xe) - 1, len(cpx) - 1), bisect.bisect_right(cum_r, ye) - 1
        return f"<xdr:{tag}><xdr:col>{c}</xdr:col><xdr:colOff>{xe - cum_c[c]}</xdr:colOff><xdr:row>{r}</xdr:row><xdr:rowOff>{ye - cum_r[r]}</xdr:rowOff></xdr:{tag}>"
    box = f'<a:off x="{x0}" y="{y0}"/><a:ext cx="{x1 - x0}" cy="{y1 - y0}"/>'
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
            f'<xdr:twoCellAnchor>{anchor("from", x0, y0)}{anchor("to", x1, y1)}<xdr:grpSp><xdr:nvGrpSpPr><xdr:cNvPr id="2" name="イナズマ線シェイプ"/><xdr:cNvGrpSpPr/></xdr:nvGrpSpPr>'
            f'<xdr:grpSpPr><a:xfrm>{box}<a:chOff x="{x0}" y="{y0}"/><a:chExt cx="{x1 - x0}" cy="{y1 - y0}"/></a:xfrm></xdr:grpSpPr>{"".join(kids)}</xdr:grpSp><xdr:clientData/></xdr:twoCellAnchor></xdr:wsDr>')


def build_xlsx(model, settings, columns_def, tasks, masters, csv_keys, title="", effort=False, template=TEMPLATE, inazuma_px=None):
    """行モデル → .xlsx のバイト列。model = chart.py --dump-json (工数・金額の列を出すなら --columns に入れて作る)。
    settings = 画面の設定 (gantt_* と gantt_flat)・columns_def = 列定義の行・tasks = タスクの行 (read_rows)・masters = {マスタ名: {コード: 名前}}・csv_keys = タスク CSV の見出し"""
    rng = model["range"]
    part, sheet_name, rid = SHEET_OF[rng]
    flat = settings.get("gantt_flat") == "on"
    cdef = dict(reversed([(c["key"], c) for c in columns_def if c.get("key")]))
    vis = [c for v in gantt_columns(settings, columns_def, csv_keys, effort) for c in ([v, dict(k="kubun", h="区分", w=48, x=False)] if v["k"] == "level3" else [v])]  # 区分 (予定／実績) はタスクの右
    vis += [dict(k=f"__pad{i}", h="", w=24, x=False) for i in range(max(0, 7 - len(vis)))]  # 題名・日付範囲・イナズマ線・休日除外 (A〜G) を置くため 7 列まで
    has_prog = any(c["k"] == "progress" for c in vis)
    helpers = [dict(k="__start", h="開始日", w=72), dict(k="__end", h="完了日", w=72), dict(k="__status", h="進捗入力", w=60), *([] if has_prog else [dict(k="__prog", h="進捗率", w=50)])]
    cols = vis + [dict(h_, x=False, hidden=True) for h_ in helpers]
    L, nvis = len(cols), len(vis)
    letter = {c["k"]: col_letter(i + 1) for i, c in enumerate(cols)}
    dates = grid_dates(model)
    g0, gN = col_letter(L + 1), col_letter(L + len(dates))
    rows = [r for r in model["rows"] if r["leaf"] or r["recur"]] if flat else model["rows"]
    R = 5 + 2 * len(rows)
    lvl0 = min(r["level"] for r in rows)
    by_no = {str(t.get("no", "")).strip(): t for t in tasks}
    X = dict(masters=masters, cdef=cdef, extras={c["k"] for c in vis if c["x"]}, indent=(lambda r: "" if flat else "　" * (r["level"] - lvl0)))
    date_col = lambda c: c["k"] in DATE_KEYS or (c["x"] and cdef.get(c["k"], {}).get("type") == "date")  # noqa: E731
    P = dict(b=letter["__start"], c=letter["__end"], g=letter["__status"], h=letter["progress" if has_prog else "__prog"], g0=g0, gN=gN, left=col_letter(L), R=R)

    # --- 見出し (1〜5 行目) ---
    ctl = {1: [("A", 41, "題名"), ("B", 41, None), ("C", 41, None), ("D", 41, "日付範囲"), ("E", 41, None), ("F", 35, "イナズマ線"), ("G", 35, "休日除外")],
           2: [("A", 41, None), ("B", 41, None), ("C", 41, None), ("D", 35, None), ("E", 35, None), ("F", 35, "表示" if model["inazuma"] else "非表示"), ("G", 35, "除外する" if model["workdays"] else "除外しない")]}
    ctl_v = {("A", 1): title, ("A", 3): "基準日 " + model["today"].replace("-", "/")}
    top = {n: [_c(f"{c}{n}", st, ("s", ctl_v.get((c, n), t)) if (ctl_v.get((c, n), t)) else None) for c, st, t in ctl.get(n, [])] for n in (1, 2)}
    top[3] = [_c("A3", 37, ("s", ctl_v[("A", 3)])), _c("B3", 37), _c("C3", 37), _c("D3", RANGE_ST, ("s", f"{iso_slash(model['window']['start'])} ～ {iso_slash(model['window']['end'])}")), _c("E3", 37), _c("F3", 37), _c("G3", 37)]
    pick = lambda i, n: 0 if n == 1 or i == 0 else 2 if i == n - 1 else 1  # noqa: E731  先頭・途中・最後
    head_grid = {n: [_c(f"{col_letter(L + 1 + i)}{n}", HEAD_ST[rng][n][pick(i, len(dates))],
                        ("s", f"第{(d.day - 1) // 7 + 1}週") if (rng == "month" and n == 4) else ("d", serial(d.isoformat()))) for i, d in enumerate(dates)] for n in HEAD_ST[rng]}
    head_rows = [_row(n, top.get(n, []) + head_grid.get(n, []), "thick" if n in THICK_ROWS[rng] else "plain") for n in (1, 2, 3, 4)]
    hdr = [_c(f"{letter[c['k']]}5", 4 if i == 0 else 6 if i == nvis - 1 else 5, ("s", c["h"]) if c["h"] else None) for i, c in enumerate(cols)]
    head_rows.append(_row(5, hdr, "thick"))

    # --- データの行 (1 タスク = 予定の行 + 実績の行) ---
    def style(kind, i, c):
        tbl = DAT_ST if date_col(c) else CEN_ST if c["k"] == "__status" else TXT_ST
        mid, left, right = tbl[kind]
        return left if i == 0 else right if i == nvis - 1 else mid
    grid_st = {kind: [(col_letter(L + 1 + i), TXT_ST[kind][2] if (i == len(dates) - 1 and len(dates) > 1) else TXT_ST[kind][0]) for i in range(len(dates))] for kind in TXT_ST}
    body = []
    for k, r in enumerate(rows):
        t = by_no.get(str(r.get("no") or "").strip()) if r["leaf"] else None
        for side, n in (("plan", 6 + 2 * k), ("actual", 7 + 2 * k)):
            kind = "first" if n == 6 else "last" if n == R else "mid"
            left = [_c(f"{letter[c['k']]}{n}", style(kind, i, c), cell_value(c["k"], side, r, t, X)) for i, c in enumerate(cols)]
            body.append(_row(n, left + [f'<c r="{gc}{n}" s="{st}"/>' for gc, st in grid_st[kind]], "thick" if n == R else "plain"))
    sheet_data = "<sheetData>" + "".join(head_rows) + "".join(body) + "</sheetData>"

    # --- 名前定義 (テンプレートの名前を出力シートの範囲へ。親ID は出さない。アプリに無い列の名前は付けない) ---
    q = f"'{sheet_name}'!"
    role_key = {"Id": "no", "StartDate": "__start", "EndDate": "__end", "Days": "pw", "Priority": "priority", "ProgressInput": "__status", "Progress": "progress" if has_prog else "__prog",
                "ProjectName": "project", "Status": "status", "TaskName": "level3", "AssignedTo": "owner", "Column13": next((c["k"] for c in cols if c["h"] == "版数"), "")}
    names = {f"{p}_{role}": (f"${letter[key]}$5" if p == "Header" else f"${letter[key]}$6:${letter[key]}${R}")
             for role, key in role_key.items() if key in letter for p in ("Header", "Input")}
    names |= {"DateInputArea": "$D$1:$G$3", "DateInputCells": f"${P['b']}$6:${P['c']}${R + 4}", "DateInputValues": "$D$3", "DateRangeTitle": "$D$1",
              "FilterDataRange": f"$A$5:${gN}${R}", "GanttArea": f"$A$6:${gN}${R}", "HeaderRow": f"$A$5:${P['left']}$5", "HolidaySwitch": "$G$2", "InazumaSwitch": "$F$2",
              "InputTableArea": f"$A$5:${P['left']}${R}", "カレンダー": f"${g0}$1:${gN}$2"}
    hsheet, hn = _holiday_sheet(model)
    hq = f"'{HOLIDAY_SHEET}'!"
    glob = {"休日_曜日設定": f"{hq}$B$2:$B$8", "休日_週末パターン": f"{hq}$D$2", "祝日リスト": f"{hq}$F$2:$F${1 + hn}", "祝日名称": f"{hq}$G$2:$G${1 + hn}"}
    allnames = sorted({**{n: q + v for n, v in names.items()}, **glob}.items(), key=lambda p: p[0].lower())
    defined = ("<definedNames>" + f'<definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">{escape(q)}$A$5:${gN}${R}</definedName>'
               + "".join(f'<definedName name="{n}">{escape(v)}</definedName>' for n, v in allnames) + "</definedNames>")

    # --- 出力シート ---
    wch = [col_width(c, date_col(c)) for c in cols]
    widths = "".join(f'<col min="{i + 1}" max="{i + 1}" width="{w}" customWidth="1"{" hidden=" + chr(34) + "1" + chr(34) if c.get("hidden") else ""}/>' for i, (c, w) in enumerate(zip(cols, wch)))
    cpx = [0 if c.get("hidden") else col_px(w) for c, w in zip(cols, wch)] + [col_px(GRID_W[rng])] * len(dates)  # 全部の列の幅 (px。非表示は 0) = シェイプの座標の元
    xs = [r["inazuma_x"] + 25569 if r["inazuma_x"] is not None else serial(model["today"]) + 0.5 for r in rows]  # 点の x (1970-01-01 の日数 → シリアル値。今日の線のままの行は今日の位置)
    cols_xml = f'<cols>{widths}<col min="{L + 1}" max="{L + len(dates)}" width="{GRID_W[rng]}" customWidth="1"/></cols>'
    dv = ('<dataValidations count="3"><dataValidation type="list" allowBlank="1" showInputMessage="1" showErrorMessage="1" sqref="F2"><formula1>"表示,非表示"</formula1></dataValidation>'
          '<dataValidation type="list" allowBlank="1" showInputMessage="1" showErrorMessage="1" sqref="G2"><formula1>"除外する,除外しない"</formula1></dataValidation>'
          f'<dataValidation type="list" allowBlank="1" showInputMessage="1" sqref="{P["g"]}6:{P["g"]}{R}"><formula1>"着手,中盤,終盤,仕上げ,完了,保留,中止"</formula1></dataValidation></dataValidations>')
    with zipfile.ZipFile(template) as zin:
        x = zin.read(f"xl/worksheets/{part}.xml").decode("utf-8")
        sub = lambda pat, new, s, **kw: re.sub(pat, lambda m: new, s, **kw)  # noqa: E731  (置き換えの文字列を正規表現として読ませない)
        x = sub(r'<dimension ref="[^"]*"/>', f'<dimension ref="A1:{gN}{R}"/>', x)
        x = sub(r"<sheetView [^>]*>", '<sheetView tabSelected="1" zoomScale="100" zoomScaleNormal="100" workbookViewId="0">', x, count=1)  # 倍率 100%
        x = sub(r"<pane [^>]*/>(<selection [^>]*/>)+", '<pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="D6" sqref="D6"/>', x, count=1)  # 見出しの 5 行だけ固定 (列の固定は利用者が出力後に自分でする)
        x = sub(r"<cols>.*?</cols>", cols_xml, x, flags=re.S)
        x = sub(r"<sheetData>.*?</sheetData>", sheet_data, x, flags=re.S)
        x = re.sub(r'(<autoFilter ref=")[^"]*(")', lambda m: f"{m.group(1)}A5:{gN}{R}{m.group(2)}", x)
        x = sub(r"<mergeCells.*?</mergeCells>", '<mergeCells count="2"><mergeCell ref="A1:C2"/><mergeCell ref="A3:C3"/></mergeCells>', x, flags=re.S)
        x = sub(r"<dataValidations.*?</dataValidations>", dv, x, flags=re.S)
        drawing = _lightning(zin.read(f"xl/drawings/drawing{part[-1]}.xml").decode("utf-8"), model, xs, cpx, L, dates, R, rng, round((inazuma_px or 3.0) * EMU)) if model["inazuma"] and rows else None
        x = x if drawing else sub(r'<drawing r:id="[^"]*"/>', "", x)  # イナズマ線オフ (または今日が期間の外) ならテンプレートの見本のシェイプごと外す。あれば drawing を差し替える
        x = _fix_cf(x, P)
        parts = {f"xl/worksheets/{part}.xml": x}
        wb = zin.read("xl/workbook.xml").decode("utf-8")
        wb = sub(r"<sheets>.*?</sheets>", f'<sheets><sheet name="{sheet_name}" sheetId="2" r:id="{rid}"/><sheet name="{HOLIDAY_SHEET}" sheetId="5" state="hidden" r:id="rId7"/></sheets>', wb, flags=re.S)
        parts["xl/workbook.xml"] = sub(r"<definedNames>.*?</definedNames>", defined, wb, flags=re.S)
        rels = zin.read("xl/_rels/workbook.xml.rels").decode("utf-8")
        rels = re.sub(r'<Relationship Id="rId\d+" Type="[^"]*/worksheet" Target="worksheets/sheet(\d)\.xml"/>', lambda m: m.group(0) if f"sheet{m.group(1)}" == part else "", rels)
        parts["xl/_rels/workbook.xml.rels"] = rels.replace("</Relationships>", f'<Relationship Id="rId7" Type="{REL_NS}/worksheet" Target="worksheets/sheet4.xml"/></Relationships>')
        ct = zin.read("[Content_Types].xml").decode("utf-8")
        ct = re.sub(r'<Override PartName="/xl/drawings/drawing(\d)\.xml"[^>]*/>', lambda m: m.group(0) if drawing and m.group(1) == part[-1] else "", ct)
        ct = re.sub(r'<Override PartName="/xl/worksheets/sheet(\d)\.xml"[^>]*/>', lambda m: m.group(0) if f"sheet{m.group(1)}" == part else "", ct)
        parts["[Content_Types].xml"] = ct.replace("</Types>", '<Override PartName="/xl/worksheets/sheet4.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        parts["docProps/app.xml"] = _app_xml(zin.read("docProps/app.xml").decode("utf-8"), [sheet_name, HOLIDAY_SHEET], [n for n, _ in allnames])
        st = zin.read("xl/styles.xml").decode("utf-8")
        xfs = "".join(f'<xf numFmtId="{f}" fontId="0" fillId="0" borderId="{b}" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' for f, b in NEW_XFS)
        xfs += '<xf numFmtId="0" fontId="0" fillId="0" borderId="13" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>'
        parts["xl/styles.xml"] = st.replace('<cellXfs count="42">', f'<cellXfs count="{RANGE_ST + 1}">').replace("</cellXfs>", xfs + "</cellXfs>")
        srels = zin.read(f"xl/worksheets/_rels/{part}.xml.rels").decode("utf-8")
        parts[f"xl/worksheets/_rels/{part}.xml.rels"] = srels if drawing else re.sub(r'<Relationship Id="[^"]*" Type="[^"]*/drawing" Target="[^"]*"/>', "", srels)
        drawing and parts.update({f"xl/drawings/drawing{part[-1]}.xml": drawing})
        parts["xl/worksheets/sheet4.xml"] = hsheet
        drop = {f"xl/worksheets/{p}.xml" for p, _, _ in SHEET_OF.values() if p != part} | {f"xl/worksheets/_rels/{p}.xml.rels" for p, _, _ in SHEET_OF.values() if p != part}
        drop |= {f"xl/drawings/drawing{i}.xml" for i in (1, 2, 3) if not (drawing and str(i) == part[-1])} | ({"xl/printerSettings/printerSettings1.bin"} if part != "sheet1" else set())
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
            [zout.writestr(i, parts.pop(i.filename, None) or zin.read(i.filename)) for i in zin.infolist() if i.filename not in drop]
            [zout.writestr(n, v) for n, v in parts.items()]  # 新しい部品 (sheet4)
    return buf.getvalue()
