#!/usr/bin/env python3
"""CSV からグラフを生成する CLI。

種類: gantt / bar / stacked / combo
例:  python3 chart.py bar samples/sales.csv -o out/bar.png --title "月別売上"
"""
import argparse
import csv
import re
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import font_manager
import numpy as np
import pandas as pd

JP_FONT_CANDIDATES = [  # 先に見つかったものを使う
    "Noto Sans CJK JP", "IPAexGothic", "IPAGothic", "TakaoGothic",       # Linux
    "Yu Gothic", "Meiryo", "BIZ UDGothic", "MS Gothic", "MS PGothic",   # Windows (游ゴシック・メイリオ・BIZ UD・MS ゴシック)
    "Hiragino Sans", "Noto Sans JP",                                     # macOS など
]


def setup_japanese_font():
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in JP_FONT_CANDIDATES:
        if name in available:
            plt.rcParams["font.family"] = name
            break
    else:
        try:
            import japanize_matplotlib  # noqa: F401
        except ImportError:
            print("警告: 日本語フォントが見つかりません (Windows: 游ゴシック/メイリオ/MS ゴシック、Linux: fonts-noto-cjk を入れてください)",
                  file=sys.stderr)
    plt.rcParams["axes.unicode_minus"] = False


def _csv_text(path):
    """CSV を文字列で読む: UTF-8 (BOM の有無どちらも) → Shift_JIS (Access の既定) の順に試す"""
    raw = Path(path).read_bytes()
    for enc in ("utf-8-sig", "cp932"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            pass
    sys.exit(f"{Path(path).name}: 文字コードを読めません（UTF-8 か Shift_JIS で保存してください）")


def read_csv(path, **kw):
    import io
    return pd.read_csv(io.StringIO(_csv_text(path)), skipinitialspace=True, **kw)


def apply_labels(ax, args, default_x=None, default_y=None):
    if args.title:
        ax.set_title(args.title, fontsize=14, pad=12)
    if args.xlabel or default_x:
        ax.set_xlabel(args.xlabel or default_x)
    if args.ylabel or default_y:
        ax.set_ylabel(args.ylabel or default_y)


def plot_gantt(df, args):
    """列: task,start,end[,group]  日付は YYYY-MM-DD"""
    need = {"task", "start", "end"}
    if not need.issubset(df.columns):
        sys.exit(f"gantt には列 {sorted(need)} が必要です (任意: group)")
    df = df.copy()
    df["start"] = pd.to_datetime(df["start"])
    df["end"] = pd.to_datetime(df["end"])
    if getattr(args, "readable", False):
        args.auto_height = args.group_headers = args.stripes = True
        args.milestones = args.month_ticks = True
        args.sort = args.sort or "start"
        args.bar_labels = args.bar_labels or "days"
    fancy = any([args.auto_height, args.sort, args.group_headers, args.stripes, args.today,
                 args.bar_labels, args.milestones, args.month_ticks])
    if not fancy:
        return _plot_gantt_plain(df, args)

    has_group = "group" in df.columns
    if not has_group:
        df["group"] = ""
    groups = list(dict.fromkeys(df["group"]))
    if args.group_headers:  # グループを最初の開始日順に並べる
        first = df.groupby("group", sort=False)["start"].min()
        groups = sorted(groups, key=lambda g: first[g])
    cmap = plt.get_cmap("tab10")
    colors = {g: cmap(i % 10) for i, g in enumerate(dict.fromkeys(df["group"]))}

    if args.sort == "start":
        df = df.sort_values(["start", "end"], kind="stable")
    if args.group_headers or args.sort:
        order = {g: i for i, g in enumerate(groups)}
        df = df.sort_values("group", key=lambda c: c.map(order), kind="stable")

    # 行リストを作る: ("header", group) or ("task", row)
    rows = []
    for g in (groups if args.group_headers else [None]):
        sub = df if g is None else df[df["group"] == g]
        if g is not None:
            rows.append(("header", g, sub))
        for r in sub.itertuples():
            rows.append(("task", g, r))
    n = len(rows)

    if args.height:
        height = args.height
    elif args.auto_height:
        height = n * 0.35 + 2.2
    else:
        height = max(3, 0.5 * n + 1.5)
    fig, ax = plt.subplots(figsize=(args.width or 14, height))

    dmin, dmax = df["start"].min(), df["end"].max()
    pad = max(3, (dmax - dmin).days * 0.02)
    x0 = mdates.date2num(dmin) - pad
    x1 = mdates.date2num(dmax) + pad * (3 if args.bar_labels or args.milestones else 1) + 1
    ax.set_xlim(x0, x1)
    ax.set_ylim(n - 0.5, -0.5)
    fig.canvas.draw()
    px_per_day = ax.get_window_extent().width / (x1 - x0) * 0.85
    fs = 8

    labels, label_styles = [], []
    for i, (kind, g, r) in enumerate(rows):
        if kind == "header":
            ax.axhspan(i - 0.5, i + 0.5, color="#dde3ea", zorder=0)
            if i > 0:
                ax.axhline(i - 0.5, color="#555", linewidth=1.0, zorder=1)
            s0 = mdates.date2num(r["start"].min())
            s1 = mdates.date2num(r["end"].max()) + 1
            ax.barh(i, s1 - s0, left=s0, height=0.22, color=colors[g], alpha=0.9, zorder=2)
            labels.append(f"■ {g}（{len(r)}件）")
            label_styles.append("header")
            continue
        if args.stripes and i % 2 == 0:
            ax.axhspan(i - 0.5, i + 0.5, color="#f3f4f6", zorder=0)
        labels.append(("  " if args.group_headers else "") + str(r.task))
        label_styles.append("task")
        s0 = mdates.date2num(r.start)
        days = (r.end - r.start).days + 1
        col = colors[r.group]
        if args.milestones and r.start == r.end:
            ax.plot(s0 + 0.5, i, marker="D", markersize=9, color=col, markeredgecolor="black",
                    markeredgewidth=0.6, zorder=4)
            ax.text(s0 + 0.5 + 6 / px_per_day * 1.6, i, r.start.strftime("%m/%d"), va="center",
                    ha="left", fontsize=fs, color="#333", zorder=5)
            continue
        ax.barh(i, days, left=s0, height=0.6, color=col, edgecolor="black", linewidth=0.4, zorder=3)
        if args.bar_labels:
            text = f"{days}日" if args.bar_labels == "days" else str(r.task)
            est_w = sum(fs * (1.0 if ord(c) > 255 else 0.6) for c in text) * fig.dpi / 72 + 6
            if est_w <= days * px_per_day:
                ax.text(s0 + days / 2, i, text, ha="center", va="center", fontsize=fs,
                        color="white", fontweight="bold", zorder=5)
            else:
                ax.text(s0 + days + 1, i, text, ha="left", va="center", fontsize=fs,
                        color="#333", zorder=5)

    ax.set_yticks(range(n))
    ax.set_yticklabels(labels)
    ax.tick_params(axis="y", length=0)
    for t, st in zip(ax.get_yticklabels(), label_styles):
        if st == "header":
            t.set_fontweight("bold")
            t.set_fontsize(10)
        else:
            t.set_fontsize(9)

    ax.xaxis_date()
    if args.month_ticks:
        ax.xaxis.set_major_locator(mdates.MonthLocator())
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y/%m"))
        ax.xaxis.set_minor_locator(mdates.WeekdayLocator(byweekday=mdates.MO))
        ax.grid(axis="x", which="major", color="#888", linewidth=0.9, alpha=0.7, zorder=1)
        ax.grid(axis="x", which="minor", color="#bbb", linestyle=":", linewidth=0.6, alpha=0.7, zorder=1)
        ax.set_axisbelow(True)
        if n > 25:  # 縦に長いときは上下両方に目盛り
            ax.tick_params(axis="x", which="both", top=True, bottom=True, labeltop=True, labelbottom=True)
    else:
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%m/%d"))
        ax.grid(axis="x", linestyle=":", alpha=0.6)

    if args.today:
        tday = mdates.date2num(pd.to_datetime(args.today))
        ax.axvline(tday, color="red", linestyle="--", linewidth=1.4, zorder=4.5)
        ax.annotate(f"今日 {pd.to_datetime(args.today):%m/%d}", (tday, 0), xycoords=("data", "axes fraction"),
                    xytext=(0, 6), textcoords="offset points", ha="center", va="bottom", fontsize=9,
                    color="red", fontweight="bold",
                    bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="red", lw=0.8), zorder=7)

    if has_group:
        from matplotlib.patches import Patch
        from matplotlib.lines import Line2D
        handles = [Patch(facecolor=colors[g], edgecolor="black", linewidth=0.4, label=g) for g in groups]
        if args.milestones:
            handles.append(Line2D([], [], marker="D", color="gray", linestyle="", markeredgecolor="black",
                                  markersize=8, label="マイルストーン"))
        ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, 0),
                  borderaxespad=2.4, ncol=len(handles), frameon=False, fontsize=9)
    for sp in ("right", "left"):
        ax.spines[sp].set_visible(False)
    apply_labels(ax, args)
    if args.title and args.month_ticks and n > 25:
        ax.set_title(args.title, fontsize=14, pad=28)
    return fig


def _plot_gantt_plain(df, args):
    has_group = "group" in df.columns
    groups = list(dict.fromkeys(df["group"])) if has_group else [None]
    cmap = plt.get_cmap("tab10")
    colors = {g: cmap(i % 10) for i, g in enumerate(groups)}

    fig, ax = plt.subplots(figsize=(args.width or 11, args.height or max(3, 0.5 * len(df) + 1.5)))
    y = np.arange(len(df))
    for i, row in enumerate(df.itertuples()):
        start = mdates.date2num(row.start)
        dur = mdates.date2num(row.end) - start + 1  # 終了日を含む
        g = row.group if has_group else None
        ax.barh(i, dur, left=start, height=0.6, color=colors[g], edgecolor="black", linewidth=0.5,
                label=g if has_group else None)
    ax.set_yticks(y)
    ax.set_yticklabels(df["task"])
    ax.invert_yaxis()
    ax.xaxis_date()
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%m/%d"))
    ax.grid(axis="x", linestyle=":", alpha=0.6)
    if has_group:
        h, l = ax.get_legend_handles_labels()
        uniq = dict(zip(l, h))
        ax.legend(uniq.values(), uniq.keys(), loc="best")
    apply_labels(ax, args, default_x="日付")
    fig.autofmt_xdate()
    return fig


def _cat_series(df, cols=None):
    cat = df.columns[0]
    series = cols or [c for c in df.columns[1:]]
    for c in series:
        if c not in df.columns:
            sys.exit(f"列 '{c}' が CSV にありません: {list(df.columns)}")
    return cat, series


def _annotate_values(ax, bars):
    for b in bars:
        ax.bar_label(b, fmt="%g", fontsize=8, padding=2)


def plot_bar(df, args):
    """1列目=カテゴリ, 残り(または --series)=系列。グループ化された縦棒。"""
    cat, series = _cat_series(df, args.series)
    fig, ax = plt.subplots(figsize=(args.width or 10, args.height or 6))
    x = np.arange(len(df))
    n = len(series)
    w = 0.8 / n
    containers = []
    for i, s in enumerate(series):
        containers.append(ax.bar(x - 0.4 + w * (i + 0.5), df[s], w, label=s))
    if args.values:
        _annotate_values(ax, containers)
    ax.set_xticks(x)
    ax.set_xticklabels(df[cat])
    ax.grid(axis="y", linestyle=":", alpha=0.6)
    ax.set_axisbelow(True)
    if n > 1:
        ax.legend()
    apply_labels(ax, args, default_x=cat)
    return fig


def plot_stacked(df, args):
    """1列目=カテゴリ, 残り(または --series)=積み上げる系列。"""
    cat, series = _cat_series(df, args.series)
    fig, ax = plt.subplots(figsize=(args.width or 10, args.height or 6))
    x = np.arange(len(df))
    bottom = np.zeros(len(df))
    for s in series:
        vals = df[s].fillna(0).to_numpy(dtype=float)
        bars = ax.bar(x, vals, 0.6, bottom=bottom, label=s)
        if args.values:
            ax.bar_label(bars, label_type="center", fmt="%g", fontsize=8)
        bottom += vals
    if args.total:
        for xi, t in zip(x, bottom):
            ax.text(xi, t, f"{t:g}", ha="center", va="bottom", fontsize=9, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(df[cat])
    ax.grid(axis="y", linestyle=":", alpha=0.6)
    ax.set_axisbelow(True)
    ax.legend()
    apply_labels(ax, args, default_x=cat)
    return fig


def plot_combo(df, args):
    """1列目=カテゴリ, --line で指定した列=右軸の折れ線, 残り(または --series)=左軸の棒。"""
    lines = args.line or []
    if not lines:
        sys.exit("combo には --line 列名 を1つ以上指定してください")
    cat = df.columns[0]
    bars_cols = args.series or [c for c in df.columns[1:] if c not in lines]
    _cat_series(df, bars_cols + lines)
    fig, ax = plt.subplots(figsize=(args.width or 10, args.height or 6))
    x = np.arange(len(df))
    n = max(len(bars_cols), 1)
    w = 0.8 / n
    if args.stack_bars:
        bottom = np.zeros(len(df))
        for s in bars_cols:
            vals = df[s].fillna(0).to_numpy(dtype=float)
            ax.bar(x, vals, 0.6, bottom=bottom, label=s)
            bottom += vals
    else:
        for i, s in enumerate(bars_cols):
            ax.bar(x - 0.4 + w * (i + 0.5), df[s], w, label=s)
    ax.set_xticks(x)
    ax.set_xticklabels(df[cat])
    ax.grid(axis="y", linestyle=":", alpha=0.6)
    ax.set_axisbelow(True)
    ax2 = ax.twinx()
    cmap = plt.get_cmap("Dark2")
    for i, s in enumerate(lines):
        ax2.plot(x, df[s], marker="o", linewidth=2, color=cmap(i % 8), label=s)
        if args.values:
            for xi, v in zip(x, df[s]):
                ax2.annotate(f"{v:g}", (xi, v), textcoords="offset points", xytext=(0, 8),
                             ha="center", fontsize=9, fontweight="bold", color=cmap(i % 8),
                             bbox=dict(boxstyle="round,pad=0.2", fc="white", ec=cmap(i % 8), lw=0.8))
    if args.ylabel2:
        ax2.set_ylabel(args.ylabel2)
    if args.y2min is not None or args.y2max is not None:
        ax2.set_ylim(args.y2min, args.y2max)
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper left")
    apply_labels(ax, args, default_x=cat)
    return fig


GANTT2_COLUMNS = {
    "owner": "担当", "category": "カテゴリ", "progress": "進捗%",
    "plan_start": "予定開始", "plan_end": "予定終了",
    "actual_start": "実績開始", "actual_end": "実績終了", "delay": "差(日)",
}
GANTT2_DEFAULT_COLS = "owner,category,progress,plan_end,actual_end,delay"


def _text_w_in(text, fs):
    """文字列のおおよその幅 (インチ)。全角=1.0em, 半角=0.6em"""
    return sum(fs * (1.0 if ord(c) > 255 else 0.6) for c in str(text)) / 72


def plot_gantt2(df, args):
    """予定/実績ガント。列:
    project,phase,task,category,owner,plan_start,plan_end,actual_start,actual_end,progress,note
    actual_start 空=未着手, actual_end のみ空=進行中 (--today まで斜線で描画)"""
    from matplotlib.patches import Patch, Rectangle
    from matplotlib.lines import Line2D

    if (args.range or args.depth or args.notes or args.root or args.date_from or args.date_to or args.layout
            or any(c.startswith("level") and c[5:].isdigit() for c in df.columns)):
        return plot_gantt_tree(df, args)
    need = ["project", "phase", "task", "plan_start", "plan_end"]
    miss = [c for c in need if c not in df.columns]
    if miss:
        sys.exit(f"gantt2 には列 {miss} が必要です")
    df = df.copy()
    for c in ["category", "owner", "note", "actual_start", "actual_end", "progress"]:
        if c not in df.columns:
            df[c] = np.nan
    for c in ["plan_start", "plan_end", "actual_start", "actual_end"]:
        df[c] = pd.to_datetime(df[c], errors="coerce")
    df["category"] = df["category"].fillna("その他")
    today = pd.to_datetime(args.today) if args.today else pd.Timestamp.today().normalize()

    cols = [c.strip() for c in (args.columns or GANTT2_DEFAULT_COLS).split(",") if c.strip()]
    bad = [c for c in cols if c not in GANTT2_COLUMNS]
    if bad:
        sys.exit(f"--columns に使えない列: {bad}  (使える列: {','.join(GANTT2_COLUMNS)})")

    cats = list(dict.fromkeys(df["category"]))
    pal = ["#1f77b4", "#ff7f0e", "#2ca02c", "#9467bd", "#8c564b", "#e377c2", "#17becf",
           "#bcbd22", "#7f7f7f"]  # 遅延の赤と被らないよう赤を除外
    ccol = {c: pal[i % len(pal)] for i, c in enumerate(cats)}
    years = {d.year for d in pd.concat([df["plan_start"], df["plan_end"]]).dropna()}
    dfmt = "%m/%d" if len(years) == 1 else "%y/%m/%d"
    fmt_d = lambda d: "" if pd.isna(d) else d.strftime(dfmt)

    def delay_of(r):
        if pd.notna(r.actual_end):
            return (r.actual_end - r.plan_end).days, False
        if pd.notna(r.actual_start) and today > r.plan_end:
            return (today - r.plan_end).days, True  # 進行中で既に遅延
        return None, False

    # ---- 行の構築 ----
    rows, notes_long = [], []
    for proj, pdf in df.groupby("project", sort=False):
        rows.append(dict(kind="project", label=str(proj), sub=pdf))
        for ph, hdf in pdf.groupby("phase", sort=False):
            rows.append(dict(kind="phase", label=str(ph), sub=hdf))
            for r in hdf.itertuples():
                note = "" if pd.isna(r.note) else str(r.note).strip()
                if len(note) > 15:
                    notes_long.append(note)
                    note = f"※{len(notes_long)}"
                rows.append(dict(kind="task", label=str(r.task), r=r, note=note))
    n = len(rows)

    # ---- テーブルのセル文字列 ----
    def cell(row, key):
        if row["kind"] != "task":
            sub = row["sub"]
            if key == "progress":
                p = pd.to_numeric(sub["progress"], errors="coerce").fillna(0)
                w = (sub["plan_end"] - sub["plan_start"]).dt.days + 1
                return f"{(p * w).sum() / w.sum():.0f}%", None
            if key == "plan_start":
                return fmt_d(sub["plan_start"].min()), None
            if key == "plan_end":
                return fmt_d(sub["plan_end"].max()), None
            return "", None
        r = row["r"]
        if key == "owner":
            return ("" if pd.isna(r.owner) else str(r.owner)), None
        if key == "category":
            return str(r.category), None
        if key == "progress":
            return ("" if pd.isna(r.progress) else f"{float(r.progress):.0f}%"), None
        if key in ("plan_start", "plan_end", "actual_start"):
            return fmt_d(getattr(r, key)), None
        if key == "actual_end":
            if pd.isna(r.actual_start):
                return "未着手", "#888"
            if pd.isna(r.actual_end):
                return "進行中", "#1f5fbf"
            return fmt_d(r.actual_end), None
        if key == "delay":
            d, running = delay_of(r)
            if d is None:
                return "", None
            txt = f"{d:+d}" if d else "±0"
            if running:
                txt += "*"
            return txt, ("#d62728" if d > 0 else ("#1f77b4" if d < 0 else "#333"))
        return "", None

    fs = 9
    indent = {"project": 0.0, "phase": 0.18, "task": 0.36}
    task_w = max(indent[r["kind"]] + _text_w_in(r["label"], fs + (1 if r["kind"] == "project" else 0))
                 for r in rows) + 0.25
    task_w = max(task_w, _text_w_in("タスク", fs) + 0.3)
    col_ws = []
    for k in cols:
        w = max([_text_w_in(GANTT2_COLUMNS[k], fs)] + [_text_w_in(cell(r, k)[0], fs) for r in rows])
        col_ws.append(w + 0.22)
    table_w = task_w + sum(col_ws)
    short_notes = [r.get("note", "") for r in rows if r["kind"] == "task"]
    note_w = max([_text_w_in("備考", fs)] + [_text_w_in(t, fs) for t in short_notes]) + 0.3

    dmin = min(df["plan_start"].min(), df["actual_start"].min())
    dmax = max(df["plan_end"].max(), df["actual_end"].max(), today if args.today else df["plan_end"].max())
    span = (dmax - dmin).days + 1
    chart_w = args.width or float(np.clip(span * 0.05, 7, 16))

    row_h = 0.32
    top_m = 1.05 if args.title else 0.65
    foot_h = 0.22 * len(notes_long)
    bot_m = 0.85 + (foot_h + 0.15 if notes_long else 0)
    left_m, right_m, gap = 0.15, 0.15, 0.35
    W = left_m + table_w + gap + chart_w + note_w + right_m
    H = top_m + n * row_h + bot_m
    fig = plt.figure(figsize=(W, H))
    fig._no_tight = True
    yb, hh = bot_m / H, n * row_h / H
    ax_t = fig.add_axes([left_m / W, yb, table_w / W, hh])
    ax = fig.add_axes([(left_m + table_w + gap) / W, yb, chart_w / W, hh])
    ax_n = fig.add_axes([(left_m + table_w + gap + chart_w) / W, yb, note_w / W, hh])
    for a in (ax_t, ax_n):
        a.set_xlim(0, 1)
        a.set_xticks([])
        a.set_yticks([])
        for sp in a.spines.values():
            sp.set_visible(False)
    ax.set_yticks([])
    for a in (ax_t, ax, ax_n):
        a.set_ylim(n - 0.5, -0.5)

    # ---- 背景 (見出し行・縞) ----
    for i, row in enumerate(rows):
        if row["kind"] == "project":
            colr = "#cfd8e3"
        elif row["kind"] == "phase":
            colr = "#e6ebf1"
        elif i % 2 == 0:
            colr = "#f4f5f7"
        else:
            colr = None
        for a in (ax_t, ax, ax_n):
            if colr:
                a.axhspan(i - 0.5, i + 0.5, color=colr, zorder=0, lw=0)
            if row["kind"] == "project" and i > 0:
                a.axhline(i - 0.5, color="#444", lw=1.2, zorder=1)

    # ---- テーブル ----
    tx = lambda inch: inch / table_w
    hy = -0.62
    ax_t.text(tx(0.08), hy, "タスク", fontsize=fs, fontweight="bold", va="bottom", clip_on=False)
    x = task_w
    col_centers = []
    for k, w in zip(cols, col_ws):
        col_centers.append(x + w / 2)
        ax_t.text(tx(x + w / 2), hy, GANTT2_COLUMNS[k], fontsize=fs, fontweight="bold",
                  ha="center", va="bottom", clip_on=False)
        ax_t.axvline(tx(x), color="#c8ccd2", lw=0.6, zorder=1)
        x += w
    ax_t.axhline(-0.5, color="#444", lw=1.0, clip_on=False)
    ax_n.axhline(-0.5, color="#444", lw=1.0, clip_on=False)
    ax_n.text(0.08, hy, "備考", fontsize=fs, fontweight="bold", va="bottom", clip_on=False)
    for i, row in enumerate(rows):
        kind = row["kind"]
        weight = "bold" if kind != "task" else "normal"
        prefix = {"project": "▼ ", "phase": "▶ ", "task": ""}[kind]
        ax_t.text(tx(0.08 + indent[kind]), i, prefix + row["label"], va="center",
                  fontsize=fs + (1 if kind == "project" else 0), fontweight=weight)
        for k, cx in zip(cols, col_centers):
            t, colr = cell(row, k)
            if t:
                ax_t.text(tx(cx), i, t, ha="center", va="center", fontsize=fs, color=colr or "#222",
                          fontweight="bold" if (k == "delay" and colr == "#d62728") or kind != "task" else "normal")
        if kind == "task" and row["note"]:
            ax_n.text(0.08, i, row["note"], va="center", fontsize=fs,
                      color="#b35900" if row["note"].startswith("※") else "#333")

    # ---- バー ----
    num = mdates.date2num
    for i, row in enumerate(rows):
        if row["kind"] != "task":
            sub = row["sub"]
            s0, s1 = num(sub["plan_start"].min()), num(sub["plan_end"].max()) + 1
            h = 0.2 if row["kind"] == "project" else 0.14
            c = "#2b3a4a" if row["kind"] == "project" else "#5d6d7e"
            ax.barh(i, s1 - s0, left=s0, height=h, color=c, zorder=3)
            for xx in (s0, s1):  # 両端の三角
                ax.plot(xx, i + h / 2, marker="v" if True else None, color=c, markersize=5, zorder=3)
            continue
        r = row["r"]
        c = ccol[r.category]
        ps, pe = num(r.plan_start), num(r.plan_end) + 1
        ax.barh(i, pe - ps, left=ps, height=0.66, color=c, alpha=0.22, edgecolor=c, linewidth=1.0, zorder=2)
        if pd.isna(r.actual_start):
            continue
        a0 = num(r.actual_start)
        running = pd.isna(r.actual_end)
        a1 = num(today) + 1 if running else num(r.actual_end) + 1
        if a1 <= a0:
            a1 = a0 + 0.5
        hatch = "////" if running else None
        ok_end = min(a1, pe)
        if ok_end > a0:
            ax.barh(i, ok_end - a0, left=a0, height=0.3, color=c, hatch=hatch,
                    edgecolor="white" if running else c, linewidth=0, zorder=4)
        if a1 > pe:
            l0 = max(a0, pe)
            ax.barh(i, a1 - l0, left=l0, height=0.3, color="#d62728", hatch=hatch,
                    edgecolor="white" if running else "#d62728", linewidth=0, zorder=4)
        if running:  # 進行中: 外枠を付けて先端を矢印風に
            ax.add_patch(Rectangle((a0, i - 0.15), a1 - a0, 0.3, fill=False,
                                   edgecolor="#333", linewidth=0.6, zorder=5))
            ax.plot(a1, i, marker=">", color="#333", markersize=4, zorder=5)

    pad = max(3, span * 0.02)
    ax.set_xlim(num(dmin) - pad, num(dmax) + 1 + pad)
    ax.xaxis_date()
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y/%m"))
    ax.xaxis.set_minor_locator(mdates.WeekdayLocator(byweekday=mdates.MO))
    ax.grid(axis="x", which="major", color="#888", linewidth=0.9, alpha=0.7)
    ax.grid(axis="x", which="minor", color="#bbb", linestyle=":", linewidth=0.6, alpha=0.7)
    ax.set_axisbelow(True)
    ax.tick_params(axis="x", which="both", top=True, bottom=True, labeltop=True, labelbottom=True,
                   labelsize=8)
    for sp in ("left", "right"):
        ax.spines[sp].set_visible(False)

    if args.today:
        t = num(today) + 0.5
        ax.axvline(t, color="red", linestyle="--", linewidth=1.3, zorder=4.5)
        ax.annotate(f"今日 {today:%m/%d}", (t, 0), xycoords=("data", "axes fraction"), xytext=(0, 6),
                    textcoords="offset points", ha="center", va="bottom", fontsize=8.5, color="red",
                    fontweight="bold", bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="red", lw=0.8),
                    zorder=7)

    if args.title:
        fig.text(0.5, 1 - 0.3 / H, args.title, ha="center", va="center", fontsize=14)

    # ---- 凡例 (1行) ----
    handles = [Patch(facecolor=ccol[c], label=c) for c in cats]
    handles += [
        Patch(facecolor=(0.5, 0.5, 0.5, 0.22), edgecolor="gray", label="予定"),
        Patch(facecolor="gray", label="実績"),
        Patch(facecolor="#d62728", label="遅延（予定超過）"),
        Patch(facecolor="gray", edgecolor="white", hatch="////", label="進行中（今日まで）"),
        Line2D([], [], color="#2b3a4a", lw=3, label="予定期間（PJ/工程）"),
    ]
    if args.today:
        handles.append(Line2D([], [], color="red", linestyle="--", label="今日"))
    leg_y = (bot_m - 0.55) / H
    fig.legend(handles=handles, loc="center", bbox_to_anchor=(0.5, leg_y), ncol=len(handles),
               frameon=False, fontsize=8.5, handlelength=1.6, columnspacing=1.2)

    # ---- 脚注 ----
    y = bot_m - 0.9
    if notes_long:
        for k, t in enumerate(notes_long, 1):
            fig.text(left_m / W, y / H, f"※{k}  {t}", fontsize=8.5, va="top", color="#333")
            y -= 0.22
    fig.text(1 - right_m / W, (bot_m - 0.9) / H if not notes_long else y / H,
             "差(日): 実績終了−予定終了。* は進行中で今日時点の超過日数",
             fontsize=7.5, color="#666", ha="right", va="top")
    return fig


# ======================================================================
# 階層ガント (gantt2 の拡張: --range / --depth / level1..N 列)
# ======================================================================
TREE_COLUMNS = dict(GANTT2_COLUMNS, note="備考", plan_days="日数(予定)", actual_days="日数(実績)", no="No.", depends="影響",
                    actual_effort="実績工数", unit_price="単価", plan_effort="予定工数(参考)", plan_amount="予定金額(参考)", actual_amount="実績金額")
# 工数・金額の列 (--columns で指定したときだけ。既定の列には入れない): 右寄せ・小数 2 桁 (1,234.50)
EFFORT_COLS = ("actual_effort", "unit_price", "plan_effort", "plan_amount", "actual_amount")
TREE_PRESETS = {
    "full": "owner,category,progress,plan_start,plan_end,actual_start,actual_end,delay",
    "short": GANTT2_DEFAULT_COLS,
    "clean": "plan_start,plan_end,plan_days,actual_start,actual_end,actual_days,progress",
}
CLEAN_HATCHES = ["", "///", "...", "\\\\\\", "xx", "---", "|||", "++", "oo"]
WEEKDAY_JA = "月火水木金土日"


# マスタ運用のタスク CSV のコア列 (Web 画面 app.py の CORE_COLUMNS と同じ。どちらも消せない)
CORE_TASK_COLUMNS = ["project", "level1", "level2", "level3", "category", "owner", "plan_start", "plan_end",
                     "actual_start", "actual_end", "progress", "note"]
OPTIONAL_TASK_COLUMNS = ["no", "priority", "importance", "depends", "calendar", "actual_effort", "unit_price"]  # calendar: 空欄/休日除外 か 暦日  # Web 画面で足したコア列。あれば使う (no = 親の中での並び)


def _is_calday(v):
    return not (isinstance(v, float) and pd.isna(v)) and str(v).strip() == "暦日"


def _no_str(v):
    """No. を文字列に (pandas が 3.0 と読んだものも "3")"""
    t = "" if pd.isna(v) else str(v).strip()
    return t[:-2] if re.fullmatch(r"\d+\.0", t) else t


def _dep_tokens(v):
    return [_no_str(x) for x in re.split(r"[\s,、，]+", "" if pd.isna(v) else str(v).strip()) if x]


def _dep_cycles(g):
    """g = {No.: [先行の No.]} → {循環に入る No.: [No., …, No.]} (Web 画面と同じ規則)"""
    sys.setrecursionlimit(max(1000, 2 * len(g) + 100))
    state, out = {}, {}

    def visit(n, stack):
        state[n] = 1
        stack.append(n)
        for m in g.get(n, ()):
            if state.get(m) == 1:
                ring = stack[stack.index(m):]
                out.update({k: ring[ring.index(k):] + ring[:ring.index(k)] + [k] for k in ring if k not in out})
            elif m not in state:
                visit(m, stack)
        stack.pop()
        state[n] = 2
    [visit(n, []) for n in g if n not in state]
    return out


def _check_deps(df):
    """影響タスク (depends) を確かめる。誤りがあれば終了 (循環参照・ない No.・自分自身・整数でない)"""
    if "depends" not in df.columns or "no" not in df.columns:
        sys.exit("--deps on には no 列と depends 列が必要です")
    nos = {_no_str(v) for v in df["no"] if _no_str(v).isdigit()}
    rows = [(_no_str(n), _dep_tokens(d)) for n, d in zip(df["no"], df["depends"])]
    errs = [f"No. {n}: 影響タスク {' '.join(t)} が不正です（No. の整数・自分以外・このファイルにある No.）"
            for n, t in rows if any(not x.isdigit() or x not in nos or x == n for x in t) or len(set(t)) != len(t)]
    cyc = _dep_cycles({n: [x for x in t if x != n] for n, t in rows if n in nos})
    rings = list({tuple(sorted(set(v))): v for v in cyc.values()}.values())
    errs += ["循環参照: " + " → ".join(v) for v in rings]
    if errs:
        sys.exit("影響タスクの誤り:\n  " + "\n  ".join(errs))


def _sort_by_no(df):
    """no 列があれば、親 (プロジェクト＞大項目＞中項目) の中で葉を No. 順に並べる。親どうしの順は最初に出てきた順のまま"""
    if "no" not in df.columns:
        return df
    keys = [c for c in ["project", "level1", "level2"] if c in df.columns]
    rank = {f"_r{k}": df.groupby(keys[:k + 1], sort=False, dropna=False).ngroup() for k in range(len(keys))}
    tmp = df.assign(**rank, _no=pd.to_numeric(df["no"], errors="coerce"))
    return tmp.sort_values([*rank, "_no"], kind="stable").drop(columns=[*rank, "_no"])


def _hier_cols(df):
    lv = sorted([c for c in df.columns if c.startswith("level") and c[5:].isdigit()],
                key=lambda c: int(c[5:]))
    if lv:
        return lv
    if {"project", "phase", "task"}.issubset(df.columns):
        return ["project", "phase", "task"]
    sys.exit("階層列がありません: level1,level2,level3 … か project,phase,task を用意してください")


def _parse_window(s):
    s = str(s).strip().lower()
    if s.endswith("w"):
        return int(s[:-1]) * 7
    if s.endswith("d"):
        return int(s[:-1])
    if s.endswith("m"):
        return int(s[:-1]) * 30
    return int(s)


def to_rgba_g(c, a):
    from matplotlib.colors import to_rgba
    return to_rgba(c, a)


def _lane_handler(hatch="////"):
    """凡例用: 上下 2 本のレーン (上＝予定 / 下＝実績) の見本"""
    from matplotlib.legend_handler import HandlerBase
    from matplotlib.patches import Rectangle

    class _H(HandlerBase):
        def create_artists(self, legend, orig, xd, yd, w, h, fontsize, trans):
            hh = h * 1.5
            y0 = yd - (hh - h) / 2
            g = hh * 0.16
            lh = (hh - g) / 2
            up = Rectangle((xd, y0 + lh + g), w, lh, facecolor=(0.45, 0.45, 0.45, 0.22), edgecolor="#555",
                           hatch=hatch, linewidth=0.6, transform=trans)
            lo = Rectangle((xd, y0), w, lh, facecolor="#555", edgecolor="none", transform=trans)
            return [up, lo]
    return _H()


def _arrow_handler(color="#555"):
    """凡例用: 先が矢印 (▶) の単色バー = 進行中 (今日まで)"""
    from matplotlib.legend_handler import HandlerBase
    from matplotlib.patches import Polygon

    class _H(HandlerBase):
        def create_artists(self, legend, orig, xd, yd, w, h, fontsize, trans):
            lh = h * 0.75
            y0 = yd + (h - lh) / 2
            tl = min(w * 0.35, lh * 0.9)
            pts = [(xd, y0), (xd + w - tl, y0), (xd + w, y0 + lh / 2), (xd + w - tl, y0 + lh), (xd, y0 + lh)]
            return [Polygon(pts, closed=True, facecolor=color, edgecolor="none", transform=trans)]
    return _H()


PAGE_SIZES = {  # 用紙サイズ (インチ)
    "a4-landscape": (297 / 25.4, 210 / 25.4), "a4-portrait": (210 / 25.4, 297 / 25.4),
    "a3-landscape": (420 / 25.4, 297 / 25.4),
}
PAGE_MARGIN = 10 / 25.4
PAGE_ABBR = {"plan_start": "予開", "plan_end": "予終", "plan_days": "予日", "actual_start": "実開",
             "actual_end": "実終", "actual_days": "実日", "progress": "進捗", "delay": "差",
             "owner": "担当", "category": "分類", "note": "備考", "no": "No.", "depends": "影響",
             "actual_effort": "実工", "unit_price": "単価", "plan_effort": "予工", "plan_amount": "予金", "actual_amount": "実金"}


# ---- 工数・単価・金額: 小数 2 桁、端数は四捨五入 (ROUND_HALF_UP)。Web 画面 (app.py) と同じ計算 ----
def _dec(v):
    """'1,234.5' → Decimal (2 桁に四捨五入)。空欄・数値でない・負 → None"""
    import unicodedata
    from decimal import Decimal, ROUND_HALF_UP
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    t = re.sub(r"^[¥$\\]", "", unicodedata.normalize("NFKC", str(v)).replace(",", "").strip())  # ¥5,000 (Access の通貨型)
    return Decimal(t).quantize(Decimal("0.01"), ROUND_HALF_UP) if re.fullmatch(r"\d{1,12}(\.\d+)?", t) else None


def _hours_per_day(args):
    """工数の基準値 (時間/日): --master のフォルダの params.csv (key,value,label) の hours_per_day。無ければ 8"""
    d = Path(args.master) if getattr(args, "master", None) else None
    p = d / "params.csv" if d else None
    if p and p.exists():
        import io
        rows = {r["key"]: r.get("value", "") for r in csv.DictReader(io.StringIO(_csv_text(p)))}
        h = _dec(rows.get("hours_per_day"))
        if h and h > 0:
            return h
    return _dec("8")


def _money(d):
    return "" if d is None else f"{d:,.2f}"


def _split_rows(rows, N):
    """行リストを N 行以内のページに分ける (大項目→中項目の境目を優先、親の途中なら「（続き）」行を付ける)"""
    def ancestors(idx):
        out, lvl = [], rows[idx]["level"]
        for j in range(idx - 1, -1, -1):
            if rows[j]["level"] < lvl and not rows[j]["leaf"]:
                out.insert(0, j)
                lvl = rows[j]["level"]
                if lvl <= 0:
                    break
        return out

    def cont(j):
        if rows[j].get("cont"):
            return rows[j]
        return dict(rows[j], name=rows[j]["name"] + "（続き）", cont=True)

    pages, s0 = [], 0
    while s0 < len(rows):
        head = [cont(j) for j in ancestors(s0)] if s0 > 0 else []
        cap = N - len(head)
        if len(rows) - s0 <= cap:
            pages.append(head + rows[s0:])
            break
        emax = s0 + cap
        b = None
        for lv, fill in ((1, 0.7), (2, 0.5)):  # 大項目 (7割以上埋まるなら) → 中項目 (半分以上) の境目で切る
            cands = [i for i in range(s0 + 1, emax + 1)
                     if not rows[i]["leaf"] and rows[i]["level"] <= lv and i - s0 >= cap * fill]
            if cands:
                b = cands[-1]
                break
        if b is None:
            b = emax
            while b - 1 > s0 and not rows[b - 1]["leaf"]:  # 親だけがページ末に残らないように
                b -= 1
        pages.append(head + rows[s0:b])
        s0 = b
    return pages


def _paginate(rows, args, cap=None):
    """行をページに分ける。None=分割しない。cap=用紙モードで 1 ページに入る最大行数"""
    rpp = getattr(args, "rows_per_page", None)
    by = getattr(args, "split_by", None)
    if cap:
        rpp = min(rpp, cap) if rpp else cap
    if not rpp and not by:
        return None
    if by:  # 大項目 (level1) ごとに 1 ページ (入りきらなければさらに分割)
        starts = [i for i, r in enumerate(rows) if not r["leaf"] and r["level"] == 1]
        if starts:
            pre = [dict(rows[j], name=rows[j]["name"] + "（続き）", cont=True) for j in range(starts[0])]
            groups = []
            for k, b in enumerate(starts):
                e = starts[k + 1] if k + 1 < len(starts) else len(rows)
                groups.append(pre + rows[b:e])
            if not rpp:
                return groups
            return [pg for g in groups for pg in _split_rows(g, max(5, int(rpp)))]
    return _split_rows(rows, max(5, int(rpp)))


def _bookmarks_of(pages):
    """PDF のしおり: 親の行 (プロジェクト＞大項目＞中項目、担当者ビューなら担当者) を最初に出てくるページで。
    続きのページ (「（続き）」の行) には付けない。[(経路, 題名, ページ番号 0 始まり)]"""
    seen = {}
    for k, pr in enumerate(pages):
        for r in pr:
            key = tuple(str(x) for x in (r["node"] or ()))
            if not r["leaf"] and not r.get("cont") and key and key != ("__root__",) and key not in seen:
                seen[key] = (key, key[-1], k)
    return list(seen.values())


def _add_bookmarks(path, marks):
    """PdfPages で書いた PDF にしおりを足す (pypdf。題名は UTF-16BE+BOM で書かれ、日本語も化けない)"""
    try:
        from pypdf import PdfWriter
    except ImportError:
        print("警告: pypdf が無いため PDF のしおりは付けません (pip install pypdf)", file=sys.stderr)
        return 0
    w = PdfWriter(clone_from=str(path))
    made = {}
    for key, title, page in marks:
        parent = next((made[key[:j]] for j in range(len(key) - 1, 0, -1) if key[:j] in made), None)
        made[key] = w.add_outline_item(title, page, parent=parent)
    w.page_mode = "/UseOutlines"  # 開いたときにしおりの欄を出す
    w.write(str(path))
    return len(made)


def _read_master(path, required):
    if not path:
        return None
    pth = Path(path)
    if not pth.exists():
        sys.exit(f"マスタが見つかりません: {pth}")
    m = read_csv(pth, dtype=str, keep_default_na=False)
    m.columns = [c.strip() for c in m.columns]
    miss = [c for c in required if c not in m.columns]
    if miss:
        sys.exit(f"{pth.name} に列 {miss} がありません (必要な列: {','.join(required)})")
    for c in m.columns:
        m[c] = m[c].str.strip()
    if "order" in m.columns:
        m["order"] = pd.to_numeric(m["order"], errors="coerce").fillna(9999)
    return m


def _load_masters(args):
    """--master DIR または個別指定 (--categories など) からマスタを読む。無いものは None"""
    d = Path(args.master) if getattr(args, "master", None) else None

    def pick(opt, fname):
        v = getattr(args, opt, None)
        if v:
            return v
        if d and (d / fname).exists():
            return str(d / fname)
        return None
    return {
        "categories": _read_master(pick("categories", "categories.csv"), ["code", "name", "color", "order"]),
        "projects": _read_master(pick("projects", "projects.csv"), ["code", "name", "color", "order"]),
        "owners": _read_master(pick("owners", "owners.csv"), ["code", "name", "dept", "color", "order"]),
        "holidays": _read_master(pick("holidays", "holidays.csv"), ["date", "name", "type"]),
    }


def _apply_masters(df, M, allow_unknown):
    """タスク CSV のコード (project / category / owner) をマスタで名前に置き換える。不明コードはエラー (行番号つき)"""
    info = {"cat_color": {}, "cat_order": {}, "proj": {}, "owner": {}}
    problems = []
    for col, key in (("category", "categories"), ("project", "projects"), ("owner", "owners")):
        m = M.get(key)
        if m is None or col not in df.columns:
            continue
        codes = set(m["code"])
        for idx, v in df[col].items():
            if pd.notna(v) and str(v).strip() and str(v).strip() not in codes:
                problems.append((idx + 2, col, str(v).strip()))
    if problems:
        lines = "\n".join(f"  {ln} 行目: {col} = {v}" for ln, col, v in sorted(problems))
        msg = f"マスタにないコードがあります ({len(problems)} 件):\n{lines}"
        if not allow_unknown:
            sys.exit(msg + "\nマスタに追加するか、--allow-unknown を付けると警告だけで続行します。")
        print("警告: " + msg + "\n(コードをそのまま名前として表示します)", file=sys.stderr)
    m = M.get("categories")
    if m is not None and "category" in df.columns:
        mp = dict(zip(m["code"], m["name"]))
        df["category_code"] = df["category"]
        df["category"] = df["category"].map(lambda v: mp.get(str(v).strip(), str(v).strip()) if pd.notna(v) else v)
        info["cat_color"] = dict(zip(m["name"], m["color"]))
        info["cat_order"] = dict(zip(m["name"], m["order"]))
    m = M.get("projects")
    if "project" in df.columns:
        df["project_code"] = df["project"].astype(str).str.strip()
        if m is not None:
            for r in m.itertuples():
                info["proj"][r.code] = dict(name=r.name, color=r.color, order=r.order)
        df["project_name"] = df["project_code"].map(lambda c: info["proj"].get(c, {}).get("name", c))
    m = M.get("owners")
    if m is not None and "owner" in df.columns:
        for r in m.itertuples():
            info["owner"][r.code] = dict(name=r.name, dept=r.dept, color=r.color, order=r.order)
        df["owner_code"] = df["owner"]
        df["owner"] = df["owner"].map(
            lambda c: info["owner"].get(str(c).strip(), {}).get("name", str(c).strip()) if pd.notna(c) else c)
    return df, info


def _build_calendar(args, M, dmin, dmax):
    """休日: 週末 (--weekend) ＋ 祝日 (--jp-holidays on) ＋ holidays.csv の 祝日/会社休日。出勤日は稼働日に戻す"""
    wk_map = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}
    wk = set()
    for w in (getattr(args, "weekend", None) or "sat,sun").split(","):
        w = w.strip().lower()[:3]
        if w:
            if w not in wk_map:
                sys.exit(f"--weekend の曜日が読めません: {w} (mon,tue,wed,thu,fri,sat,sun)")
            wk.add(wk_map[w])
    hol, work = {}, {}
    if (getattr(args, "jp_holidays", None) or "off") == "on":
        try:
            import jpholiday
        except ImportError:
            sys.exit("--jp-holidays on には jpholiday が必要です: pip install --user --break-system-packages jpholiday")
        for d, nm in jpholiday.between(dmin.date(), dmax.date()):
            hol[d] = (nm, "祝日")
    m = M.get("holidays")
    if m is not None:
        for r in m.itertuples():
            d = pd.to_datetime(r.date, errors="coerce")
            if pd.isna(d):
                sys.exit(f"holidays.csv の日付が読めません: {r.date}")
            if r.type == "出勤日":
                work[d.date()] = r.name
            elif r.type in ("祝日", "会社休日"):
                hol[d.date()] = (r.name, r.type)
            else:
                sys.exit(f"holidays.csv の type は 祝日 / 会社休日 / 出勤日 のどれかです: {r.date} {r.type}")

    def is_off(ts):
        d = ts.date() if hasattr(ts, "date") else ts
        if d in work:
            return False
        if d in hol:
            return True
        return d.weekday() in wk
    return is_off, hol, work, wk


def plot_gantt_tree(df, args):
    from matplotlib.patches import Patch, Rectangle
    from matplotlib.lines import Line2D

    hcols = _hier_cols(df)
    for c in ["plan_start", "plan_end"]:
        if c not in df.columns:
            sys.exit(f"列 {c} が必要です")
    df = df.copy()
    M = _load_masters(args)
    master_on = any(v is not None for v in M.values())
    if set(CORE_TASK_COLUMNS) <= set(df.columns):
        keep = CORE_TASK_COLUMNS + [c for c in OPTIONAL_TASK_COLUMNS if c in df.columns]
        df = _sort_by_no(df[keep].copy())  # 追加の列 (工数など) は描画に使わない
    elif master_on:
        miss = [c for c in CORE_TASK_COLUMNS if c not in df.columns]
        sys.exit(f"タスク CSV に必須の列がありません: {', '.join(miss)}")
    deps_on = (getattr(args, "deps", None) or "off") == "on"
    deps_on and _check_deps(df)
    MINFO = {"cat_color": {}, "cat_order": {}, "proj": {}, "owner": {}}
    if master_on:
        df, MINFO = _apply_masters(df, M, getattr(args, "allow_unknown", False))
    for c in ["category", "owner", "note", "actual_start", "actual_end", "progress"]:
        if c not in df.columns:
            df[c] = np.nan
    for c in ["plan_start", "plan_end", "actual_start", "actual_end"]:
        df[c] = pd.to_datetime(df[c], errors="coerce")
    df["category"] = df["category"].fillna("その他")
    df["progress"] = pd.to_numeric(df["progress"], errors="coerce").fillna(0)
    view = getattr(args, "view", None) or "all"
    COLOR_TITLE = "色＝カテゴリ"
    MCOL = dict(MINFO["cat_color"])  # 色の対応 (表示名→色)
    MORD = dict(MINFO["cat_order"])  # 凡例の並び
    lv_cols = [c for c in hcols if c.startswith("level")]
    if view in ("all", "project") and "project" in df.columns and lv_cols:
        if "project_name" not in df.columns:
            df["project_code"] = df["project"].astype(str)
            df["project_name"] = df["project_code"]
        porder = {v["name"]: v["order"] for v in MINFO["proj"].values()}
        if porder:  # プロジェクトはマスタの order 順 (同じプロジェクト内の並びはそのまま)
            df["_po"] = df["project_name"].map(lambda n: porder.get(n, 9999))
            df = df.sort_values("_po", kind="stable").drop(columns="_po")
        hcols = ["project_name"] + lv_cols
        if view == "project" and not getattr(args, "split_by", None):
            args.split_by = "project"
    elif view == "project":
        sys.exit("--view project には project 列と level1… 列が必要です")
    if view == "owner":
        if "owner" not in df.columns:
            sys.exit("--view owner には owner 列が必要です")
        oinfo = {v["name"]: v for v in MINFO["owner"].values()}
        df["owner"] = df["owner"].fillna("（未割当）")
        df["_oo"] = df["owner"].map(lambda n: oinfo.get(n, {}).get("order", 9999))
        df = df.sort_values(["_oo", "owner", "plan_start"], kind="stable").drop(columns="_oo")
        cnt = df["owner"].value_counts()
        df["owner_group"] = df["owner"].map(
            lambda n: f"{n}（{oinfo[n]['dept']}・{cnt[n]}件）" if n in oinfo else f"{n}（{cnt[n]}件）")
        pcode = df["project_code"] if "project_code" in df.columns else pd.Series([""] * len(df), index=df.index)
        leafname = df[hcols[-1]].astype(str)
        labels, seen = [], {}
        for (o, pc, nm) in zip(df["owner_group"], pcode, leafname):
            lab = f"[{pc}] {nm}" if pc else nm
            k = (o, lab)
            seen[k] = seen.get(k, 0) + 1
            labels.append(lab if seen[k] == 1 else f"{lab} ({seen[k]})")
        df["owner_task"] = labels
        hcols = ["owner_group", "owner_task"]
        if "project_name" in df.columns:  # 色＝プロジェクト
            df["category"] = df["project_name"]
            MCOL = {v["name"]: v["color"] for v in MINFO["proj"].values()}
            MORD = {v["name"]: v["order"] for v in MINFO["proj"].values()}
            COLOR_TITLE = "色＝プロジェクト"
    cal_on = (master_on or (getattr(args, "jp_holidays", None) or "off") == "on"
              or getattr(args, "workdays", None) is not None or getattr(args, "weekend", None) is not None)
    WD = (getattr(args, "workdays", None) or "off") == "on"
    DAY_HDR = ({"plan_days": "稼働(予)", "actual_days": "稼働(実)"} if WD else
               {"plan_days": "暦日(予)", "actual_days": "暦日(実)"}) if cal_on else {}
    today = pd.to_datetime(args.today) if args.today else pd.Timestamp.today().normalize()
    rng = args.range or "year"
    notes_mode = args.notes or "table"
    depth = args.depth or 99
    chart_layout = getattr(args, "layout", None) == "chart"
    clean_layout = getattr(args, "layout", None) == "clean"
    legend_mode = (getattr(args, "legend", None) or "bottom") if clean_layout else "bottom"
    page = getattr(args, "page", None)
    split = clean_layout and getattr(args, "bars", None) == "split"
    if getattr(args, "min_row_mm", None) is None:
        args.min_row_mm = 5.5 if split else 4.5  # 2 レーンにするときは少し高く
    if page and clean_layout and legend_mode == "bottom":
        legend_mode = "inline"  # 用紙モードでは下の凡例は使わない
    task_sw = getattr(args, "task_swatches", None) or ("on" if legend_mode == "inline" else "off")
    sw_off = 0.22 if (legend_mode == "inline" or (legend_mode == "header-split" and task_sw == "on")) else 0
    patterns_on = (getattr(args, "patterns", None) or "on") == "on"
    flat = clean_layout and getattr(args, "actual_style", None) == "flat"
    HS_LINES = (0.50, 0.66, 0.82) if patterns_on else (0.50, 0.66)  # header-split: 凡例の行の位置 (用紙モード、上端からのインチ)

    # ---- 列 ----
    spec = args.columns or ("clean" if clean_layout else "full")
    preset = spec in TREE_PRESETS
    spec = TREE_PRESETS.get(spec, spec)
    cols = [c.strip() for c in spec.split(",") if c.strip()]
    bad = [c for c in cols if c not in TREE_COLUMNS]
    if bad:
        sys.exit(f"--columns に使えない列: {bad}  (使える列: {','.join(TREE_COLUMNS)} / プリセット: full, short)")
    missing = [c for c in cols if c in ("no", "depends", "actual_effort", "unit_price") and c not in df.columns]
    if any(c in ("plan_amount", "actual_amount") for c in cols) and "unit_price" not in df.columns:
        missing.append("unit_price")
    if "actual_amount" in cols and "actual_effort" not in df.columns:
        missing.append("actual_effort")
    if missing:
        sys.exit(f"--columns の列 {missing} がタスク CSV にありません")
    # No. は表の先頭 (タスク名の左) に置く。auto: clean レイアウトで列がプリセット (または指定なし) かつ CSV に no があるとき
    no_mode = getattr(args, "no_column", None) or "auto"
    NO_LEAD = "no" in df.columns and no_mode != "off" and ("no" in cols or no_mode == "on" or (no_mode == "auto" and clean_layout and preset))
    cols = [c for c in cols if c != "no"]
    _no_txt = [_no_str(v) for v in df["no"]] if NO_LEAD else []
    if notes_mode == "table" and "note" not in cols and not clean_layout:
        cols.append("note")
    if notes_mode == "right" and "note" in cols:
        cols.remove("note")

    # ---- 用紙モード: 表の列幅・ガント幅をデータに依らず先に決める (全ページで同じ) ----
    if page:
        PW, PH = PAGE_SIZES[page]
        Wc, Hc = PW - 2 * PAGE_MARGIN, PH - 2 * PAGE_MARGIN
        p_fs, p_ind = 7.0, 0.14
        _yrs = {d.year for d in pd.to_datetime(pd.concat([df["plan_start"], df["plan_end"]]),
                                                errors="coerce").dropna()}
        _dsamp = "10/07" if len(_yrs) == 1 else "26/10/07"
        samp = {"plan_start": _dsamp, "plan_end": _dsamp, "actual_start": _dsamp, "actual_end": _dsamp,
                "plan_days": "999", "actual_days": "999", "progress": "100%", "delay": "+99*", "note": "※9 あいうえお…",
                "actual_effort": "9,999.99", "unit_price": "99,999.99", "plan_effort": "9,999.99",
                "plan_amount": "99,999,999.99", "actual_amount": "99,999,999.99"}  # 工数・金額は計算列もあるので見本の幅で
        p_col_ws = []
        for k in cols:
            sm = samp.get(k) or max([str(v) for v in df[k].dropna()] + [""], key=lambda t: _text_w_in(t, p_fs))
            p_col_ws.append(max(_text_w_in(DAY_HDR.get(k, PAGE_ABBR.get(k, k)), p_fs), _text_w_in(sm, p_fs)) + 0.07)
        _need = 0.0
        for lv, hc in enumerate(hcols):
            for v in df[hc].dropna().unique():
                last = lv == len(hcols) - 1
                f = p_fs + (1 if lv == 0 else 0)
                _need = max(_need, lv * p_ind + _text_w_in(("" if last else "▼ ") + str(v), f) * (1.0 if last else 1.08))
        _cap = min(2.65, 0.25 * Wc) if view == "owner" else min(2.1, 0.2 * Wc)  # 担当者ビューは見出しが長い
        p_task_w = min(_need + 0.08 + sw_off + 0.08, _cap)
        p_no_w = (max(_text_w_in(t, p_fs) for t in ["No.", *_no_txt]) + 0.1) if NO_LEAD else 0.0
        p_table_w = p_no_w + p_task_w + sum(p_col_ws)
        p_gap, p_left, p_right = 0.15, 0.0, 0.05
        p_chart_w = Wc - p_left - p_table_w - p_gap - p_right
        if p_chart_w < 2.5:
            sys.exit(f"用紙 {page} に表とガントが収まりません (ガント幅 {p_chart_w:.1f}in)。--columns で列を減らしてください")
        if rng == "week" and not args.window and not args.date_to:  # 1日が --min-day-mm 以上になる週数
            _dfit = int(p_chart_w * 25.4 // args.min_day_mm)
            args.window = f"{max(1, _dfit // 7)}w"
        p_top, p_foot, p_axis = ((1.42 if patterns_on else 1.26) if legend_mode == "header-split" else 1.2), 0.2, 0.3
        p_rows_area = Hc - p_top - p_axis - p_foot
        p_rows_fit = max(5, int(p_rows_area // (args.min_row_mm / 25.4)))
        if args.rows_per_page and args.rows_per_page < p_rows_fit:
            p_rows_fit = args.rows_per_page
        elif args.rows_per_page and args.rows_per_page > p_rows_fit:
            print(f"警告: 行の高さ {args.min_row_mm}mm 以上では 1 ページ {p_rows_fit} 行までです "
                  f"(--rows-per-page {args.rows_per_page} → {p_rows_fit})", file=sys.stderr)
        p_row_h = p_rows_area / p_rows_fit

    # ---- 表示期間 ----
    def act_end_eff(r):
        if pd.notna(r.actual_end):
            return r.actual_end
        if pd.notna(r.actual_start):
            return max(today, r.actual_start)
        return pd.NaT
    df["x_aend"] = [act_end_eff(r) for r in df.itertuples()]
    if rng in ("week", "month"):
        if args.date_from:
            wf = pd.to_datetime(args.date_from)
        else:
            back = 14 if rng == "week" else 28
            wf = today - pd.Timedelta(days=back)
            wf = wf - pd.Timedelta(days=wf.weekday()) if rng == "week" else wf.replace(day=1)
        if args.date_to:
            wt = pd.to_datetime(args.date_to)
        else:
            wdays = _parse_window(args.window or ("8w" if rng == "week" else "4m"))
            wt = wf + pd.Timedelta(days=wdays - 1)
    else:
        wf = pd.to_datetime(args.date_from) if args.date_from else min(df["plan_start"].min(), df["actual_start"].min())
        wt = pd.to_datetime(args.date_to) if args.date_to else max(df["plan_end"].max(), df["x_aend"].max())
    windowed = rng in ("week", "month") or args.date_from or args.date_to

    def visible(r):
        if not windowed:
            return True
        s = min(r.plan_start, r.actual_start) if pd.notna(r.actual_start) else r.plan_start
        e = max(r.plan_end, r.x_aend) if pd.notna(r.x_aend) else r.plan_end
        return s <= wt and e >= wf
    df["_vis"] = [visible(r) for r in df.itertuples()]

    # ---- ツリー構築 ----
    def path_of(r):
        p = []
        for c in hcols:
            v = getattr(r, c) if c.isidentifier() else r[c]
            if pd.isna(v) or str(v).strip() == "":
                break
            p.append(str(v).strip())
        return tuple(p)
    df["_path"] = [path_of(r) for _, r in df.iterrows()]
    children = {}
    root = (("__root__",) if args.root else ())
    def add_child(par, ch):
        children.setdefault(par, [])
        if ch not in children[par]:
            children[par].append(ch)
    for idx, r in df.iterrows():
        p = r["_path"]
        full = root + p
        for k in range(len(full)):
            add_child(full[:k] if k else None, full[:k + 1])
        children.setdefault(full, [])
    leaf_of = {root + r["_path"]: idx for idx, r in df.iterrows()}

    def leaves_under(node):
        if node in leaf_of and not children.get(node):
            return [leaf_of[node]]
        out = []
        for ch in children.get(node, []):
            out += leaves_under(ch)
        return out

    rows, notes_long = [], []
    note_chars = args.note_chars
    def walk(node, level):
        idxs = leaves_under(node)
        if not any(df.loc[idxs, "_vis"]):
            return
        is_leaf = node in leaf_of and not children.get(node)
        kids = children.get(node, [])
        collapsed = (not is_leaf) and level >= depth
        name = args.root if node == ("__root__",) else node[-1]
        row = dict(level=level, name=name, leaf=is_leaf, collapsed=collapsed, node=node,
                   sub=df.loc[idxs], r=(df.loc[idxs[0]] if is_leaf else None),
                   ndesc=len([i for i in idxs if df.loc[i, "_vis"]]), note="")
        if is_leaf and not clean_layout:
            note = "" if pd.isna(row["r"]["note"]) else str(row["r"]["note"]).strip()
            limit = 10 if chart_layout else (note_chars if notes_mode == "table" else 15)
            if len(note) > limit:
                notes_long.append(note)
                k = len(notes_long)
                note = (f"※{k} " + note[:max(1, limit - 2)] + "…") if (notes_mode == "table"
                                                                   and not chart_layout) else f"※{k}"
            row["note"] = note
        rows.append(row)
        if not is_leaf and not collapsed:
            for ch in kids:
                walk(ch, level + 1)
    base_level = 0 if args.root else 1
    for top in children.get(None, []):
        walk(top, base_level)
    n = len(rows)
    if n == 0:
        sys.exit("表示期間内に行がありません")

    # ---- 集計 ----
    def agg(sub):
        ps, pe = sub["plan_start"].min(), sub["plan_end"].max()
        started = sub["actual_start"].notna()
        done = sub["actual_end"].notna()
        a_s = sub["actual_start"].min() if started.any() else pd.NaT
        all_done = bool(done.all())
        ae = sub["actual_end"].max() if all_done else pd.NaT
        running = bool(started.any() and not all_done)
        a_eff = ae if all_done else (max(today, a_s) if running else pd.NaT)
        w = (sub["plan_end"] - sub["plan_start"]).dt.days + 1
        prog = float((sub["progress"] * w).sum() / w.sum())
        return dict(ps=ps, pe=pe, as_=a_s, ae=ae, a_eff=a_eff, running=running, all_done=all_done,
                    prog=prog)
    for row in rows:
        row["agg"] = agg(row["sub"])

    years = {d.year for d in pd.concat([df["plan_start"], df["plan_end"]]).dropna()}
    dfmt = "%m/%d" if len(years) == 1 else "%y/%m/%d"
    fmt_d = lambda d: "" if pd.isna(d) else d.strftime(dfmt)

    # ---- 休日カレンダー ----
    HOL, WORK = {}, {}
    if cal_on:
        _dts = pd.concat([df[c] for c in ["plan_start", "plan_end", "actual_start", "actual_end"]]).dropna()
        _dmin = min(_dts.min(), wf, today) - pd.Timedelta(days=60)
        _dmax = max(_dts.max(), wt, today) + pd.Timedelta(days=60)
        is_off, HOL, WORK, _wk = _build_calendar(args, M, _dmin, _dmax)
    else:
        def is_off(ts):
            return ts.weekday() >= 5
    import datetime as _dtm
    from functools import lru_cache

    @lru_cache(maxsize=None)
    def _nwork_ord(a, b):
        return sum(1 for o in range(a, b + 1) if not is_off(_dtm.date.fromordinal(o)))

    def nwork(a, b):
        """a〜b (両端を含む) の稼働日数"""
        return _nwork_ord(a.toordinal(), b.toordinal()) if b >= a else 0

    # ---- タスクごとの稼働カレンダー: 「暦日」は休日も数える (日数・イナズマ線・バー内の休日の淡色なし) ----
    def is_cal(row):
        return bool(row["leaf"]) and _is_calday(row["r"].get("calendar"))

    CAL_ANY = WD and "calendar" in df.columns and any(_is_calday(v) for v in df["calendar"])
    if CAL_ANY:  # 暦日のタスクがあるときだけ: 親の進捗の重み = 各タスク自身の日数 (無ければ従来どおり暦の日数)
        def _own_prog(sub):
            w = [(r.plan_end - r.plan_start).days + 1 if _is_calday(getattr(r, "calendar", "")) else nwork(r.plan_start, r.plan_end)
                 for r in sub.itertuples()]
            return float(sum(p * x for p, x in zip(sub["progress"], w)) / sum(w)) if sum(w) else 0.0
        [row["agg"].update(prog=_own_prog(row["sub"])) for row in rows if not row["leaf"]]

    # ---- 工数・金額 (--columns に入っているときだけ計算)。予定日数は稼働カレンダーどおり (休日除外 = 稼働日、暦日 = 暦の日数) ----
    if any(k in cols for k in EFFORT_COLS):
        from decimal import Decimal, ROUND_HALF_UP
        _q = lambda x: x.quantize(Decimal("0.01"), ROUND_HALF_UP)  # noqa: E731
        _hours = _hours_per_day(args)
        if cal_on:
            _eoff = is_off
        else:  # 稼働日表示が OFF でも、予定工数は休日 (週末・祝日・休日マスタ) を除いて数える (Web 画面と同じ)
            _ds = pd.concat([df[c] for c in ["plan_start", "plan_end"]]).dropna()
            _eoff = _build_calendar(args, M, _ds.min() - pd.Timedelta(days=7), _ds.max() + pd.Timedelta(days=7))[0]

        def _eff(r):
            ps, pe = r.get("plan_start"), r.get("plan_end")
            n = None
            if pd.notna(ps) and pd.notna(pe) and pe >= ps:
                n = (pe - ps).days + 1 if _is_calday(r.get("calendar")) else sum(1 for d in pd.date_range(ps, pe) if not _eoff(d))
            price, act = _dec(r.get("unit_price")), _dec(r.get("actual_effort"))
            plan = _q(Decimal(n) * _hours) if n is not None else None
            mul = lambda x: _q(x * price) if x is not None and price is not None else None  # noqa: E731
            return {"actual_effort": act, "unit_price": price, "plan_effort": plan, "plan_amount": mul(plan), "actual_amount": mul(act)}

        def eff_cell(row, key):
            if row["leaf"]:
                return _money(_eff(row["r"])[key])
            if key == "unit_price":  # 親の行: 単価は空欄、ほかは子の合計
                return ""
            vals = [v for v in (_eff(r)[key] for _, r in row["sub"].iterrows()) if v is not None]
            return _money(sum(vals, Decimal(0))) if vals else ""

    def cell(row, key):
        a = row["agg"]
        if key in EFFORT_COLS:
            return eff_cell(row, key), ("#868e96" if key.startswith("plan_") else None)
        if key == "depends":  # 影響タスク (先行の No.)
            return (",".join(_dep_tokens(row["r"].get("depends"))) if row["leaf"] else ""), "#1f5fbf"
        if key == "owner":
            owners = row["sub"]["owner"].dropna().unique()
            return (str(owners[0]) if len(owners) == 1 and row["leaf"] else ""), None
        if key == "category":
            return (str(row["r"]["category"]) if row["leaf"] else ""), None
        if key == "progress":
            return f"{a['prog']:.0f}%", None
        if key == "plan_start":
            return fmt_d(a["ps"]), None
        if key == "plan_end":
            return fmt_d(a["pe"]), None
        if key == "actual_start":
            return (fmt_d(a["as_"]) if pd.notna(a["as_"]) else "－"), (None if pd.notna(a["as_"]) else "#aaa")
        if key == "actual_end":
            if pd.isna(a["as_"]):
                return "未着手", "#888"
            if a["running"]:
                return "進行中", "#1f5fbf"
            return fmt_d(a["ae"]), None
        if key == "delay":
            if a["all_done"]:
                d, run = (a["ae"] - a["pe"]).days, False
            elif a["running"] and today > a["pe"]:
                d, run = (today - a["pe"]).days, True
            else:
                return "", None
            if WD and not is_cal(row):  # 稼働日で数える (暦日のタスクは暦の日数のまま)
                one = pd.Timedelta(days=1)
                end = a["ae"] if not run else today
                d = nwork(a["pe"] + one, end) if end > a["pe"] else -nwork(end + one, a["pe"])
            txt = (f"{d:+d}" if d else "±0") + ("*" if run else "")
            return txt, ("#d62728" if d > 0 else ("#1f77b4" if d < 0 else "#333"))
        if key == "plan_days":
            if WD and is_cal(row):
                return f"{(a['pe'] - a['ps']).days + 1}暦", None
            if WD:
                return f"{nwork(a['ps'], a['pe'])}", None
            return f"{(a['pe'] - a['ps']).days + 1}", None
        if key == "actual_days":
            if pd.isna(a["as_"]):
                return "－", "#aaa"
            cal = WD and is_cal(row)
            dd = nwork(a["as_"], a["a_eff"]) if WD and not cal else (a["a_eff"] - a["as_"]).days + 1
            return f"{dd}{'暦' if cal else ''}", ("#1f5fbf" if a["running"] else None)
        if key == "note":
            return row["note"], ("#b35900" if row["note"].startswith("※") else "#333")
        return "", None

    # ---- サイズ ----
    fs = 9
    ind_step = 0.2
    def label_of(row):
        if row["leaf"]:
            return row["name"]
        mark = "▶ " if row["collapsed"] else "▼ "
        extra = f"（{row['ndesc']}件）" if row["collapsed"] else ""
        return mark + row["name"] + extra
    if not args.columns and not page:  # 自動: 全行が空の列は省く (折りたたみ時の担当・カテゴリなど)
        cols = [k for k in cols if any(cell(r, k)[0] for r in rows)]
    if chart_layout:
        cols = []
    min_level = min(r["level"] for r in rows)
    task_w = max((r["level"] - min_level) * ind_step + _text_w_in(label_of(r), fs) for r in rows) + 0.3
    task_w = max(task_w, _text_w_in("タスク", fs) + 0.3)
    if sw_off:
        task_w += sw_off
    col_ws = [max([_text_w_in(DAY_HDR.get(k, TREE_COLUMNS[k]), fs)] + [_text_w_in(cell(r, k)[0], fs) for r in rows]) + 0.22
              for k in cols]
    no_w = (max(_text_w_in(t, fs) for t in ["No.", *_no_txt]) + 0.16) if NO_LEAD else 0.0  # 先頭の No. の欄
    table_w = no_w + task_w + sum(col_ws)
    if notes_mode == "right" and not chart_layout:
        note_w = max([_text_w_in("備考", fs)] + [_text_w_in(r["note"], fs) for r in rows]) + 0.3
    else:
        note_w = 0.0
    span = (wt - wf).days + 1
    if rng == "week":
        chart_w = args.width or float(np.clip(span * 0.24, 8, 20))
    elif rng == "month":
        chart_w = args.width or float(np.clip(span * 0.11, 8, 18))
    else:
        chart_w = args.width or float(np.clip(span * 0.036, 10, 16))
    if chart_layout and not args.width:
        if rng == "week":
            chart_w = float(np.clip(span * 0.34, 14, 24))
        elif rng == "month":
            chart_w = float(np.clip(span * 0.15, 14, 22))
        else:
            chart_w = float(np.clip(span * 0.058, 16, 22))
        chart_w = max(chart_w, 4.2 * table_w)  # ガント部分を全体の8割以上に

    if clean_layout and not args.width:
        if rng == "week":
            chart_w = float(np.clip(span * 0.26, 10, 20))
        elif rng == "month":
            chart_w = float(np.clip(span * 0.12, 10, 18))
        else:
            chart_w = float(np.clip(span * 0.04, 12, 18))

    if args.min_day_px:  # 1日 = 最低 N ピクセルになるよう幅を自動決定
        tot_days = span + (0 if windowed else 2 * max(3, span * 0.015))
        need = tot_days * args.min_day_px / args.dpi
        cap = args.max_width - table_w - note_w - 0.75
        if need > cap:
            print(f"警告: 1日={args.min_day_px}px にはガント部分の幅 {need:.1f}in が必要ですが、"
                  f"--max-width {args.max_width:g}in を超えるため {cap:.1f}in に制限します "
                  f"(1日≈{cap * args.dpi / tot_days:.1f}px)。--range week / month や --from/--to で"
                  "期間を絞るか、--max-width を増やしてください。", file=sys.stderr)
            need = cap
        chart_w = max(chart_w, need) if not args.width else chart_w

    if page:
        fs, ind_step = p_fs, p_ind
        task_w, col_ws, table_w, note_w, chart_w, no_w = p_task_w, p_col_ws, p_table_w, 0.0, p_chart_w, p_no_w
        _days = span + (0 if windowed else 2 * max(3, span * 0.015))
        mm_day = chart_w * 25.4 / _days
        print(f"用紙 {page}: ガント幅 {chart_w * 25.4:.0f}mm / {_days:.0f}日 → 1日 = {mm_day:.2f}mm "
              f"({mm_day / 25.4 * args.dpi:.1f}px @ {args.dpi}dpi), 1ページ最大 {p_rows_fit} 行 "
              f"(行の高さ {p_row_h * 25.4:.1f}mm)")
        if rng == "week" and mm_day < args.min_day_mm:
            print(f"警告: 1日 = {mm_day:.2f}mm で --min-day-mm {args.min_day_mm} 未満です。"
                  "--window を短くするか列を減らしてください", file=sys.stderr)

    inazuma = (getattr(args, "inazuma", None) or "off") == "on"
    INAZUMA_C = getattr(args, "inazuma_color", None) or "#e8590c"  # 既定: 濃いオレンジ (予定超過の赤・今日の赤と区別)
    OVR = getattr(args, "overrun_color", None) or "#d62728"  # 予定超過の色
    BAND = getattr(args, "today_band", None)  # 今日の列の色 (None=なし)

    def _mix_white(col, k):
        from matplotlib.colors import to_rgb
        r, g, b = to_rgb(col)
        return (r + (1 - r) * k, g + (1 - g) * k, b + (1 - b) * k)

    def inazuma_point(row):
        """イナズマ線の折れ点 x (None=今日の線のまま)。進捗点＝予定開始＋進捗%×予定日数"""
        if not row["leaf"] and not getattr(args, "inazuma_parents", False):
            return None
        a = row["agg"]
        if a["all_done"]:
            return None  # 完了
        if pd.isna(a["as_"]) and a["ps"] > today:
            return None  # まだ始まる予定でない
        ps_, pe_ = mdates.date2num(a["ps"]), mdates.date2num(a["pe"]) + 1
        if WD and not is_cal(row):  # 稼働日の軸で: 予定開始＋進捗%×予定稼働日数 → 休日を飛ばして暦の日付に戻す (暦日のタスクは暦の軸)
            wds = [d for d in pd.date_range(a["ps"], a["pe"]) if not is_off(d)]
            if wds:
                T = (a["prog"] / 100.0) * len(wds)
                k = int(T)
                return pe_ if k >= len(wds) else mdates.date2num(wds[k]) + (T - k)
        return ps_ + (a["prog"] / 100.0) * (pe_ - ps_)

    def month_header(ax, ipd, fs):
        """月ビューの見出し: 上に「YYYY年MM月」の行と「第N週」の行 (月曜始まり・1 日を含む週が第1週)、下に月。
        週・月の境目の線を見出しの中まで伸ばして、下のグリッドと続けて見せる"""
        from matplotlib.transforms import blended_transform_factory as _bt
        num = mdates.date2num
        ax.xaxis.set_major_formatter(plt.NullFormatter())
        ax.tick_params(axis="x", which="both", length=0)
        lo, hi = mdates.num2date(ax.get_xlim()[0]).date(), mdates.num2date(ax.get_xlim()[1]).date()
        days = pd.date_range(pd.Timestamp(lo), pd.Timestamp(hi) - pd.Timedelta(days=1), freq="D")
        cuts = lambda f: [d for k, d in enumerate(days) if k == 0 or f(d)]  # noqa: E731
        spans = lambda ds_: list(zip(ds_, [*ds_[1:], days[-1] + pd.Timedelta(days=1)]))  # noqa: E731
        fit = lambda cands, w: next((t for t in cands if _text_w_in(t, fs) + 0.04 <= w), "")  # noqa: E731
        pt = ax.figure.dpi / 72 / ax.bbox.height  # 1pt = 軸の高さの何割か
        tr = _bt(ax.transData, ax.transAxes)
        ROW_H = fs + 4  # 1 行の高さ (pt)

        def put(x, row, text, color, top=True):
            ax.annotate(text, (x, 1 if top else 0), xycoords=("data", "axes fraction"), xytext=(0, (2 + row * ROW_H) if top else -3),
                        textcoords="offset points", ha="center", va="bottom" if top else "top", fontsize=fs, color=color,
                        annotation_clip=False)
        for a, b in spans(cuts(lambda d: d.day == 1)):
            w = (b - a).days * ipd
            put(num(a) + (b - a).days / 2, 1, fit([f"{a.year}年{a.month:02d}月", f"{a.month}月"], w), "#333")
            put(num(a) + (b - a).days / 2, 0, fit([f"{a.year}年{a.month:02d}月", f"{a.month}月"], w), "#333", top=False)
        for a, b in spans(cuts(lambda d: d.day == 1 or d.weekday() == 0)):
            n_ = (a.day - 1 + a.replace(day=1).weekday()) // 7 + 1
            put(num(a) + (b - a).days / 2, 0, fit([f"第{n_}週", f"{n_}"], (b - a).days * ipd), "#555")  # 月は上の行にあるので付けない
        top = 1 + (2 + 2 * ROW_H) * pt
        for d in days[1:]:
            if d.day == 1 or d.weekday() == 0:
                ax.plot([num(d)] * 2, [1, top if d.day == 1 else 1 + (2 + ROW_H) * pt], transform=tr, clip_on=False,
                        color="#6f7680" if d.day == 1 else "#a3aab3", linewidth=0.9 if d.day == 1 else 0.6, zorder=3)
        ax.plot([num(days[0]), num(days[-1]) + 1], [1 + (2 + ROW_H) * pt] * 2, transform=tr, clip_on=False, color="#d5d9de", linewidth=0.5)

    DEP_C = "#5c6b7a"  # 影響線: 関係を示すだけ (日付の矛盾の判定はしない)

    def draw_deps(prow, ax, ipd):
        """影響線: 先行タスクの予定バーの終わり → このタスクの予定バーの始まり (かぎ形＋小さな矢じり)。
        相手がこのページにない線は短い線と No. だけ"""
        num = mdates.date2num
        yo = 0.19 if split else 0.0
        d = 0.09 / ipd  # かぎの張り出し (約 2.3mm)
        lw = 0.7 if ipd * 25.4 >= 1.5 else 0.45  # 年ビューは細く
        leaf = [(i, r) for i, r in enumerate(prow) if r["leaf"]]
        at = {_no_str(r["r"]["no"]): (i, r) for i, r in leaf}
        xs_ = lambda r: num(r["agg"]["ps"])  # noqa: E731
        xe_ = lambda r: num(r["agg"]["pe"]) + 1  # noqa: E731

        def head(x, y, col):
            ax.annotate("", xy=(x, y), xytext=(x - d, y), arrowprops=dict(arrowstyle="-|>", mutation_scale=5, lw=lw, color=col,
                        shrinkA=0, shrinkB=0), zorder=5.6, annotation_clip=False)

        def link(pi, p, si, s_):
            col = DEP_C
            x1_, y1_, x2_, y2_ = xe_(p), pi - yo, xs_(s_), si - yo
            mid = (min(pi, si) + 0.5) if si != pi else pi + 0.5
            pts = ([(x1_, y1_), (x1_ + d, y1_), (x1_ + d, y2_), (x2_ - d, y2_)] if x2_ - d >= x1_ + d else
                   [(x1_, y1_), (x1_ + d, y1_), (x1_ + d, mid), (x2_ - 2 * d, mid), (x2_ - 2 * d, y2_), (x2_ - d, y2_)])
            ax.plot(*zip(*pts), color=col, lw=lw, zorder=5.5, solid_joinstyle="miter")
            head(x2_, y2_, col)

        def stub_in(no_, si, s_):  # 先行がこのページにない
            col = DEP_C
            x2_, y2_ = xs_(s_), si - yo
            ax.plot([x2_ - 2.5 * d, x2_ - d], [y2_, y2_], color=col, lw=lw, zorder=5.5, linestyle=(0, (2, 1)))
            head(x2_, y2_, col)
            ax.text(x2_ - 2.6 * d, y2_, f"No.{no_}", fontsize=4.5, color=col, ha="right", va="center", zorder=5.7)

        def stub_out(pi, p, no_):  # 後のタスクがこのページにない
            x1_, y1_ = xe_(p), pi - yo
            ax.plot([x1_, x1_ + 2.5 * d], [y1_, y1_], color=DEP_C, lw=lw, zorder=5.5, linestyle=(0, (2, 1)))
            ax.text(x1_ + 2.6 * d, y1_, f"→No.{no_}", fontsize=4.5, color=DEP_C, ha="left", va="center", zorder=5.7)

        for si, s_ in leaf:
            for no_ in _dep_tokens(s_["r"].get("depends")):
                link(*at[no_], si, s_) if no_ in at else stub_in(no_, si, s_)
        [stub_out(*at[no_], _no_str(r["r"]["no"])) for r in all_rows if r["leaf"] and _no_str(r["r"]["no"]) not in at
         for no_ in _dep_tokens(r["r"].get("depends")) if no_ in at]

    def hdr_of(k):
        if k in DAY_HDR:
            return DAY_HDR[k]
        return PAGE_ABBR.get(k, TREE_COLUMNS[k]) if page else TREE_COLUMNS[k]

    def disp_label(row):
        lab = label_of(row)
        if not page:
            return lab
        big = row["level"] <= min_level and not row["leaf"]
        f = fs + (1 if big else 0)
        k = 1.0 if row["leaf"] else 1.08  # 太字の分
        avail = task_w - 0.08 - (row["level"] - min_level) * ind_step - sw_off - 0.06
        if _text_w_in(lab, f) * k <= avail:
            return lab
        while lab and _text_w_in(lab + "…", f) * k > avail:
            lab = lab[:-1]
        return lab + "…"

    all_rows = rows

    def render_page(rows, title, foot=None):
        n = len(rows)
        row_h = 0.38 if chart_layout else (0.32 if clean_layout else 0.3)
        top_m = 1.25 if title else 0.7
        bot_m = 0.9 + (0.21 * len(notes_long) + 0.15 if notes_long else 0) + (0.55 if clean_layout else 0)
        if legend_mode != "bottom":
            bot_m = 0.45  # 下の凡例・説明行なし (目盛りラベル分だけ)
        # 凡例の項目 (ラベル) を先に決める
        LFS = 7.0
        _shown_cats = {r["r"]["category"] for r in all_rows if r["leaf"]}
        leg_cats = [c for c in dict.fromkeys(df["category"]) if c in _shown_cats]
        if MORD:
            leg_cats = sorted(leg_cats, key=lambda c: MORD.get(c, 9999))
        leg_lv1 = [g for g in dict.fromkeys(p[0] for p in df["_path"] if p)
                   if any(r["leaf"] and r["r"]["_path"][0] == g for r in all_rows)]
        leg_bar = (["上＝予定／下＝実績", "予定超過", "進行中（今日まで）"] if split else
                   ["予定", "実績", "予定超過", "進行中（今日まで）", "予定（親・子）", "実績（親・子）"])
        if windowed:
            leg_bar.append("期間外へ続く")
        if wf <= today <= wt:
            leg_bar.append("今日")
        leg_groups = [("色＝カテゴリ", leg_cats), ("模様＝大項目", leg_lv1), ("バー", leg_bar)]
        if not patterns_on:
            leg_groups = [g for g in leg_groups if g[0] != "模様＝大項目"]

        def _item_w(lab):
            return (1.5 + 0.4 + 0.9) * LFS / 72 + _text_w_in(lab, LFS)

        def _chunks(labels, avail):
            out, cur, w = [], [], 0.0
            for lab in labels:
                iw = _item_w(lab)
                if cur and w + iw > avail:
                    out.append(cur)
                    cur, w = [], 0.0
                cur.append(lab)
                w += iw
            if cur:
                out.append(cur)
            return out
        hdr_rows = []
        if legend_mode == "header-split" and not page:
            top_m += 0.5 if patterns_on else 0.34  # 副題の下に凡例 3 行 (模様なしは 2 行)
        if legend_mode == "header":
            lab_w = max(_text_w_in(t + "：", LFS) for t, _ in leg_groups) + 0.08
            avail = max(1.0, table_w - lab_w - 0.05)
            for t, labs in leg_groups:
                for k, ch in enumerate(_chunks(labs, avail)):
                    hdr_rows.append((t if k == 0 else "", ch))
            need_h = 0.16 + len(hdr_rows) * 0.17
            free_h = top_m - (0.62 * 0.32 + 0.14)
            if need_h > free_h:
                top_m += need_h - free_h
        left_m, right_m, gap = 0.15, 0.25, 0.35
        if page:  # 用紙サイズ固定 (図＝余白を除いた印刷範囲)。行は上から詰め、行が少なければ下が空く
            row_h, top_m = p_row_h, p_top
            left_m, right_m, gap = p_left, p_right, p_gap
            W, H = Wc, Hc
            bot_m = H - top_m - n * row_h
        else:
            W = left_m + table_w + gap + chart_w + note_w + right_m
            H = top_m + n * row_h + bot_m
        fig = plt.figure(figsize=(W, H))
        fig._no_tight = True
        if page:
            fig._page = (PW, PH, PAGE_MARGIN)
        yb, hh = bot_m / H, n * row_h / H
        ax_t = fig.add_axes([left_m / W, yb, table_w / W, hh])
        ax = fig.add_axes([(left_m + table_w + gap) / W, yb, chart_w / W, hh])
        axes = [ax_t, ax]
        ax_n = None
        if note_w:
            ax_n = fig.add_axes([(left_m + table_w + gap + chart_w) / W, yb, note_w / W, hh])
            axes.append(ax_n)
        for a in [ax_t] + ([ax_n] if ax_n else []):
            a.set_xlim(0, 1)
            a.set_xticks([])
            a.set_yticks([])
            for sp in a.spines.values():
                sp.set_visible(False)
        ax.set_yticks([])
        for a in axes:
            a.set_ylim(n - 0.5, -0.5)

        # ---- 背景 ----
        shade = {0: "#b9c6d6", 1: "#cfd8e3", 2: "#e6ebf1"}
        for i, row in enumerate(rows):
            colr = shade.get(row["level"], "#eef1f5") if not row["leaf"] else ("#f4f5f7" if i % 2 == 0 else None)
            for a in axes:
                if colr:
                    a.axhspan(i - 0.5, i + 0.5, color=colr, zorder=0, lw=0)
                if not row["leaf"] and row["level"] <= max(min_level, 1) and i > 0:
                    a.axhline(i - 0.5, color="#444", lw=1.1, zorder=1)

        # ---- 表 ----
        tx = lambda inch: inch / table_w
        hy = -0.62
        ax_t.text(tx(no_w + 0.08), hy, "タスク", fontsize=fs, fontweight="bold", va="bottom", clip_on=False)
        if NO_LEAD:
            ax_t.text(tx(no_w - 0.06), hy, "No.", fontsize=fs, fontweight="bold", ha="right", va="bottom", clip_on=False)
            ax_t.axvline(tx(no_w), color="#c8ccd2", lw=0.6, zorder=1)
        x = no_w + task_w
        centers = []
        for k, w in zip(cols, col_ws):
            is_note = k == "note"
            centers.append((x + 0.1) if is_note else (x + w - 0.08) if k in EFFORT_COLS else (x + w / 2))  # 工数・金額は右寄せ (小数点をそろえる)
            ax_t.text(tx(centers[-1]), hy, hdr_of(k), fontsize=fs, fontweight="bold",
                      ha="left" if is_note else "right" if k in EFFORT_COLS else "center", va="bottom", clip_on=False)
            ax_t.axvline(tx(x), color="#c8ccd2", lw=0.6, zorder=1)
            x += w
        for a in axes:
            a.axhline(-0.5, color="#444", lw=1.0, clip_on=False)
        if ax_n:
            ax_n.text(0.08, hy, "備考", fontsize=fs, fontweight="bold", va="bottom", clip_on=False)
        for i, row in enumerate(rows):
            bold = not row["leaf"]
            big = row["level"] <= min_level and not row["leaf"]
            NO_LEAD and row["leaf"] and ax_t.text(tx(no_w - 0.06), i, _no_str(row["r"]["no"]), ha="right", va="center",
                                                  fontsize=fs - 0.5, color="#555")
            ax_t.text(tx(no_w + 0.08 + (row["level"] - min_level) * ind_step + sw_off), i, disp_label(row), va="center",
                      fontsize=fs + (1 if big else 0), fontweight="bold" if bold else "normal")
            for k, cx in zip(cols, centers):
                t, colr = cell(row, k)
                if t:
                    ax_t.text(tx(cx), i, t, ha="left" if k == "note" else "right" if k in EFFORT_COLS else "center", va="center",
                              fontsize=fs, color=colr or "#222", fontstyle="italic" if k in ("plan_effort", "plan_amount") else "normal",
                              fontweight="bold" if (bold and k != "note") or (k == "delay" and colr == "#d62728")
                              else "normal")
            if ax_n and row["note"]:
                ax_n.text(0.08, i, row["note"], va="center", fontsize=fs,
                          color="#b35900" if row["note"].startswith("※") else "#333")

        # ---- バー ----
        pal = ["#1f77b4", "#ff7f0e", "#2ca02c", "#9467bd", "#8c564b", "#e377c2", "#17becf",
               "#bcbd22", "#7f7f7f"]
        shown_leaf_idx = [r["sub"].index[0] for r in rows if r["leaf"]]
        ccol = {c: pal[i % len(pal)] for i, c in enumerate(dict.fromkeys(df["category"]))}  # 表示に依らず固定
        if MCOL:
            ccol.update(MCOL)  # マスタの色
        shown_cats = set(df.loc[shown_leaf_idx, "category"]) if shown_leaf_idx else set()
        cats = [c for c in ccol if c in shown_cats]
        num = mdates.date2num
        x0, x1 = num(wf), num(wt) + 1
        if not windowed:
            pad = max(3, span * 0.015)
            x0, x1 = x0 - pad, x1 + pad

        def actual_bar(i, a0, a1, pe, y, h, color, running):
            if a1 <= a0:
                a1 = a0 + 0.5
            hatch = "////" if running else None
            ok_end = min(a1, pe)
            if ok_end > a0:
                ax.barh(y, ok_end - a0, left=a0, height=h, color=color, hatch=hatch,
                        edgecolor="white" if running else color, linewidth=0, zorder=4)
            if a1 > pe:
                l0 = max(a0, pe)
                ax.barh(y, a1 - l0, left=l0, height=h, color="#d62728", hatch=hatch,
                        edgecolor="white" if running else "#d62728", linewidth=0, zorder=4)
            if running:
                ax.add_patch(Rectangle((a0, y - h / 2), a1 - a0, h, fill=False, edgecolor="#333",
                                       linewidth=0.6, zorder=5))
                if x0 < a1 < x1:
                    ax.plot(a1, y, marker=">", color="#333", markersize=4, zorder=5)

        ipd = chart_w / (x1 - x0)  # 1日あたりのインチ
        has_ms = [False]

        def tw_days(t, f):
            return _text_w_in(t, f) / ipd

        def chart_row(i, row):
            from matplotlib.colors import to_rgba
            a = row["agg"]
            leaf = row["leaf"]
            ps, pe = num(a["ps"]), num(a["pe"]) + 1
            fsl = 7.5
            gapd = 0.07 / ipd
            mrg = 0.22 / ipd  # 端の ◀▶ 用の余白
            if leaf:
                c = ccol.get(row["r"]["category"], "#7f7f7f")
                h, fa, la = 0.56, 0.62, 0.22
            else:
                c = {0: "#1b2631", 1: "#2b3a4a"}.get(row["level"], "#5d6d7e")
                h, fa, la = 0.42, 0.55, 0.16
            # マイルストーン
            if leaf and a["ps"] == a["pe"]:
                has_ms[0] = True
                from matplotlib import patheffects as pe_
                ax.plot(ps + 0.5, i, marker="D", markersize=9, color=c, markeredgecolor="black",
                        markeredgewidth=0.6, zorder=5)
                lab = f"{row['name']} {a['ps']:%m/%d}"
                if pd.notna(a["ae"]) and a["ae"] != a["pe"]:
                    dd = (a["ae"] - a["pe"]).days
                    lab += f"（実績{a['ae']:%m/%d} {dd:+d}日）"
                elif pd.notna(a["ae"]):
                    lab += " 済"
                xx = ps + 0.5 + 0.12 / ipd
                if xx + tw_days(lab, fsl) > x1 - mrg:
                    ax.text(ps + 0.5 - 0.12 / ipd, i, lab, ha="right", va="center", fontsize=fsl, color="#333", zorder=6,
                            path_effects=[pe_.withStroke(linewidth=2.2, foreground="white")])
                else:
                    ax.text(xx, i, lab, ha="left", va="center", fontsize=fsl, color="#333", zorder=6,
                            path_effects=[pe_.withStroke(linewidth=2.2, foreground="white")])
                return
            ax.barh(i, pe - ps, left=ps, height=h, color=to_rgba(c, la), edgecolor=c, linewidth=1.0, zorder=2)
            prog = max(0.0, min(1.0, a["prog"] / 100))
            if prog > 0:
                ax.barh(i, (pe - ps) * prog, left=ps, height=h, color=to_rgba(c, fa), linewidth=0, zorder=3)
            a_end = None
            if pd.notna(a["as_"]):
                a0, a1 = num(a["as_"]), num(a["a_eff"]) + 1
                a_end = a1
                actual_bar(i, a0, a1, pe, i + h / 2 + 0.09, 0.12, c if leaf else "#3d6fa8", a["running"])
            vis_l, vis_r = max(ps, x0), min(pe, x1)
            right_edge = max(pe, a_end or pe)
            # ---- ラベル候補 (優先度: 小さいほど重要) ----
            items = []  # (prio, order, text, color, kws, preferred)
            if a["all_done"]:
                d = (a["ae"] - a["pe"]).days
            elif a["running"] and today > a["pe"]:
                d = (today - a["pe"]).days
            else:
                d = 0
            if d > 0:
                items.append((1, 0, f"+{d}日", "#d62728", dict(fontweight="bold"), "R"))
            elif d < 0:
                items.append((1, 0, f"{d}日", "#1f77b4", dict(fontsize=fsl - 0.5), "R"))
            if row["note"].startswith("※"):
                items.append((1.5, 5, row["note"], "#b35900", dict(fontweight="bold"), "R"))
            if leaf:
                if prog > 0 or pd.notna(a["as_"]):
                    items.append((2, 2, f"{a['prog']:.0f}%", "#1a1a1a", dict(fontweight="bold"), "I"))
                own = row["sub"]["owner"].dropna()
                if len(own):
                    items.append((3, 3, str(own.iloc[0]), "#666", {}, "R"))
            else:
                nch = len(children.get(row.get("node"), [])) if not row["collapsed"] else row["ndesc"]
                word = "配下" if row["collapsed"] else "子"
                items.append((2, 2, f"{word}{nch}件・進捗{a['prog']:.0f}%", "#2b3a4a", dict(fontweight="bold"), "R"))
            if bar_dates:
                items.append((4, 1, a["ps"].strftime("%m/%d"), "#888", dict(fontsize=fsl - 0.5), "L"))
                items.append((4, 1, a["pe"].strftime("%m/%d"), "#888", dict(fontsize=fsl - 0.5), "R"))
            if row["note"] and not row["note"].startswith("※"):
                items.append((5, 6, row["note"], "#777", dict(style="italic"), "R"))

            caps = {
                "R": (x1 - mrg) - (right_edge + gapd) if right_edge < x1 - mrg else -1,
                "L": (vis_l - gapd) - (x0 + mrg) if vis_l > x0 + mrg else -1,
                "I": (vis_r - vis_l) - 2 * gapd - (mrg if ps < x0 else 0) - (mrg if pe > x1 else 0),
            }
            placed = {"R": [], "L": [], "I": []}
            for it in sorted(items, key=lambda t: t[0]):
                prio, order, text, col, kw, pref = it
                w = tw_days(text, kw.get("fontsize", fsl)) + gapd * 1.5
                if pref == "I":
                    tries = ["I", "R", "L"]
                elif pref == "L":
                    tries = ["L"]
                else:
                    tries = ["R", "L", "I"] if prio < 4 else ["R"]
                for z in tries:
                    if caps[z] >= w:
                        caps[z] -= w
                        placed[z].append(it)
                        break
            # 描画
            from matplotlib import patheffects as pe_

            def kwd(kw):
                k2 = dict(kw)
                k2.setdefault("fontsize", fsl)
                k2["path_effects"] = [pe_.withStroke(linewidth=2.2, foreground="white")]
                return k2
            xr = right_edge + gapd
            for it in sorted(placed["R"], key=lambda t: t[1]):
                _, _, text, col, kw, _ = it
                ax.text(xr, i, text, ha="left", va="center", color=col, zorder=6, **kwd(kw))
                xr += tw_days(text, kwd(kw)["fontsize"]) + gapd * 1.5
            xl = vis_l - gapd
            for it in sorted(placed["L"], key=lambda t: -t[1]):
                _, _, text, col, kw, _ = it
                ax.text(xl, i, text, ha="right", va="center", color=col, zorder=6, **kwd(kw))
                xl -= tw_days(text, kwd(kw)["fontsize"]) + gapd * 1.5
            xi = vis_l + gapd + (mrg if ps < x0 else 0)
            for it in sorted(placed["I"], key=lambda t: t[1]):
                _, _, text, col, kw, _ = it
                ax.text(xi, i - 0.02, text, ha="left", va="center", color=col, zorder=6, **kwd(kw))
                xi += tw_days(text, kwd(kw)["fontsize"]) + gapd * 1.5

        px_day = chart_w * args.dpi / (x1 - x0)
        if (args.min_day_px or args.day_ticks) and not getattr(args, "_pxday_done", False):
            args._pxday_done = True
            print(f"1日 = {px_day:.1f} px（ガント部分 {chart_w:.2f}in × {args.dpi}dpi / {x1 - x0:.1f}日）")
        day_mode = bool(args.min_day_px or args.day_ticks)
        from matplotlib.collections import LineCollection
        tick_segs, tick_cols, cap_segs = [], [], []

        lv1_list = list(dict.fromkeys(p[0] for p in df["_path"] if p))
        lv1_hatch = {g: CLEAN_HATCHES[k % len(CLEAN_HATCHES)] for k, g in enumerate(lv1_list)}
        if not patterns_on:  # --patterns off: どのバーにも模様を付けない (色＝カテゴリだけ)
            lv1_hatch = {g: "" for g in lv1_list}

        def clean_actual(y, a0, a1, pe, h, color, running, caps=None):
            from matplotlib.colors import to_rgba
            if a1 <= a0:
                a1 = a0 + 0.5
            if flat:
                return flat_actual(y, a0, a1, pe, h, color, running)
            segs = []
            if min(a1, pe) > a0:
                segs.append((a0, min(a1, pe), color))
            if a1 > pe:
                segs.append((max(a0, pe), a1, OVR))
            for s0, s1, col in segs:
                if running:  # 進行中: 淡い単色＋破線の枠 (模様は使わない)
                    ax.barh(y, s1 - s0, left=s0, height=h, color=to_rgba(col, 0.55), edgecolor="none",
                            linewidth=0, zorder=4)
                else:
                    ax.barh(y, s1 - s0, left=s0, height=h, color=col, linewidth=0, zorder=4)
            if running:
                ax.add_patch(Rectangle((a0, y - h / 2), a1 - a0, h, fill=False, edgecolor="#222",
                                       linewidth=0.9, linestyle=(0, (3, 2)), zorder=5))
            if caps == "lane":  # 2 レーン方式: レーンの高さちょうどの端線 (上下のレーンをつながない)
                for xx in (a0, a1):
                    cap_segs.append([(xx, y - h / 2), (xx, y + h / 2)])
            elif day_mode:  # 端に細い縦線 (1日のバーでも幅が見える)
                for xx in (a0, a1):
                    cap_segs.append([(xx, y - h / 2 - 0.04), (xx, y + h / 2 + 0.04)])

        LANE_H, LANE_OFF = 0.28, 0.19  # 上＝予定 (i-0.19)、下＝実績 (i+0.19)、すき間 0.10 行
        GAPS = WD and (getattr(args, "holiday_gaps", None) or "on") == "on" and ipd * 25.4 >= 1.5
        off_nums = ([num(d) for d in pd.date_range(pd.Timestamp(mdates.num2date(x0).date()), wt) if is_off(d)]
                    if GAPS else [])

        def gap_cover(y, h, s0, s1):
            """稼働日モード (週ビュー): バーの中の休日を淡く (白を重ねて約 4 割の濃さに)"""
            for xd in off_nums:
                if s0 <= xd < s1:
                    ax.add_patch(Rectangle((xd, y - h / 2), 1, h, facecolor="white", alpha=0.6, linewidth=0,
                                           zorder=4.3))
        mm_day_ = ipd * 25.4
        flat_caps, flat_cap_cols = [], []

        def _darker(col, k=0.35):
            from matplotlib.colors import to_rgb
            r, g, b = to_rgb(col)
            return (r * (1 - k), g * (1 - k), b * (1 - k))

        def flat_actual(y, a0, a1, pe, h, color, running):
            """--actual-style flat: 枠なしの単色。予定超過は赤。進行中は先が ▶ の矢印 (先端＝今日)"""
            from matplotlib.patches import Polygon
            red = OVR
            tl = 0.0
            if running:
                tl = min(1.2 / mm_day_, a1 - a0)  # 先端の長さ: 最低 1.2mm (バーより長くはしない)
            body_end = a1 - tl
            for s0, s1, col in ((a0, min(body_end, pe), color), (max(a0, pe), body_end, red)):
                if s1 > s0:
                    ax.barh(y, s1 - s0, left=s0, height=h, color=col, linewidth=0, zorder=4)
            if running and tl > 0:
                tip_col = red if (a1 - tl / 2) > pe else color
                ax.add_patch(Polygon([(body_end, y - h / 2), (a1, y), (body_end, y + h / 2)], closed=True,
                                     facecolor=tip_col, edgecolor="none", zorder=4))
            if mm_day_ < 1.5:  # 年ビュー: 同じ色相の少し濃い細い端線 (枠に見えないよう 0.4pt)
                ends = [(a0, color if a0 < pe else red)]
                if not running:
                    ends.append((a1, red if a1 > pe else color))
                for xx, col in ends:
                    flat_caps.append([(xx, y - h / 2), (xx, y + h / 2)])
                    flat_cap_cols.append(_darker(col))

        def split_row(i, row):
            """--bars split: 親・子・孫とも同じ規則。上レーン＝予定 (淡色＋大項目の模様＋枠)、下レーン＝実績 (濃い単色)"""
            from matplotlib.colors import to_rgba
            a = row["agg"]
            ps, pe = num(a["ps"]), num(a["pe"]) + 1
            path0 = row["node"][1] if (args.root and len(row["node"]) > 1) else (row["node"][0] if row["node"] else "")
            if row["leaf"]:
                c = ccol.get(row["r"]["category"], "#7f7f7f")
                path0 = row["r"]["_path"][0]
            else:
                c = {0: "#1b2631", 1: "#2b3a4a"}.get(row["level"], "#4f5f70")
            hatch = lv1_hatch.get(path0, "")
            yp, ya = i - LANE_OFF, i + LANE_OFF
            ax.barh(yp, pe - ps, left=ps, height=LANE_H, color=to_rgba(c, 0.20), zorder=2, linewidth=0)
            ax.barh(yp, pe - ps, left=ps, height=LANE_H, color="none", edgecolor=to_rgba(c, 0.75),
                    hatch=hatch, linewidth=0, zorder=2.1)
            ax.add_patch(Rectangle((ps, yp - LANE_H / 2), pe - ps, LANE_H, fill=False, edgecolor=c,
                                   linewidth=0.6, zorder=2.2))
            if not flat:  # flat では予定の端はカテゴリ色の枠で十分 (黒い端線なし)
                for xx in (ps, pe):
                    cap_segs.append([(xx, yp - LANE_H / 2), (xx, yp + LANE_H / 2)])
            lanes = [(yp, ps, pe)]
            if pd.notna(a["as_"]):
                clean_actual(ya, num(a["as_"]), num(a["a_eff"]) + 1, pe, LANE_H, c, a["running"], caps="lane")
                lanes.append((ya, num(a["as_"]), num(a["a_eff"]) + 1))
            if GAPS and not is_cal(row):  # 暦日のタスクは休日も動くので淡くしない
                for yy, l0, l1 in lanes:
                    gap_cover(yy, LANE_H, l0, l1)
            off = 0.05 / ipd
            for yy, l0, l1 in lanes:  # 期間外へ続く: レーンごとに小さな ◀ ▶ (そのレーンの上に)
                if l0 < x0:
                    ax.plot(x0 + off, yy, marker="<", markersize=2.4, color="#111", markeredgecolor="white",
                            markeredgewidth=0.3, zorder=6, clip_on=False)
                if l1 > x1:
                    ax.plot(x1 - off, yy, marker=">", markersize=2.4, color="#111", markeredgecolor="white",
                            markeredgewidth=0.3, zorder=6, clip_on=False)

        def clean_row(i, row):
            from matplotlib.colors import to_rgba
            if split:
                return split_row(i, row)
            a = row["agg"]
            ps, pe = num(a["ps"]), num(a["pe"]) + 1
            if row["leaf"]:
                c = ccol.get(row["r"]["category"], "#7f7f7f")
                hatch = lv1_hatch.get(row["r"]["_path"][0], "")
                ax.barh(i, pe - ps, left=ps, height=0.62, color=to_rgba(c, 0.20), zorder=2, linewidth=0)
                ax.barh(i, pe - ps, left=ps, height=0.62, color="none", edgecolor=to_rgba(c, 0.75),
                        hatch=hatch, linewidth=0, zorder=2.1)
                ax.add_patch(Rectangle((ps, i - 0.31), pe - ps, 0.62, fill=False, edgecolor=c,
                                       linewidth=0.6 if day_mode else 0.9, zorder=2.2))
                if args.day_ticks and px_day >= 3:  # 日の区切りを予定バーの上下の縁に小さく
                    for dd in range(1, int(round(pe - ps))):
                        xx = ps + dd
                        if x0 < xx < x1:
                            tick_segs.extend([[(xx, i - 0.31), (xx, i - 0.17)], [(xx, i + 0.17), (xx, i + 0.31)]])
                            tick_cols.extend([c, c])
                if pd.notna(a["as_"]):
                    clean_actual(i, num(a["as_"]), num(a["a_eff"]) + 1, pe, 0.26, c, a["running"])
            else:
                pc = {0: "#1b2631", 1: "#2b3a4a"}.get(row["level"], "#5d6d7e")
                ax.barh(i - 0.1, pe - ps, left=ps, height=0.14, color=pc, zorder=3, linewidth=0)
                if pd.notna(a["as_"]):
                    clean_actual(i + 0.12, num(a["as_"]), num(a["a_eff"]) + 1, pe, 0.12, "#3d6fa8",
                                 a["running"])

        if clean_layout:
            plt.rcParams["hatch.linewidth"] = 0.6
        bar_dates = chart_layout and (getattr(args, "bar_dates", None) or "on") == "on"
        for i, row in enumerate(rows):
            a = row["agg"]
            ps, pe = num(a["ps"]), num(a["pe"]) + 1
            if chart_layout:
                chart_row(i, row)
            elif clean_layout:
                clean_row(i, row)
            elif row["leaf"]:
                c = ccol.get(row["r"]["category"], "#7f7f7f")
                ax.barh(i, pe - ps, left=ps, height=0.66, color=c, alpha=0.22, edgecolor=c, linewidth=1.0, zorder=2)
                if pd.notna(a["as_"]):
                    actual_bar(i, num(a["as_"]), num(a["a_eff"]) + 1, pe, i, 0.3, c, a["running"])
            else:
                pc = {0: "#1b2631", 1: "#2b3a4a"}.get(row["level"], "#5d6d7e")
                ax.barh(i - 0.13, pe - ps, left=ps, height=0.16, color=pc, zorder=3)
                for xx in (ps, pe):
                    if x0 <= xx <= x1:
                        ax.plot(xx, i - 0.05, marker="v", color=pc, markersize=4.5, zorder=3)
                if pd.notna(a["as_"]):
                    actual_bar(i, num(a["as_"]), num(a["a_eff"]) + 1, pe, i + 0.15, 0.16, "#3d6fa8",
                               a["running"])
            # 表示期間外への継続マーカー
            if split:
                continue  # 2 レーン方式はレーンごとに描画済み
            s_all = min(ps, num(a["as_"])) if pd.notna(a["as_"]) else ps
            e_all = max(pe, num(a["a_eff"]) + 1) if pd.notna(a["a_eff"]) else pe
            if s_all < x0:
                ax.plot(x0 + span * 0.004 + 0.15, i, marker="<", color="#444", markersize=6, zorder=6,
                        clip_on=False)
            if e_all > x1:
                ax.plot(x1 - span * 0.004 - 0.15, i, marker=">", color="#444", markersize=6, zorder=6,
                        clip_on=False)

        if split and getattr(args, "lane_labels", "on") != "off" and n:  # 先頭行だけ、ガントの左端の外に「予」「実」
            for yy, t_ in ((-LANE_OFF, "予"), (LANE_OFF, "実")):
                ax.annotate(t_, (0, yy), xycoords=("axes fraction", "data"), xytext=(-2, 0),
                            textcoords="offset points", ha="right", va="center", fontsize=5.5,
                            color="#555", annotation_clip=False)
        if tick_segs:
            ax.add_collection(LineCollection(tick_segs, colors=tick_cols, linewidths=0.6, zorder=2.3))
        if cap_segs:
            ax.add_collection(LineCollection(cap_segs, colors="#1a1a1a", linewidths=0.8, zorder=5.5))
        if flat and flat_caps:
            ax.add_collection(LineCollection(flat_caps, colors=flat_cap_cols, linewidths=0.4, zorder=4.5))

        # ---- 目盛り ----
        ax.set_xlim(x0, x1)
        ax.xaxis_date()
        if rng == "week":
            ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=mdates.MO))
            ax.xaxis.set_major_formatter(plt.FuncFormatter(
                lambda v, _: (lambda d: f"{d:%m/%d}({WEEKDAY_JA[d.weekday()]})")(mdates.num2date(v))))
            ax.xaxis.set_minor_locator(mdates.DayLocator())
            ax.grid(axis="x", which="major", color="#777", linewidth=1.0, alpha=0.8)
            ax.grid(axis="x", which="minor", color="#ccc", linewidth=0.5, alpha=0.8)
            d = wf
            while d <= wt:  # 土日 (休日カレンダー使用時は 休日) を薄く塗る
                if (is_off(d) if cal_on else d.weekday() >= 5):
                    ax.axvspan(num(d), num(d) + 1, color="#e9edf3", alpha=0.7, zorder=0.5, lw=0)
                d += pd.Timedelta(days=1)
        elif rng == "month":
            ax.xaxis.set_major_locator(mdates.MonthLocator())
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y/%m"))
            ax.xaxis.set_minor_locator(mdates.WeekdayLocator(byweekday=mdates.MO))
            ax.grid(axis="x", which="major", color="#777", linewidth=1.0, alpha=0.8)
            ax.grid(axis="x", which="minor", color="#bbb", linestyle=":", linewidth=0.6, alpha=0.8)
        else:
            ax.xaxis.set_major_locator(mdates.MonthLocator())
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y/%m"))
            if page and chart_w / (x1 - x0) * 30 < 0.6:  # 用紙モードで月の幅が狭い: 「2026/4」は年初と最初だけ、他は「5月」
                _d0 = mdates.num2date(x0)
                _first_m = (_d0.year, _d0.month) if _d0.day == 1 else ((_d0.year + _d0.month // 12), _d0.month % 12 + 1)
                def _mfmt(v, _):
                    d = mdates.num2date(v)
                    return f"{d.year}/{d.month}" if ((d.year, d.month) == _first_m or d.month == 1) else f"{d.month}月"
                ax.xaxis.set_major_formatter(plt.FuncFormatter(_mfmt))
            ax.grid(axis="x", which="major", color="#aaa", linewidth=0.7, alpha=0.8)
            for m in pd.date_range(wf.replace(day=1), wt, freq="MS"):
                if m.month in (1, 4, 7, 10) and not args.grid:  # 四半期の区切りを太く
                    ax.axvline(num(m), color="#555", linewidth=1.4, zorder=1)
        ax.set_axisbelow(True)
        tls = 7 if page else 8
        ax.tick_params(axis="x", which="both", top=True, bottom=True, labeltop=True, labelbottom=True,
                       labelsize=tls)
        ax.tick_params(axis="x", which="minor", length=2)
        today_in_header = False
        if args.grid:  # 階層つきの縦グリッド (日 < 週 < 月 < 四半期)
            g = args.grid
            if g == "auto":
                g = "day" if rng == "week" else "week"
            ax.grid(False, which="both", axis="x")
            GL = {
                "light": {"day": ("#e2e5e9", 0.45), "week": ("#b4bac3", 0.85),
                          "month": ("#959ca6", 1.0), "quarter": ("#5f6670", 1.5)},
                "normal": {"day": ("#c4c9d0", 0.7), "week": ("#8f96a0", 1.1),
                           "month": ("#6f7680", 1.3), "quarter": ("#4a515a", 1.7)},
                "strong": {"day": ("#a9afb8", 0.9), "week": ("#737a85", 1.35),
                           "month": ("#545b65", 1.5), "quarter": ("#343a42", 2.0)},
            }[args.grid_strength or "normal"]
            levels = {"day": 0, "week": 1, "month": 2, "none": 9}[g]
            d0 = pd.Timestamp(mdates.num2date(x0).date())
            d1 = pd.Timestamp(mdates.num2date(x1).date()) + pd.Timedelta(days=1)
            from matplotlib.collections import LineCollection as _LC
            segs = {k: [] for k in GL}
            if levels < 9:
                for d in pd.date_range(d0, d1, freq="D"):
                    xd = num(d)
                    if not (x0 < xd < x1):
                        continue
                    if d.day == 1 and d.month in (1, 4, 7, 10):
                        k = "quarter"
                    elif d.day == 1:
                        k = "month"
                    elif d.weekday() == 0:
                        k = "week"
                    else:
                        k = "day"
                    if {"day": 0, "week": 1, "month": 2, "quarter": 3}[k] >= levels:
                        segs[k].append([(xd, -0.5), (xd, n - 0.5)])
            if page and g == "week" and 7 * chart_w / (x1 - x0) * 25.4 < 4.0:  # 週の間隔が 4mm 未満なら細く淡く
                GL = dict(GL, week=("#d3d8de", 0.6 / 0.7))
            for k, (col, lw) in GL.items():
                if segs[k]:
                    ax.add_collection(_LC(segs[k], colors=col, linewidths=lw * (0.7 if page else 1), zorder=0.7))
            # 年ビュー＋週グリッド: 小さな週番号 (入るときだけ)
            wk_on = (args.week_numbers or "auto") != "off" and g == "week" and rng not in ("week", "month")  # 月ビューは「第N週」の見出し
            wkf = 6.5 if page else 5.5
            if wk_on and (_text_w_in("W53", wkf) + 0.03) < 7 * chart_w / (x1 - x0):
                ax.tick_params(axis="x", which="major", labeltop=False)
                sec = ax.secondary_xaxis("top")
                sec.xaxis.set_major_locator(ax.xaxis.get_major_locator())
                sec.xaxis.set_major_formatter(ax.xaxis.get_major_formatter())
                sec.tick_params(axis="x", labelsize=tls, pad=10, length=3)
                for d in pd.date_range(d0, d1, freq="W-MON"):
                    xd = num(d) + 3.5
                    if x0 < xd < x1:
                        ax.text(xd, 1.0, f"W{d.isocalendar().week}", transform=ax.get_xaxis_transform(),
                                ha="center", va="bottom", fontsize=wkf, color="#9aa0a8", clip_on=False)
            # 週ビュー＋日グリッド: 各日のマスの上に日付 (1〜31)
            dn_on = (args.day_numbers or "auto") != "off" and g == "day"
            dnf = 6.5 if page else 6
            if dn_on and (_text_w_in("31", dnf) + (0.005 if page else 0.02)) < chart_w / (x1 - x0):
                ax.tick_params(axis="x", which="major", labeltop=False)
                ax.tick_params(axis="x", which="minor", top=False)  # 日付の間に目盛り線が入って「,」に見えるのを防ぐ
                sec = ax.secondary_xaxis("top")
                sec.xaxis.set_major_locator(ax.xaxis.get_major_locator())
                sec.xaxis.set_major_formatter(ax.xaxis.get_major_formatter())
                sec.tick_params(axis="x", labelsize=tls, pad=10, length=3)
                for d in pd.date_range(d0, d1, freq="D"):
                    xd = num(d) + 0.5
                    if x0 < xd < x1:
                        colr = "#c0504d" if d.weekday() == 6 else ("#4f81bd" if d.weekday() == 5 else "#6b7280")
                        if cal_on:
                            if d.date() in WORK:
                                colr = "#6b7280"  # 出勤日
                            elif d.date() in HOL:
                                colr = "#c0504d" if HOL[d.date()][1] == "祝日" else "#b07070"  # 祝日=赤 / 会社休日=灰赤
                        if d == today:  # 今日は日付を赤で強調 (下の「今日」ラベルの代わり)
                            ax.text(xd, 1.0, f"{d.day}", transform=ax.get_xaxis_transform(), ha="center",
                                    va="bottom", fontsize=dnf, color="#1a1a1a" if BAND else "white",
                                    fontweight="bold", clip_on=False,
                                    bbox=dict(boxstyle="round,pad=0.15", fc=BAND or "red",
                                              ec="#5c940d" if BAND else "none", lw=0.6))
                            today_in_header = True
                        else:
                            ax.text(xd, 1.0, f"{d.day}", transform=ax.get_xaxis_transform(), ha="center",
                                    va="bottom", fontsize=dnf, color=colr, clip_on=False)
        if rng == "month":
            month_header(ax, ipd, tls)
        for sp in ("left", "right"):
            ax.spines[sp].set_visible(False)

        deps_on and draw_deps(rows, ax, ipd)
        band_label = None
        if BAND and x0 <= num(today) <= x1:  # 今日の列: 1日が 1.5mm 以上なら今日のマス、狭い (年ビュー) なら今日を含む週 (月〜日) を淡く
            if ipd * 25.4 >= 1.5:
                ax.axvspan(num(today), num(today) + 1, color=BAND, zorder=0.6, lw=0)
                band_label = "今日"
            else:
                wk0 = today - pd.Timedelta(days=today.weekday())
                ax.axvspan(num(wk0), num(wk0) + 7, color=_mix_white(BAND, 0.35), zorder=0.6, lw=0)
                band_label = "今日（週）"
        if x0 <= num(today) <= x1 and (args.today or windowed):
            t = num(today) + 0.5
            if inazuma:  # イナズマ線が今日の線を兼ねる (各行の間では今日の位置に戻る)
                from matplotlib import patheffects as _pe
                yo = LANE_OFF if split else 0.0  # 予定レーンの中心 (2 レーン方式は上のレーン)
                xs, ys_, vx, vy = [t], [-0.5], [], []
                for i, row in enumerate(rows):
                    pp = inazuma_point(row)
                    if pp is None:
                        continue
                    ppc = min(max(pp, x0), x1)
                    xs += [t, ppc, t]
                    ys_ += [i - 0.5, i - yo, i + 0.5]
                    vx.append(ppc)
                    vy.append(i - yo)
                xs.append(t)
                ys_.append(n - 0.5)
                halo = 3.2 if getattr(args, "inazuma_color", None) else 2.6  # 色指定時は太めの白縁 (赤い予定超過と交差しても分かる)
                ax.plot(xs, ys_, color="white", linewidth=halo, zorder=6.9, solid_joinstyle="round",
                        solid_capstyle="round")  # 白い縁取り (角が尖らないよう丸い角)
                ax.plot(xs, ys_, color=INAZUMA_C, linewidth=1.1, zorder=7, solid_joinstyle="round")
                ax.plot(vx, vy, "o", color=INAZUMA_C, markersize=2.6, markeredgecolor="white",
                        markeredgewidth=0.5, zorder=7.1)
            else:
                ax.axvline(t, color="red", linestyle="--", linewidth=1.3, zorder=4.5)
            if not today_in_header and page:  # 用紙モード: 今日ラベルは上の見出し (月ラベルの上) に置き、バーと重ねない
                ax.annotate(f"今日 {today:%m/%d}", (t, 1), xycoords=("data", "axes fraction"), xytext=(0, 28 if rng == "month" else 17),  # 月ビューは 2 行の見出しの上
                            textcoords="offset points", ha="center", va="bottom", fontsize=7.5,
                            color="#1a1a1a" if BAND else "red", fontweight="bold", annotation_clip=False,
                            bbox=dict(boxstyle="round,pad=0.15", fc=BAND or "white", ec="#5c940d" if BAND else "red",
                                      lw=0.7), zorder=7)
            elif not today_in_header:
                ax.annotate(f"今日 {today:%m/%d}", (t, 0), xycoords=("data", "axes fraction"), xytext=(0, 6),
                        textcoords="offset points", ha="center", va="bottom", fontsize=8.5, color="red",
                        fontweight="bold", bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="red", lw=0.8),
                        zorder=7)

        label = {"year": "全期間", "month": "月", "week": "週"}[rng]
        sub_t = f"表示: {label}  {wf:%Y/%m/%d} 〜 {wt:%Y/%m/%d}"
        if depth < 99:
            sub_t += f"  ／ 第{depth}階層まで表示（▶ は折りたたみ）"
        if legend_mode != "bottom" and cal_on:
            sub_t += ("  ／ 日数＝稼働日（土日・祝日・会社休日を除き出勤日を含む、進行中は今日まで・青）" if WD else
                      "  ／ 日数＝暦日（開始日・終了日を含む、進行中は今日まで・青）")
        elif legend_mode != "bottom":
            sub_t += "  ／ 日数は開始日・終了日を含む（進行中は今日まで・青）"
        if CAL_ANY:
            sub_t += "  ／ 「暦」＝稼働カレンダーが暦日のタスク（休日も数える）"
        if page:
            sub_t += f"  ／ 1日＝{mm_day:.2f}mm"
            fig.text(0.5, 1 - 0.13 / H, title, ha="center", va="center", fontsize=13)
            fig.text(0.5, 1 - 0.36 / H, sub_t, ha="center", va="center", fontsize=7.5, color="#555")
            import datetime as _dt
            fig.text(0.0, 0.0, f"出力日 {_dt.datetime.now():%Y/%m/%d %H:%M}", ha="left", va="bottom",
                     fontsize=6.5, color="#777")
            if foot:
                fig.text(1 - right_m / W, 0.0, foot, ha="right", va="bottom", fontsize=7, color="#555")
        elif title:
            fig.text(0.5, 1 - 0.3 / H, title, ha="center", va="center", fontsize=14)
            fig.text(0.5, 1 - 0.58 / H, sub_t, ha="center", va="center", fontsize=9, color="#555")
        else:
            fig.text(0.5, 1 - 0.18 / H, sub_t, ha="center", va="center", fontsize=9, color="#555")

        if legend_mode != "bottom":
            def hnd(group, lab):
                if group == "色＝カテゴリ":
                    return Patch(facecolor=ccol[lab], edgecolor=ccol[lab], label=lab)
                if group == "模様＝大項目":
                    return Patch(facecolor="white", edgecolor="#555", hatch=lv1_hatch[lab], label=lab)
                return {
                    "予定": Patch(facecolor=(0.5, 0.5, 0.5, 0.2), edgecolor="gray", label=lab),
                    "実績": Patch(facecolor="gray", label=lab),
                    "予定超過": Patch(facecolor=OVR, label=lab),
                    "進行中（今日まで）": arrow_h if flat else Patch(facecolor=(0.5, 0.5, 0.5, 0.55), edgecolor="#222",
                                          linestyle=(0, (3, 2)), label=lab),
                    "予定（親・子）": Line2D([], [], color="#2b3a4a", lw=2.5, label=lab),
                    "実績（親・子）": Line2D([], [], color="#3d6fa8", lw=2.5, label=lab),
                    "期間外へ続く": Line2D([], [], marker=">", color="#444", linestyle="", label=lab),
                    "今日": Line2D([], [], color="red", linestyle="--", label=lab),
                    "上＝予定／下＝実績": lane_h,
                }[lab]
            lane_h = Patch(label="上＝予定／下＝実績")
            arrow_h = Patch(label="進行中（今日まで）")
            lkw = dict(frameon=False, fontsize=LFS, handlelength=1.5, handleheight=0.8, handletextpad=0.4,
                       columnspacing=0.9, borderpad=0, borderaxespad=0)
            if split or flat:
                lkw["handler_map"] = {}
                if split:
                    lkw["handler_map"][lane_h] = _lane_handler("////" if patterns_on else None)
                if flat:
                    lkw["handler_map"][arrow_h] = _arrow_handler()
            if legend_mode == "header":  # 左上の空き (タスク列・表見出しの上) に小さく
                lab_w = max(_text_w_in(t + "：", LFS) for t, _ in leg_groups) + 0.08
                gname = None
                for k, (t, ch) in enumerate(hdr_rows):
                    if t:
                        gname = t
                    yc = 1 - (0.2 + 0.17 * k) / H
                    if t:
                        fig.text(left_m / W, yc, t + "：", ha="left", va="center", fontsize=LFS,
                                 fontweight="bold", color="#444")
                    fig.legend(handles=[hnd(gname, lab) for lab in ch], loc="center left",
                               bbox_to_anchor=((left_m + lab_w) / W, yc), ncol=len(ch), **lkw)
            elif legend_mode == "header-split":  # 色・模様・バーを別々の行に (見出し帯の中、ラベルを左に揃える)
                if task_sw == "on":
                    for i, row in enumerate(rows):
                        xi = tx(no_w + 0.08 + (row["level"] - min_level) * ind_step)
                        if row["leaf"]:
                            ax_t.add_patch(Rectangle((xi, i - 0.27), tx(0.15), 0.54,
                                                     facecolor=ccol[row["r"]["category"]], edgecolor="none", zorder=3))
                bar_hs = [lane_h if split else hnd("バー", "予定"), hnd("バー", "予定超過"),
                          hnd("バー", "進行中（今日まで）")]
                if not split:
                    bar_hs.insert(1, hnd("バー", "実績"))
                if windowed:
                    bar_hs.append(hnd("バー", "期間外へ続く"))
                if cal_on and rng == "week":
                    bar_hs.append(Patch(facecolor="#e3e8ef", edgecolor="#c4c9d0", linewidth=0.5,
                                        label="休日（バー内は淡く）" if GAPS else "休日"))
                if BAND and wf <= today <= wt:
                    _yr = ipd * 25.4 < 1.5
                    bar_hs.append(Patch(facecolor=_mix_white(BAND, 0.35) if _yr else BAND, edgecolor="#8fbf4a",
                                        linewidth=0.5, label="今日（週）" if _yr else "今日"))
                if inazuma:
                    bar_hs.append(Line2D([], [], color=INAZUMA_C, lw=1.1, marker="o", markersize=2.6,
                                         markeredgecolor="white", markeredgewidth=0.5,
                                         label="イナズマ線（左＝遅れ／右＝前倒し）"))
                elif wf <= today <= wt:
                    bar_hs.append(hnd("バー", "今日"))
                neutral = (0.55, 0.55, 0.55)
                groups = [
                    (COLOR_TITLE, [Patch(facecolor=ccol[c], edgecolor=ccol[c], label=c) for c in leg_cats], {}),
                    ("模様＝大項目", [Patch(facecolor="white", edgecolor="#555", hatch=lv1_hatch[g] or None,
                                         linewidth=0.6, label=g + ("（無地）" if not lv1_hatch[g] else ""))
                                   for g in leg_lv1], dict(handlelength=2.2, handleheight=1.0)),
                    ("バー", bar_hs, {}),
                ]
                if not patterns_on:
                    groups = [g for g in groups if g[0] != "模様＝大項目"]
                ys = HS_LINES if page else ((0.80, 0.96, 1.12) if patterns_on else (0.80, 0.96))
                gfs = LFS + 0.5
                lab_w = max(_text_w_in(t + "：", gfs) for t, _, _ in groups) + 0.06
                for (t, hs, extra), yy in zip(groups, ys):
                    if not hs:
                        continue
                    yc = 1 - yy / H
                    fig.text(left_m / W, yc, t + "：", ha="left", va="center", fontsize=gfs, fontweight="bold",
                             color="#333")
                    kw = dict(lkw, **extra)
                    fig.legend(handles=hs, loc="center left", bbox_to_anchor=((left_m + lab_w) / W, yc),
                               ncol=len(hs), **kw)
            elif legend_mode == "inline":  # 表の中に見本: タスク行=カテゴリ色、大項目行=模様
                for i, row in enumerate(rows):
                    xi = tx(no_w + 0.08 + (row["level"] - min_level) * ind_step)
                    wsw = tx(0.15)
                    if row["leaf"]:
                        ax_t.add_patch(Rectangle((xi, i - 0.27), wsw, 0.54, facecolor=ccol[row["r"]["category"]],
                                                 edgecolor="none", zorder=3))
                    elif row["level"] == 1 and row["node"][-1] in lv1_hatch and patterns_on:
                        ax_t.add_patch(Rectangle((xi, i - 0.27), wsw, 0.54, facecolor="white",
                                                 edgecolor="#555", hatch=lv1_hatch[row["node"][-1]], linewidth=0.6,
                                                 zorder=3))
                key = [hnd("色＝カテゴリ", c) for c in leg_cats] + [hnd("バー", b) for b in
                                                              (["上＝予定／下＝実績", "予定超過", "進行中（今日まで）"]
                                                               if split else
                                                               ["予定", "実績", "予定超過", "進行中（今日まで）"])]
                if page:  # 用紙モード: 副題の下に中央寄せ
                    fig.legend(handles=key, loc="upper center", bbox_to_anchor=(0.5, 1 - 0.5 / H),
                               ncol=len(key), **lkw)
                else:
                    fig.legend(handles=key, loc="upper right", bbox_to_anchor=(1 - right_m / W, 1 - 0.1 / H),
                               ncol=len(key), **lkw)
            return fig

        handles = [Patch(facecolor=ccol[c], label=c) for c in cats]
        if clean_layout:
            blank = Patch(facecolor="none", edgecolor="none", label="")
            _lane_patch = Patch(label="上＝予定／下＝実績")
            rows_leg = [
                ("色 ＝ カテゴリ", [Patch(facecolor=ccol[c], edgecolor=ccol[c], label=c) for c in cats]),
                ("模様 ＝ 大項目", [Patch(facecolor="white", edgecolor="#555", hatch=lv1_hatch[g], label=g)
                                  for g in lv1_list if any(r["leaf"] and r["r"]["_path"][0] == g for r in rows)]),
                ("バー", [_lane_patch, Patch(facecolor=OVR, label="予定超過"),
                          Patch(facecolor=(0.5, 0.5, 0.5, 0.55), edgecolor="#222", linestyle=(0, (3, 2)),
                                label="進行中（今日まで）")] if split else
                         [Patch(facecolor=(0.5, 0.5, 0.5, 0.2), edgecolor="gray", label="予定"),
                          Patch(facecolor="gray", label="実績"),
                          Patch(facecolor=OVR, label="予定超過"),
                          Patch(facecolor=(0.5, 0.5, 0.5, 0.55), edgecolor="#222", linestyle=(0, (3, 2)),
                                label="進行中（今日まで）"),
                          Line2D([], [], color="#2b3a4a", lw=3, label="予定（親・子）"),
                          Line2D([], [], color="#3d6fa8", lw=3, label="実績（親・子）")]
                         + ([Line2D([], [], marker=">", color="#444", linestyle="", label="期間外へ続く")]
                            if windowed else [])
                         + ([Line2D([], [], color="red", linestyle="--", label="今日")]
                            if x0 <= num(today) <= x1 else [])),
            ]
            if not patterns_on:
                rows_leg = [r_ for r_ in rows_leg if not r_[0].startswith("模様")]
            for k, (ttl, hs) in enumerate(rows_leg):
                yy = (bot_m - 0.45 - 0.36 * k) / H
                leg = fig.legend(handles=hs, loc="center left", bbox_to_anchor=(0.5, yy), ncol=max(1, len(hs)),
                                 frameon=False, fontsize=8.5, handlelength=2.2, handleheight=1.1,
                                 columnspacing=1.3, **({"handler_map": {_lane_patch: _lane_handler("////" if patterns_on else None)}} if split else {}))
                fig.canvas.draw()
                bb = leg.get_window_extent().transformed(fig.transFigure.inverted())
                leg.set_bbox_to_anchor((0.5 - bb.width / 2, yy), transform=fig.transFigure)
                fig.text(0.5 - bb.width / 2 - 0.08 / W, yy, ttl + "：", ha="right", va="center",
                         fontsize=8.5, fontweight="bold", color="#333")
                fig.add_artist(leg)
            handles = []
        elif chart_layout:
            handles += [
                Patch(facecolor=(0.5, 0.5, 0.5, 0.22), edgecolor="gray", label="予定"),
                Patch(facecolor=(0.5, 0.5, 0.5, 0.62), label="進捗（完了分）"),
                Line2D([], [], color="gray", lw=3, label="実績（下の細線）"),
                Patch(facecolor="#d62728", label="遅延"),
                Patch(facecolor="gray", edgecolor="white", hatch="////", label="進行中"),
            ]
            if has_ms[0]:
                handles.append(Line2D([], [], marker="D", color="gray", linestyle="", markeredgecolor="black",
                                      label="マイルストーン"))
            handles.append(Patch(facecolor=to_rgba_g("#2b3a4a", 0.16), edgecolor="#2b3a4a", label="親・子（集計）"))
        elif cats:
            handles += [Patch(facecolor=(0.5, 0.5, 0.5, 0.22), edgecolor="gray", label="予定"),
                        Patch(facecolor="gray", label="実績")]
        if not chart_layout and not clean_layout:
            handles += [
                Patch(facecolor="#d62728", label="遅延"),
                Patch(facecolor="gray", edgecolor="white", hatch="////", label="進行中"),
                Line2D([], [], color="#2b3a4a", lw=3, label="予定（集計）"),
                Line2D([], [], color="#3d6fa8", lw=3, label="実績（集計）"),
            ]
        if windowed and not clean_layout:
            handles.append(Line2D([], [], marker=">", color="#444", linestyle="", label="期間外へ続く"))
        if x0 <= num(today) <= x1 and not clean_layout:
            handles.append(Line2D([], [], color="red", linestyle="--", label="今日"))
        if clean_layout:
            fig.text(1 - right_m / W, 0.12 / H,
                     "日数は開始日・終了日を含む／進行中の日数は今日まで（青）／親・子の行は配下の集計"
                     + ("／「暦」= 稼働カレンダーが暦日のタスク（休日も数える）" if CAL_ANY else ""),
                     fontsize=7.5, color="#666", ha="right", va="bottom")
            return fig
        fig.legend(handles=handles, loc="center", bbox_to_anchor=(0.5, (bot_m - 0.58) / H), ncol=len(handles),
                   frameon=False, fontsize=8.5, handlelength=1.6, columnspacing=1.1)
        y = bot_m - 0.92
        for k, t in enumerate(notes_long, 1):
            fig.text(left_m / W, y / H, f"※{k}  {t}", fontsize=8.5, va="top", color="#333")
            y -= 0.21
        fig.text(1 - right_m / W, (bot_m - 0.92) / H,
                 ("バーの見方: 濃い部分=進捗、下の細線=実績、赤=予定超過、+N日=遅延（進行中は今日時点）、"
                  "−N日=前倒し、灰色の文字=担当・予定開始/終了日" if chart_layout else
                  "差(日): 実績終了−予定終了。* は進行中で今日時点の超過日数／親行は子孫の集計"
                  + ("／日数の「暦」= 稼働カレンダーが暦日のタスク（休日も数える）" if CAL_ANY else "")),
                 fontsize=7.5, color="#666", ha="right", va="top")
        return fig

    pages = _paginate(all_rows, args, cap=p_rows_fit if page else None)
    if pages is None:
        return render_page(all_rows, args.title)
    figs = []
    named = getattr(args, "split_by", None) in ("project", "owner")
    for k, pr in enumerate(pages, 1):
        ttl = args.title or ""
        if named and pr and pr[0]["node"]:
            gname = pr[0]["node"][0]
            ttl = f"{ttl} ― {gname}" if ttl else gname
        f = render_page(pr, f"{ttl}（{k}/{len(pages)}）", foot=f"{k} / {len(pages)} ページ")
        figs.append(f)
    figs and setattr(figs[0], "_bookmarks", _bookmarks_of(pages))
    if page:
        print(f"{len(pages)} ページ / 各ページの行数: {[len(pg) for pg in pages]}")
    return figs


PLOTTERS = {"gantt": plot_gantt, "bar": plot_bar, "stacked": plot_stacked, "combo": plot_combo,
            "gantt2": plot_gantt2}


def main(argv=None):
    p = argparse.ArgumentParser(
        description="CSV からグラフを作成 (gantt / bar / stacked / combo)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "CSV 形式:\n"
            "  gantt  : task,start,end[,group]  (日付 YYYY-MM-DD, 終了日を含む)\n"
            "  bar    : 1列目=カテゴリ, 2列目以降=系列 (グループ化縦棒)\n"
            "  stacked: 1列目=カテゴリ, 2列目以降=積み上げ系列\n"
            "  combo  : 1列目=カテゴリ, 棒の列..., --line で指定した列は右軸の折れ線\n"
            "  gantt2 : project,phase,task,category,owner,plan_start,plan_end,\n"
            "           actual_start,actual_end,progress,note  (予定/実績ガント)\n"
        ),
    )
    p.add_argument("type", nargs="?", choices=PLOTTERS, help="グラフの種類")
    p.add_argument("csv", help="入力 CSV ファイル (UTF-8)")
    p.add_argument("--type", dest="type_opt", choices=PLOTTERS, help="種類 (位置引数の代わり)")
    p.add_argument("-o", "--output", default=None, help="出力ファイル (.png/.svg/.pdf)。既定: <種類>.png")
    p.add_argument("--title")
    p.add_argument("--xlabel")
    p.add_argument("--ylabel")
    p.add_argument("--ylabel2", help="combo の右軸ラベル")
    p.add_argument("--line", action="append", help="combo: 右軸に折れ線で描く列 (複数可)")
    p.add_argument("--series", nargs="+", help="使う系列列を限定 (bar/stacked/combo の棒)")
    p.add_argument("--stack-bars", action="store_true", help="combo: 棒を積み上げにする")
    p.add_argument("--values", action="store_true", help="値ラベルを表示")
    p.add_argument("--total", action="store_true", help="stacked: 合計を上に表示")
    p.add_argument("--y2min", type=float)
    p.add_argument("--y2max", type=float)
    g = p.add_argument_group("gantt 用 (タスクが多いとき向け)")
    g.add_argument("--auto-height", action="store_true", help="行数に合わせて高さを自動調整 (1行≈0.35in)")
    g.add_argument("--sort", choices=["start"], help="start: グループ内を開始日順に並べ替え")
    g.add_argument("--group-headers", action="store_true", help="グループ見出し行と区切り線 (グループは開始日順)")
    g.add_argument("--stripes", action="store_true", help="行の背景を1行おきに色付け")
    g.add_argument("--today", metavar="YYYY-MM-DD", help="指定日に「今日」の縦破線")
    g.add_argument("--bar-labels", nargs="?", const="days", choices=["days", "name"],
                   help="バーに日数(days, 既定)かタスク名(name)を表示。入らなければ右側に表示")
    g.add_argument("--milestones", action="store_true", help="start==end の行を◆で描画")
    g.add_argument("--month-ticks", action="store_true", help="月ごとの目盛り(YYYY/MM)+週ごとの補助線")
    g.add_argument("--readable", action="store_true", help="上の見やすさオプションをまとめて有効化 (--today 以外)")
    p.add_argument("--columns", help="gantt2: 左表の列 (カンマ区切り。既定 " + GANTT2_DEFAULT_COLS
                   + "。使える列: " + ",".join(GANTT2_COLUMNS) + ")")
    t = p.add_argument_group("gantt2 階層・期間ビュー")
    t.add_argument("--range", choices=["year", "month", "week"], help="year=全期間 / month / week=今日前後の詳細")
    t.add_argument("--depth", type=int, help="表示する階層の深さ (例: 2 で孫を折りたたみ)")
    t.add_argument("--window", help="month/week の表示幅 (例 8w, 60d, 4m)。既定 week=8w, month=4m")
    t.add_argument("--from", dest="date_from", metavar="YYYY-MM-DD", help="表示開始日")
    t.add_argument("--to", dest="date_to", metavar="YYYY-MM-DD", help="表示終了日")
    t.add_argument("--notes", choices=["table", "right"], help="備考の位置 (階層ビューの既定 table)")
    t.add_argument("--note-chars", type=int, default=12, help="表内の備考の最大文字数 (超えると…と※脚注)")
    t.add_argument("--layout", choices=["table", "chart", "clean"], default=None,
                   help="table=左に表 (既定) / chart=ガント主体 (情報はバー周辺に) / clean=表は日付・日数・進捗だけ、バーに文字なし")
    t.add_argument("--bar-dates", choices=["on", "off"], help="chart レイアウトでバー両端に開始/終了日 (既定 on)")
    t.add_argument("--min-day-px", type=float, help="1日を最低 N ピクセルで描く (幅を自動拡大。例 6〜8)")
    t.add_argument("--max-width", type=float, default=40, help="--min-day-px で広げる図の幅の上限 (インチ, 既定 40)")
    t.add_argument("--day-ticks", action="store_true", help="予定バーの縁に日の区切りの小さな目盛り (1日≥3pxのとき)")
    t.add_argument("--grid", choices=["auto", "day", "week", "month", "none"],
                   help="縦グリッドの細かさ。auto=週ビューは毎日・年/月ビューは毎週 (月初・四半期はより濃く)")
    t.add_argument("--week-numbers", choices=["auto", "off"], help="--grid week のとき上端に小さな週番号 W41 (既定 auto)")
    t.add_argument("--inazuma", choices=["on", "off"],
                   help="イナズマ線 (未完了タスクの進捗点を今日の線から左右に折って結ぶ)。既定 off")
    t.add_argument("--deps", choices=["on", "off"], default="off",
                   help="影響タスク (depends 列の No.) を矢印で描く: 先行の予定終了 → 後のタスクの予定開始 (既定 off。循環参照はエラー)")
    t.add_argument("--inazuma-color", metavar="色", help="イナズマ線の色 (既定 #e8590c 濃いオレンジ)")
    t.add_argument("--today-band", metavar="色",
                   help="今日の列を塗る色 (例 #d8f5a2)。週ビューは今日のマス、年ビューは今日を含む週 (淡く)")
    t.add_argument("--overrun-color", metavar="色", help="予定超過の色 (clean レイアウト。既定 #d62728)")
    t.add_argument("--inazuma-parents", action="store_true", help="イナズマ線を親・子の行 (加重進捗) にも引く")
    t.add_argument("--actual-style", choices=["outline", "flat"],
                   help="clean レイアウトの実績バー: outline=今まで (既定) / flat=枠なし単色・進行中は先が矢印 (今日まで)")
    t.add_argument("--patterns", choices=["on", "off"],
                   help="clean レイアウトで大項目ごとの模様 (既定 on)。off=模様なし・色＝カテゴリだけ (凡例の模様の行も消える)")
    t.add_argument("--task-swatches", choices=["on", "off"],
                   help="タスク名の左の色見本 (inline は既定 on、header-split は既定 off)")
    t.add_argument("--legend", choices=["bottom", "header", "inline", "header-split", "off"],
                   help="clean レイアウトの凡例の位置。bottom=下 (既定) / header=左上の空き / inline=表の中に見本 / header-split=見出し帯に色・模様・バーを別行で / off")
    t.add_argument("--grid-strength", choices=["light", "normal", "strong"],
                   help="--grid の線の濃さ。normal (既定) / light=以前の淡い線 / strong")
    t.add_argument("--day-numbers", choices=["auto", "off"], help="週ビュー＋日グリッドで上端に日付 1〜31 (既定 auto)")
    t.add_argument("--bars", choices=["overlay", "split"],
                   help="clean レイアウトのバー: overlay=予定の上に細い実績 (既定) / split=上下 2 レーン (上＝予定・下＝実績)")
    t.add_argument("--lane-labels", choices=["on", "off"], default="on", help="--bars split で先頭行の左に「予」「実」")
    t.add_argument("--page", choices=list(PAGE_SIZES), help="用紙サイズ固定でページ分割 (余白 10mm)")
    t.add_argument("--pdf", action="store_true", help="--page のとき PNG に加えて複数ページ PDF も出力")
    t.add_argument("--no-column", dest="no_column", choices=["auto", "on", "off"], default="auto",
                   help="表の先頭に No. 列 (CSV に no があるとき)。auto = clean レイアウトで --columns がプリセット/省略のとき")
    t.add_argument("--bookmarks", choices=["on", "off"], default="off",
                   help="--page の PDF にしおり (プロジェクト＞大項目＞中項目 / 担当者) を付ける (既定 off)")
    t.add_argument("--min-row-mm", type=float, default=None, help="--page の最小行高さ mm (既定 4.5、--bars split は 5.5)")
    t.add_argument("--min-day-mm", type=float, default=3.0, help="--page の週ビューで 1日の最小幅 mm (既定 3.0)")
    t.add_argument("--rows-per-page", type=int, metavar="N", help="N 行ごとに別画像へ分割 (_p1, _p2 …)")
    t.add_argument("--split-by", choices=["level1", "project", "owner"],
                   help="一番上の階層ごとに改ページ (level1=大項目 / project=プロジェクト / owner=担当者)")
    t.add_argument("--view", choices=["all", "project", "owner"],
                   help="all=階層 (既定) / project=プロジェクトごと (改ページ) / owner=担当者ごと (色＝プロジェクト)")
    t.add_argument("--master", metavar="DIR", help="マスタのフォルダ (categories.csv, projects.csv, owners.csv, holidays.csv)")
    t.add_argument("--categories", metavar="CSV", help="カテゴリマスタ (code,name,color,order)")
    t.add_argument("--projects", metavar="CSV", help="プロジェクトマスタ (code,name,color,order)")
    t.add_argument("--owners", metavar="CSV", help="担当者マスタ (code,name,dept,color,order)")
    t.add_argument("--holidays", metavar="CSV", help="休日マスタ (date,name,type  type=祝日/会社休日/出勤日)")
    t.add_argument("--allow-unknown", action="store_true", help="マスタにないコードを警告だけにして続行")
    t.add_argument("--jp-holidays", choices=["on", "off"], help="日本の祝日を自動で休日にする (jpholiday)。既定 off")
    t.add_argument("--weekend", metavar="曜日", help="週末 (休日) の曜日。既定 sat,sun")
    t.add_argument("--workdays", choices=["on", "off"], help="on=日数を稼働日で数える / off=暦日")
    t.add_argument("--holiday-gaps", choices=["on", "off"], help="稼働日モードの週ビューでバーの中の休日を淡く (既定 on)")
    t.add_argument("--root", metavar="名前", help="全体を束ねるルート行 (プロジェクト名) を追加")
    p.add_argument("--width", type=float, help="図の幅 (インチ)")
    p.add_argument("--height", type=float, help="図の高さ (インチ)")
    p.add_argument("--dpi", type=int, default=None, help="解像度 (既定 150、--page のときは 200)")
    args = p.parse_args(argv)
    if args.dpi is None:
        args.dpi = 200 if getattr(args, "page", None) else 150

    kind = args.type_opt or args.type
    if not kind:
        p.error("グラフの種類を指定してください (例: chart.py bar data.csv)")
    setup_japanese_font()
    df = read_csv(args.csv)
    fig = PLOTTERS[kind](df, args)
    out = Path(args.output or f"{kind}.png")
    out.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(fig, list):  # ページ分割: 余白を固定して全ページの幅と位置をそろえる
        total = 0
        pg = getattr(fig[0], "_page", None)
        save_kw = {}
        if pg:  # 用紙モード: 図(印刷範囲)の外側に余白を付けて用紙ぴったりで保存
            from matplotlib.transforms import Bbox
            PW, PH, PM = pg
            save_kw = dict(bbox_inches=Bbox.from_bounds(-PM, -PM, PW, PH), facecolor="white")
        want_pdf = pg and (out.suffix.lower() == ".pdf" or args.pdf)
        if want_pdf:
            from matplotlib.backends.backend_pdf import PdfPages
            pdf_out = out.with_suffix(".pdf")
            with PdfPages(pdf_out) as pdf:
                for f in fig:
                    pdf.savefig(f, **save_kw)
            marks = getattr(fig[0], "_bookmarks", None)
            nb = _add_bookmarks(pdf_out, marks) if args.bookmarks == "on" and marks else 0
            print(f"保存しました: {pdf_out}  ({pdf_out.stat().st_size / 1024:.0f} KB, {len(fig)} ページ, ベクター"
                  + (f", しおり {nb} 件" if nb else "") + ")")
        png_out = out.with_suffix(".png") if out.suffix.lower() == ".pdf" else out
        for k, f in enumerate(fig, 1):
            o = png_out.with_name(f"{png_out.stem}_p{k}{png_out.suffix}")
            f.savefig(o, dpi=args.dpi, **save_kw)
            plt.close(f)
            sz = o.stat().st_size
            total += sz
            print(f"保存しました: {o}  ({sz / 1024:.0f} KB)")
        print(f"{len(fig)} ページ, 合計 {total / 1024:.0f} KB")
        return
    if not getattr(fig, "_no_tight", False):
        fig.tight_layout()
    fig.savefig(out, dpi=args.dpi, bbox_inches="tight")
    print(f"保存しました: {out}")


if __name__ == "__main__":
    main()
