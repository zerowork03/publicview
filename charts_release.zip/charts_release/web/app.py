"""ガントチャート入力 Web UI (ローカル用)

起動:  python app.py            → http://127.0.0.1:8050
       python app.py --host 0.0.0.0 --port 8050
データ: ../data/tasks/*.csv (タスク。ファイルごとにタブで開く) と ../master/*.csv (マスタ・列定義は全ファイル共通)。
  ../samples/tasks_master.csv は最初に data/tasks/ へ写し、以後 data/tasks/tasks_master.csv を保存するたびに同じ内容を書き戻す
  (chart.py の CLI で今まで通り使えるように)。
保存のたびに ../data/backup/YYYYMMDD-HHMMSS/ へ直前のファイルを退避する (タスクは tasks/<ファイル名>)。
"""
import argparse
import contextvars
import csv
import hashlib
import datetime as dt
import io
import json
import re
import shutil
import subprocess
import sys
import logging
import uuid
from collections import Counter
from decimal import Decimal, ROUND_HALF_UP
import unicodedata
import zipfile
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_file, send_from_directory

WEB = Path(__file__).resolve().parent
BASE = WEB.parent
CHART = BASE / "chart.py"
MASTER = BASE / "master"
TASK_DIR = BASE / "data" / "tasks"  # タスクのファイル置き場 (1 ファイル = 1 タブ)
LEGACY = BASE / "samples" / "tasks_master.csv"  # 以前の場所。data/tasks/ が空のときだけ一度写す (書き戻しはしない)
DEFAULT_TASK = "tasks_master.csv"
TASK_NAME_RE = re.compile(r'^[^\\/:*?"<>|\x00-\x1f]{1,80}\.csv$')
CUR_FILE = contextvars.ContextVar("cur_file", default=None)  # このリクエストで扱うタスクのファイル (?file=)
BACKUP = BASE / "data" / "backup"
OUTPUT = WEB / "output"
SETTINGS = WEB / "settings.json"
PRESETS = WEB / "presets.json"
COLUMNS = MASTER / "columns.csv"
log = logging.getLogger("gantt-web")
REPAIR_NOTES = []  # 列定義を自動修復したときのお知らせ

# ---- タスクのコア列 (システムの正。列定義ファイルからは消せない・キー/型/必須は変えられない) ----
CORE_COLUMNS = [
    {"key": "no", "label": "No.", "type": "int", "width": "50"},  # 並びの指定 (行そのものの順番は変えない)
    {"key": "project", "label": "プロジェクト", "type": "code:projects", "width": "150"},
    {"key": "level1", "label": "大項目", "type": "text", "width": "100"},
    {"key": "level2", "label": "中項目", "type": "text", "width": "100"},
    {"key": "level3", "label": "タスク", "type": "text", "width": "190"},
    {"key": "category", "label": "カテゴリ", "type": "code:categories", "width": "100"},
    {"key": "owner", "label": "担当", "type": "code:owners", "width": "110"},
    {"key": "plan_start", "label": "予定開始", "type": "date", "width": ""},
    {"key": "plan_end", "label": "予定終了", "type": "date", "width": ""},
    {"key": "actual_start", "label": "実績開始", "type": "date", "width": ""},
    {"key": "actual_end", "label": "実績終了", "type": "date", "width": ""},
    {"key": "progress", "label": "進捗%", "type": "percent", "width": "58"},
    {"key": "note", "label": "備考", "type": "text", "width": "170"},
    {"key": "priority", "label": "優先順位", "type": "code:priorities", "width": "90"},
    {"key": "importance", "label": "重要度", "type": "code:importance", "width": "80"},
    {"key": "depends", "label": "影響タスク", "type": "text", "width": "90"},  # 先行タスクの No. (カンマ・空白区切り、同じファイル内)
    {"key": "calendar", "label": "稼働カレンダー", "type": "select:休日除外/暦日", "width": "90"},  # 空欄 = 休日除外
    {"key": "actual_effort", "label": "実績工数", "type": "number", "width": "80"},  # 手入力。0 以上・小数 2 桁 (四捨五入)
    {"key": "unit_price", "label": "単価", "type": "number", "width": "90"},  # 手入力。0 以上・小数 2 桁 (四捨五入)
]
NEW_CORE = {"no", "priority", "importance", "depends", "calendar", "actual_effort", "unit_price"}
AUTO_ADD = {"priority", "importance", "depends", "calendar", "actual_effort", "unit_price"}
EFFORT_KEYS = ("actual_effort", "unit_price")  # 小数 2 桁で保存する列
# 計算列 (システムの列): タスク CSV には書かない。列定義には載り、表示名・幅・並び・表示・バー表示だけ変えられる
CALC_COLUMNS = [
    {"key": "plan_effort", "label": "予定工数（参考）", "type": "calc", "width": "90"},  # 予定日数 × 工数の基準値
    {"key": "plan_amount", "label": "予定金額（参考）", "type": "calc", "width": "110"},  # 予定工数 × 単価
    {"key": "actual_amount", "label": "実績金額", "type": "calc", "width": "110"},  # 実績工数 × 単価
]
CALC_KEYS = [c["key"] for c in CALC_COLUMNS]
# パラメータ (master/params.csv: key,value,label。全ファイル共通。chart.py も --master で読む)
PARAM_DEFS = [
    {"key": "hours_per_day", "label": "工数の基準値（時間/日）", "default": "8.00"},
    {"key": "currency", "label": "通貨の表示", "default": "円"},
    {"key": "output_keep_days", "label": "出力ファイルを残す日数（web/output）", "default": "30"},
    {"key": "backup_keep", "label": "バックアップを残す数（data/backup の世代）", "default": "100"},
]
GENERIC_CORE = ("priority", "importance", "calendar")  # コア列だが値は任意・検証は追加列と同じ (型どおり)
DEP_ITEM = re.compile(r"^([1-9]\d{0,8})$")  # 影響タスクの 1 項目 = No. (整数)  # 値は任意のコア列: 取り込んだ CSV に無ければ空欄で補う (No. は値が必須なので補わず拒否)  # 後から足したコア列: 既存のタスク CSV には一度だけ自動で追加する (バックアップ付き)
MIGRATE_NOTES = []  # 自動で行った移行・作成のお知らせ (画面に出す)
# マスタ: 組み込み 3 つ ＋ 列定義の型 code:<名前> で参照されるもの (master/<名前>.csv、列は code,name,color,order)
BUILTIN_MASTERS = ("categories", "projects", "owners")
MASTER_FIELDS = ["code", "name", "color", "order"]
MASTER_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,30}$")
RESERVED_KINDS = {"tasks", "holidays", "columns", "settings", "presets", "backup", "params"}
SAMPLE_MASTERS = {
    "priorities": [("P1", "最優先", "#c92a2a"), ("P2", "高", "#e8590c"), ("P3", "中", "#f08c00"), ("P4", "低", "#868e96")],
    "importance": [("A", "高", "#5f3dc4"), ("B", "中", "#1971c2"), ("C", "低", "#868e96")],
}
MASTER_LABELS = {"categories": "カテゴリ", "projects": "プロジェクト", "owners": "担当者", "priorities": "優先順位", "importance": "重要度"}
CORE_KEYS = [c["key"] for c in CORE_COLUMNS]
COL_FIELDS = ["key", "label", "type", "required", "width", "visible", "order", "default", "validation",
              "bar_pos", "bar_order", "bar_max", "bar_title", "bar_short"]
CORE_EDITABLE = ("label", "width", "order", "visible", "bar_pos", "bar_order", "bar_max", "bar_title", "bar_short")  # コア列で変えてよい項目
BAR_POS = ("none", "inside", "right", "left", "below", "above")  # ガントのバーの周りに出す位置
BAR_DEFAULT = {"owner": ("right", "1"), "note": ("below", "1")}
BAR_SHORT = {"priority": "優先", "importance": "重要", "depends": "影響", "calendar": "暦"}  # バーの見出しの短縮名 (既定)
SHORT_RE = re.compile(r"^[^,\"\r\n]{0,10}$")
DEP_SPLIT = re.compile(r"[\s,、，]+")
TYPE_RE = re.compile(r"^(text|date|int|percent|number|bool|code:[a-z][a-z0-9_]{0,30}|select:[^/]+(/[^/]+)*)$")
KEY_RE = re.compile(r"^[^,\"\r\n]{1,40}$")
BOOL_VALUES = {"1", "0", "-1", "true", "false", "yes", "no", "はい", "いいえ"}  # -1 = Access の Yes (True)

BASE_SCHEMAS = {
    "tasks": ["project", "level1", "level2", "level3", "category", "owner", "plan_start", "plan_end",
              "actual_start", "actual_end", "progress", "note"],
    "categories": ["code", "name", "color", "order"],
    "projects": ["code", "name", "color", "order"],
    "owners": ["code", "name", "dept", "color", "order"],
    "holidays": ["date", "name", "type"],
    "columns": COL_FIELDS,
    "params": ["key", "value", "label"],
}


# ---- 工数・単価・金額: 小数 2 桁、端数は四捨五入 (ROUND_HALF_UP)。CSV には 1234.50 の形で書く ----
D2 = Decimal("0.01")
DEC_RE = re.compile(r"^\d{1,12}(\.\d+)?$")


def dec(v):
    """'1,234.5' や全角数字 → Decimal (2 桁に四捨五入)。空欄・数値でない・負 → None"""
    t = re.sub(r"^[¥$\\]", "", unicodedata.normalize("NFKC", str(v or "")).replace(",", "").strip())  # Access の通貨型は ¥5,000 で出ることがある
    return Decimal(t).quantize(D2, ROUND_HALF_UP) if DEC_RE.match(t) else None


def dec_str(v):
    """保存用: 数値なら 2 桁 (0.10・8.00)、空欄は空欄、読めない値はそのまま (検証でエラーにする)"""
    d = dec(v)
    return f"{d:.2f}" if d is not None else str(v or "").strip()


def money(d):
    return "" if d is None else f"{d:,.2f}"


def load_params():
    """{key: value}。ファイルが無い・値が不正なら既定値"""
    rows = {r["key"]: r.get("value", "") for r in (read_csv_file(MASTER / "params.csv")[1] if (MASTER / "params.csv").exists() else [])}
    vals = {p["key"]: rows.get(p["key"]) or p["default"] for p in PARAM_DEFS}
    h = dec(vals["hours_per_day"])
    return vals | {"hours_per_day": f"{h:.2f}" if h and h > 0 else "8.00"}


def param_errors(vals):
    h = dec(vals.get("hours_per_day"))
    return ([_err(-1, "hours_per_day", "工数の基準値は 0 より大きい数値（小数 2 桁）")] if not h or h <= 0 else []) + \
        ([_err(-1, "currency", "通貨の表示は 1〜10 文字")] if not 1 <= len(vals.get("currency", "")) <= 10 else []) + \
        [_err(-1, k, f"{k} は 1〜{hi} の整数") for k, hi in (("output_keep_days", 3650), ("backup_keep", 10000))
         if not (str(vals.get(k, "")).isdigit() and 1 <= int(vals[k]) <= hi)]


def work_calendar():
    """稼働日の判定 (画面と同じ: 週末 ＋ 祝日 (jp_holidays on) ＋ holidays.csv。出勤日は稼働日)"""
    s = load_settings()
    wk = {["mon", "tue", "wed", "thu", "fri", "sat", "sun"].index(w) for w in (s["weekend"] or "sat,sun").split(",")
          if w in ("mon", "tue", "wed", "thu", "fri", "sat", "sun")}
    hol_rows = read_rows("holidays")
    work = {h["date"] for h in hol_rows if h["type"] == "出勤日"}
    hol = {h["date"] for h in hol_rows if h["type"] != "出勤日"}
    jp = {}

    def is_off(d):
        if s["jp_holidays"] == "on" and d.year not in jp:
            jp[d.year] = {h["date"] for h in (jp_holidays(d.year) or [])}
        iso = d.isoformat()
        return iso not in work and (iso in hol or d.weekday() in wk or iso in jp.get(d.year, ()))
    return is_off


def plan_days(r, is_off):
    """予定日数: 稼働カレンダーが暦日なら暦の日数、それ以外は稼働日数。日付が不正なら None"""
    a, b = pdate(r.get("plan_start", "")), pdate(r.get("plan_end", ""))
    if not a or not b or b < a:
        return None
    days = [a + dt.timedelta(n) for n in range((b - a).days + 1)]
    return len(days) if (r.get("calendar") or "").strip() == "暦日" else sum(1 for d in days if not is_off(d))


def calc_values(r, hours, is_off):
    """計算列 (Decimal か None)。予定工数 = 予定日数 × 基準値、予定金額 = 予定工数 × 単価、実績金額 = 実績工数 × 単価"""
    n, price, act = plan_days(r, is_off), dec(r.get("unit_price")), dec(r.get("actual_effort"))
    pe = (Decimal(n) * hours).quantize(D2, ROUND_HALF_UP) if n is not None else None
    mul = lambda x: (x * price).quantize(D2, ROUND_HALF_UP) if x is not None and price is not None else None  # noqa: E731
    return {"plan_effort": pe, "plan_amount": mul(pe), "actual_amount": mul(act)}


def master_uses():
    """{マスタ名: [そのマスタを使うタスクの列]} 組み込み → 列定義の順"""
    uses = {k: [] for k in BUILTIN_MASTERS}
    for c in load_schema()[0]:
        if c["type"].startswith("code:"):
            uses.setdefault(c["type"][5:], []).append(c["key"])
    return uses


def master_kinds():
    return [k for k in master_uses() if k not in RESERVED_KINDS]


def all_kinds():
    return ["tasks", *master_kinds(), "holidays", "columns"]


def fields_of(kind):
    if kind in BASE_SCHEMAS:
        return BASE_SCHEMAS[kind]
    if kind in master_kinds():
        return MASTER_FIELDS
    abort(404)
HOL_TYPES = ("祝日", "会社休日", "出勤日")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
CODE_RE = re.compile(r"^[A-Za-z0-9_\-]{1,20}$")
JOB_RE = re.compile(r"^[0-9]{8}-[0-9]{6}-[0-9a-f]{6}$")
FILE_RE = re.compile(r"^[A-Za-z0-9_\-]+\.(png|pdf|zip)$")
DEFAULT_SETTINGS = {
    "view": "all", "range": "week", "today": "", "date_from": "", "date_to": "", "workdays": "on",
    "jp_holidays": "on", "inazuma": "on", "page": "a4-landscape", "split_by": "", "format": "pdf",
    "title": "", "weekend": "sat,sun", "deps": "off", "effort_cols": "off",  # effort_cols: PDF/PNG の表に工数・金額の列を足す  # deps: PDF/PNG に影響線 (矢印) を描く
    "gantt_collapsed": "",  # ガントのツリーで折りたたんだ親 (プロジェクトのコード\t大項目\t中項目)。改行区切り (共通条件)
    "gantt_deps": "on",  # ガント編集・比較の「影響線を表示」(共通条件)
    "gantt_span": "auto", "gantt_span_from": "", "gantt_span_to": "",  # 表示期間 (共通条件): auto / fixed (from〜to) / all
    "grid_col_order": "", "grid_frozen": "0", "grid_hidden": "",  # タスク表の見た目だけ (列の並び・左から固定する列数)。CSV の列順には使わない
    "open_files": "", "cur_file": "", "out_file": "", "cmp_a": "", "cmp_b": "",  # 開いているファイルのタブ・比較 (全ファイル共通の条件)
}

app = Flask(__name__, static_folder=str(WEB / "static"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024


# ---------------- タスクのファイル ----------------
def task_files():
    return sorted((p for p in TASK_DIR.glob("*.csv") if p.is_file()), key=lambda p: (p.name != DEFAULT_TASK, p.name))


def safe_name(name):
    name = str(name or "").strip()
    return name if TASK_NAME_RE.match(name) and not name.startswith(".") and Path(name).name == name else None


def task_file(name):
    """名前 → data/tasks/ の既存ファイル。不正な名前・無いファイルは 404"""
    p = TASK_DIR / name if safe_name(name) else None
    if not p or not p.is_file():
        abort(404, f"タスクのファイルがありません: {name}")
    return p


def task_path():
    """いま扱うタスクのファイル (リクエストの ?file=、無ければ既定のファイル)"""
    files = task_files()
    return CUR_FILE.get() or next((p for p in files if p.name == DEFAULT_TASK), files[0] if files else TASK_DIR / DEFAULT_TASK)


@app.before_request
def pick_file():
    CUR_FILE.set(task_file(request.args["file"]) if "file" in request.args else None)


def path_of(kind):
    if kind == "tasks":
        return task_path()
    if kind == "columns":
        return COLUMNS
    if kind in BASE_SCHEMAS or (MASTER_NAME_RE.match(kind) and kind in master_kinds()):
        return MASTER / f"{kind}.csv"
    abort(404)


def read_csv_file(p):
    """(見出し, 行) を返す。値は前後の空白を除く"""
    if not p.exists():
        return [], []
    rd = csv.DictReader(io.StringIO(read_text_any(p), newline=""))
    rows = [{k: (v or "").strip() for k, v in r.items() if k is not None} for r in rd]
    return [h.strip().strip('"') for h in (rd.fieldnames or [])], rows


def read_text_any(p):
    """UTF-8 (BOM の有無どちらも) → Shift_JIS (Access の既定) の順に読む"""
    raw = p.read_bytes()
    text = next((t for t in (_decode(raw, enc) for enc in ("utf-8-sig", "cp932")) if t is not None), None)
    if text is None:
        raise ValueError(f"{p.name}: 文字コードを読めません（UTF-8 か Shift_JIS で保存してください）")
    return text


def file_version(p):
    """ファイルの版 (内容のハッシュ)。読み込んだ後に Access から書き出し直されたかを保存のときに確かめる"""
    return hashlib.sha1(p.read_bytes()).hexdigest()[:16] if p.exists() else ""


def task_header():
    return read_csv_file(task_path())[0]


def read_rows(kind):
    if kind == "columns":
        return load_schema()[0]
    head, rows = read_csv_file(path_of(kind))
    keys = task_fields(rows, head) if kind == "tasks" else fields_of(kind)  # タスクは追加の列もそのまま持つ
    norm = access_norm(kind)
    return [{k: norm.get(k, str)(r.get(k, "")) for k in keys} for r in rows]


def _intish(v):
    return str(int(float(v.replace(",", "")))) if v and INTISH_RE.match(v) else v


def access_norm(kind):
    """Access から書き出した CSV のくせを読むときにそろえる: 日付 (2026/10/15 0:00:00)・整数 (1,234 / 30.00)・金額 (1,234.5)"""
    dates = {k: norm_date for k in DATE_COLS}
    if kind == "tasks":
        dates |= {c["key"]: norm_date for c in load_schema()[0] if c["type"] == "date"}  # 追加の日付列も
        return dates | {k: _intish for k in ("no", "progress")} | {k: dec_str for k in EFFORT_KEYS}
    return dates | ({"order": _intish} if kind in master_kinds() else {})


def write_rows(kind, rows, stamp, fields=None):
    p = path_of(kind)
    if p.exists() and stamp:  # バックアップ (タスクは tasks/<ファイル名>)
        bdir = BACKUP / stamp / ("tasks" if kind == "tasks" else "")
        bdir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, bdir / p.name)
    p.parent.mkdir(parents=True, exist_ok=True)
    fields = fields or (task_fields(rows) if kind == "tasks" else fields_of(kind))
    tmp = p.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8-sig", newline="") as f:  # Excel 向けに BOM 付き
        w = csv.DictWriter(f, fieldnames=fields, lineterminator="\r\n")
        w.writeheader()
        w.writerows({k: r.get(k, "") for k in fields} for r in rows)
    tmp.replace(p)  # タスクの正は data/tasks/ だけ (以前の samples/ への書き戻しはやめた)


# ---------------- 列定義 (master/columns.csv) ----------------
def core_def(c, order):
    return {"key": c["key"], "label": c["label"], "type": c["type"], "required": "no" if c["key"] in CALC_KEYS else "yes", "width": c["width"],
            "visible": "yes", "order": str(order), "default": "0" if c["key"] == "progress" else "", "validation": "",
            "bar_pos": BAR_DEFAULT.get(c["key"], ("none",))[0], "bar_order": BAR_DEFAULT.get(c["key"], ("", ""))[1], "bar_max": "",
            "bar_title": "yes", "bar_short": BAR_SHORT.get(c["key"], "")}


def parse_validation(v):
    """min=0;max=100;regex=^... (regex は最後に書く。; を含んでよい) → dict。書式が違えば ValueError"""
    out, rest = {}, (v or "").strip()
    while rest:
        if rest.startswith("regex="):
            re.compile(rest[6:])
            return out | {"regex": rest[6:]}
        tok, _, rest = rest.partition(";")
        k, eq, val = tok.strip().partition("=")
        if k not in ("min", "max") or not eq or not _is_num(val.strip()):
            raise ValueError(f"検証の書式が違います: {tok}（例 min=0;max=100;regex=^A）")
        out[k] = float(val)
        rest = rest.strip()
    return out


def _editable(r, base):
    """コア列: 変えてよい項目 (表示名・幅・並び・表示) だけ取り込む"""
    ok = {"label": bool(r.get("label")), "width": (r.get("width") or "").isdigit() or r.get("width") == "",
          "order": _is_num(r.get("order") or "x"), "visible": r.get("visible") in ("yes", "no"), **_bar_ok(r)}
    return base | {k: r[k] for k in CORE_EDITABLE if ok[k] and k in r}


def _bar_ok(r):
    return {"bar_pos": r.get("bar_pos") in BAR_POS, "bar_order": r.get("bar_order") == "" or _is_num(r.get("bar_order") or "x"),
            "bar_max": r.get("bar_max") == "" or (r.get("bar_max") or "").isdigit(),
            "bar_title": (r.get("bar_title") or "yes") in ("yes", "no"), "bar_short": r.get("bar_short") is not None and bool(SHORT_RE.match(r["bar_short"]))}


def _restore_core(i, c, r, notes):
    base = core_def(c, i + 1)
    if r is None:
        notes.append(f"{'計算列' if c['key'] in CALC_KEYS else 'コア列'}「{c['key']}」を列定義に追加しました（今回の更新）" if c["key"] in NEW_CORE | set(CALC_KEYS)
                     else f"コア列「{c['key']}」が列定義にないため復元しました")
        return base
    bad = [f for f, want in (("type", c["type"]), ("required", base["required"])) if r.get(f) != want]
    bad and notes.append(f"{'計算列' if c['key'] in CALC_KEYS else 'コア列'}「{c['key']}」の {'/'.join(bad)} が変更されていたため元に戻しました")
    return _editable(r, base)


def _norm_extra(r, notes):
    t = r.get("type") or "text"
    if not TYPE_RE.match(t):
        notes.append(f"列「{r['key']}」の型 {t} が不正なため text にしました")
        t = "text"
    try:
        parse_validation(r.get("validation"))
        val = r.get("validation") or ""
    except (ValueError, re.error):
        notes.append(f"列「{r['key']}」の検証 {r.get('validation')} が読めないため外しました")
        val = ""
    yn = lambda v, d: v if v in ("yes", "no") else d  # noqa: E731
    return {"key": r["key"], "label": r.get("label") or r["key"], "type": t, "required": yn(r.get("required"), "no"),
            "width": r.get("width") if (r.get("width") or "").isdigit() else "", "visible": yn(r.get("visible"), "yes"),
            "order": r.get("order") if _is_num(r.get("order") or "x") else "999", "default": r.get("default") or "",
            "validation": val, **{k: r.get(k, "") if ok else "" for k, ok in _bar_ok(r).items()},
            "bar_pos": r.get("bar_pos") if r.get("bar_pos") in BAR_POS else "none", "bar_title": yn(r.get("bar_title"), "yes")}


def load_schema():
    """列定義を読む。コア列が欠けたり変えられていたら復元してファイルも直す (警告を記録)。(列定義, お知らせ) を返す"""
    if not COLUMNS.exists():  # 初回: コア列だけの列定義を作る
        write_rows("columns", [core_def(c, i + 1) for i, c in enumerate(CORE_COLUMNS + CALC_COLUMNS)], "", COL_FIELDS)
    _, rows = read_csv_file(COLUMNS)
    notes = []
    first = {}
    rows = [r for r in rows if r.get("key") and first.setdefault(r["key"], r) is r]
    by_key = {r["key"]: r for r in rows}
    core = [_restore_core(i, c, by_key.get(c["key"]), notes) for i, c in enumerate(CORE_COLUMNS + CALC_COLUMNS)]
    extra = [_norm_extra(r, notes) for r in rows if r["key"] not in CORE_KEYS + CALC_KEYS and KEY_RE.match(r["key"])]
    cols = sorted(core + extra, key=lambda c: float(c["order"]))
    if notes:
        log.warning("列定義を修復しました: %s", " / ".join(notes))
        write_rows("columns", cols, dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-schema", COL_FIELDS)
        REPAIR_NOTES.extend(n for n in notes if n not in REPAIR_NOTES and "今回の更新" not in n)  # 画面に出すため保存されるまで覚えておく
        MIGRATE_NOTES.extend(n for n in notes if n not in MIGRATE_NOTES and "今回の更新" in n)
    return cols, notes


def task_fields(rows, head=None):
    """CSV の列順は常にファイルにある見出しの順。足りない列だけ後ろへ (コア列 → 列定義の追加列 → 行にある列)。
    画面の列の並び替えは見た目だけで、ここには影響しない。_rid (行の識別子) は CSV に書かない"""
    head = task_header() if head is None else head
    schema = [c["key"] for c in load_schema()[0] if c["key"] not in CORE_KEYS and c["type"] != "calc"]
    seen = dict.fromkeys([*head, *CORE_KEYS, *schema, *(k for r in rows for k in r)])
    return [k for k in seen if isinstance(k, str) and KEY_RE.match(k) and k != RID and k not in CALC_KEYS]  # 計算列は CSV に書かない


# ---- タスク行の識別子: 読み込んだときの行番号 + コア列の内容のハッシュ。画面ではセルの値の編集だけを許す ----
RID = "_rid"


def row_id(i, r):
    digest = hashlib.sha1("\x1f".join(r.get(k, "") for k in CORE_KEYS).encode("utf-8")).hexdigest()[:12]
    return f"{i}-{digest}"


def with_ids(rows):
    return [r | {RID: row_id(i, r)} for i, r in enumerate(rows)]


def row_set_error(sent):
    """送られた行がいまのファイルの行と 1 対 1・同じ順番か (追加・複写・削除・並べ替えは不可)"""
    want = [row_id(i, r) for i, r in enumerate(read_rows("tasks"))]
    got = [r.get(RID) if isinstance(r, dict) else None for r in sent]
    if got == want:
        return None
    added, removed = [g for g in got if g not in want], [w for w in want if w not in got]
    dup = len(set(got)) != len(got)
    reason = ("行の追加・複写" if added or dup else "") + ("・" if (added or dup) and removed else "") + ("行の削除" if removed else "")
    return (f"タスクの行は変更できません（{reason or '行の並べ替え'}）。現在 {len(want)} 行、送信 {len(got)} 行。"
            "セルの値の編集だけができます。行の追加・削除は Access（または CSV）で行い、書き出し直してください"
            + ("（ファイルが外で変更された場合は画面を再読み込みしてください）" if added and not dup and len(got) == len(want) else ""))


def missing_headers(head):
    return [c["key"] for c in load_schema()[0] if c["required"] == "yes" and c["key"] not in head]


def load_settings():
    s = dict(DEFAULT_SETTINGS)
    if SETTINGS.exists():
        try:
            s.update({k: v for k, v in json.loads(SETTINGS.read_text(encoding="utf-8")).items() if k in s})
        except (ValueError, OSError):
            pass
    return s


def jp_holidays(year):
    try:
        import jpholiday
    except ImportError:
        return None
    return [{"date": d.isoformat(), "name": n, "type": "祝日"}
            for d, n in jpholiday.between(dt.date(year, 1, 1), dt.date(year, 12, 31))]


def pdate(s):
    try:
        return dt.date.fromisoformat(s) if s and DATE_RE.match(s) else None
    except ValueError:
        return None


DATE_COLS = {"plan_start", "plan_end", "actual_start", "actual_end", "date"}
YMD_RE = re.compile(r"^(\d{4})[/.-](\d{1,2})[/.-](\d{1,2})(?:[ T]\d{1,2}:\d{2}(?::\d{2})?)?$")  # Access: 2026/10/15 0:00:00
INTISH_RE = re.compile(r"^-?[\d,]+(\.0+)?$")  # Access: 1,234 / 30.00 → 整数


def norm_date(v):
    """2026/10/5・2026-10-05 → 2026-10-05 (読めなければそのまま返し、検証でエラーにする)"""
    m = YMD_RE.match(v)
    return f"{m[1]}-{int(m[2]):02d}-{int(m[3]):02d}" if m else v


def clean_rows(kind, rows):
    if not isinstance(rows, list) or not all(isinstance(r, dict) for r in rows):
        abort(400, "rows の形式が不正です")
    val = lambda r, k: str(r.get(k) if r.get(k) is not None else "").strip()  # noqa: E731
    keys = task_fields(rows) if kind == "tasks" else fields_of(kind)
    dates = DATE_COLS | ({c["key"] for c in load_schema()[0] if c["type"] == "date"} if kind == "tasks" else set())
    decs = set(EFFORT_KEYS) if kind == "tasks" else set()
    return [{k: norm_date(val(r, k)) if k in dates else dec_str(val(r, k)) if k in decs else val(r, k) for k in keys} for r in rows]


def _err(row, col, msg):
    return {"row": row, "col": col, "msg": msg}


def _is_num(v, lo=None, hi=None):
    try:
        x = float(v)
    except ValueError:
        return False
    return (lo is None or x >= lo) and (hi is None or x <= hi)


def _dup_errors(rows, col, label):
    """同じ値が 2 回目以降に出た行をエラーにする"""
    first = {}
    return [_err(i, col, f"{label}が重複 ({first[r[col]] + 1} 行目)")
            for i, r in enumerate(rows) if r[col] and first.setdefault(r[col], i) != i]


def _task_errors(i, r, codes):
    d = {c: pdate(r[c]) for c in ("plan_start", "plan_end", "actual_start", "actual_end")}
    checks = [
        *((c, "必須です") for c in ("no", "project", "level1", "level3", "category", "owner", "plan_start", "plan_end")
          if not r.get(c)),
        ("no", "No. は 1 以上の整数") if r.get("no") and not re.fullmatch(r"[1-9]\d{0,8}", r["no"]) else None,
        *((c, f"マスタにないコード: {r[c]}") for c, k in (("project", "projects"), ("category", "categories"), ("owner", "owners"))
          if r[c] and r[c] not in codes[k]),
        *((c, "日付は YYYY-MM-DD") for c in d if r[c] and d[c] is None),
        ("plan_end", "予定終了が予定開始より前") if d["plan_start"] and d["plan_end"] and d["plan_end"] < d["plan_start"] else None,
        ("actual_end", "実績終了が実績開始より前") if d["actual_start"] and d["actual_end"] and d["actual_end"] < d["actual_start"] else None,
        ("actual_start", "実績終了があるのに実績開始が空") if r["actual_end"] and not r["actual_start"] else None,
        ("progress", "進捗は 0〜100 の数値") if r["progress"] and not _is_num(r["progress"], 0, 100) else None,
        *((c, "0 以上の数値（小数 2 桁。3 桁目は四捨五入）") for c in EFFORT_KEYS if r.get(c) and dec(r[c]) is None),
    ]
    return [_err(i, c, m) for c, m in filter(None, checks)]


# ---- 影響タスク (depends): 先行タスクの No.。同じファイルの中だけ。循環は禁止 ----
def dep_tokens(v):
    return [x for x in DEP_SPLIT.split((v or "").strip()) if x]


def find_cycles(g):
    """g = {No.: [先行の No. …]}。循環に入っている No. → その No. から始まる循環の道筋 [12, 15, 20, 12]"""
    sys.setrecursionlimit(max(1000, 2 * len(g) + 100))
    state, out = {}, {}

    def visit(n, stack):
        state[n] = 1
        stack.append(n)
        for m in g.get(n, ()):
            if state.get(m) == 1:
                ring = stack[stack.index(m):]
                out.update({k: ring[ring.index(k):] + ring[:ring.index(k)] + [k] for k in ring if k not in out})
            elif m not in state:
                visit(m, stack)
        stack.pop()
        state[n] = 2
    [visit(n, []) for n in g if n not in state]
    return out


def dep_refs(v):
    """depends → 先行の No. の並び (書式の正しいものだけ)"""
    return [m.group(1) for m in map(DEP_ITEM.match, dep_tokens(v)) if m]


def dep_errors(rows):
    """行ごとの depends のエラー (書式・重複・自分自身・存在・循環)"""
    nos = {r["no"] for r in rows if re.fullmatch(r"[1-9]\d{0,8}", r.get("no") or "")}
    def row_msg(r):
        toks, refs = dep_tokens(r.get("depends")), dep_refs(r.get("depends"))
        return next((m for ok, m in (
            (len(refs) == len(toks), f"影響タスクは No. の整数をカンマ区切りで（例 3, 5）: {' '.join(x for x in toks if not DEP_ITEM.match(x))}"),
            (len(set(refs)) == len(refs), f"同じ No. が重複: {', '.join(sorted({x for x in refs if refs.count(x) > 1}))}"),
            (r.get("no") not in refs, "自分自身の No. は指定できません"),
            (all(x in nos for x in refs), f"No. {', '.join(x for x in refs if x not in nos)} はこのファイルにありません"),
        ) if not ok), None)
    first = [(i, r, row_msg(r)) for i, r in enumerate(rows)]
    graph = {r["no"]: [x for x in dep_refs(r.get("depends")) if x in nos] for _, r, m in first if not m and r.get("no") in nos}
    cyc = find_cycles(graph)
    return [_err(i, "depends", m or "循環参照: " + " → ".join(cyc[r["no"]]))
            for i, r, m in first if m or r.get("no") in cyc]


def _rule_error(col, v):
    """追加列の検証: 型 → min/max (数値は値、文字は長さ) → regex"""
    try:
        rule = parse_validation(col["validation"])
    except (ValueError, re.error):
        rule = {}
    n = float(v) if col["type"] in ("int", "number", "percent") and _is_num(v) else len(v)
    return next((m for ok, m in (
        ("min" not in rule or n >= rule["min"], f"{rule.get('min', 0):g} 以上にしてください"),
        ("max" not in rule or n <= rule["max"], f"{rule.get('max', 0):g} 以下にしてください"),
        ("regex" not in rule or re.search(rule.get("regex", ""), v), f"書式が違います（{rule.get('regex')}）"),
    ) if not ok), None)


def value_error(col, v, codes):
    t = col["type"]
    if not v:
        return "必須です" if col["required"] == "yes" else None
    type_ok = {"date": lambda: pdate(v) is not None, "int": lambda: bool(re.fullmatch(r"-?\d+", v)),
               "number": lambda: _is_num(v), "percent": lambda: _is_num(v, 0, 100),
               "bool": lambda: v.lower() in BOOL_VALUES}
    msgs = {"date": "日付は YYYY-MM-DD", "int": "整数で入力", "number": "数値で入力", "percent": "0〜100 の数値", "bool": "はい/いいえ (1/0)"}
    if t in type_ok and not type_ok[t]():
        return msgs[t]
    if t.startswith("code:") and v not in codes.get(t[5:], set()):
        return f"マスタにないコード: {v}"
    if t.startswith("select:") and v not in t[7:].split("/"):
        return f"選択肢にない値: {v}（{t[7:]}）"
    return _rule_error(col, v)


def _extra_errors(i, r, cols, codes):
    return [_err(i, c["key"], m) for c in cols if (m := value_error(c, r.get(c["key"], ""), codes))]


def schema_errors(rows):
    """列定義の保存チェック。コア列の削除・キー変更・型変更・任意化は拒否する"""
    keys = [r["key"] for r in rows]
    core = {c["key"]: c for c in CORE_COLUMNS}
    errs = [_err(-1, "key", f"コア列「{k}」は削除・キー変更できません") for k in CORE_KEYS if k not in keys]
    errs += [_err(-1, "key", f"計算列「{k}」は削除・キー変更できません") for k in CALC_KEYS if k not in keys]
    errs += [_err(i, "type", f"計算列「{r['key']}」の型は変更できません（calc）") for i, r in enumerate(rows) if r["key"] in CALC_KEYS and r["type"] != "calc"]
    errs += [_err(i, "type", "型 calc は計算列 (システム) だけが使えます") for i, r in enumerate(rows) if r["type"] == "calc" and r["key"] not in CALC_KEYS]
    errs += [_err(i, "type", f"コア列「{r['key']}」の型は変更できません（{core[r['key']]['type']}）")
             for i, r in enumerate(rows) if r["key"] in core and r["type"] != core[r["key"]]["type"]]
    errs += [_err(i, "required", f"コア列「{r['key']}」は必須（yes）から外せません")
             for i, r in enumerate(rows) if r["key"] in core and r["required"] != "yes"]
    return errs + [e for i, r in enumerate(rows) for e in _column_row_errors(i, r)] + _dup_errors(rows, "key", "キー")


def _column_row_errors(i, r):
    def bad_validation():
        try:
            parse_validation(r["validation"])
        except (ValueError, re.error) as ex:
            return str(ex)
    vmsg = bad_validation()
    checks = [
        ("key", "キーは 1〜40 文字（, \" 改行は不可）") if not KEY_RE.match(r["key"]) else None,
        ("label", "必須です") if not r["label"] else None,
        ("type", "型は text / int / number / percent / bool / date / code:projects 等 / select:高/中/低") if not TYPE_RE.match(r["type"]) and r["type"] != "calc" else None,
        ("type", "そのマスタ名は使えません") if r["type"].startswith("code:") and r["type"][5:] in RESERVED_KINDS else None,
        ("required", "yes か no") if r["required"] not in ("yes", "no") else None,
        ("visible", "yes か no") if r["visible"] not in ("yes", "no") else None,
        ("width", "幅は 30〜600 の整数") if r["width"] and not (r["width"].isdigit() and 30 <= int(r["width"]) <= 600) else None,
        ("order", "並び順は数値") if r["order"] and not _is_num(r["order"]) else None,
        ("validation", vmsg) if vmsg else None,
        ("bar_pos", "バー表示位置は none / inside / right / left / below / above") if r["bar_pos"] not in BAR_POS else None,
        ("bar_title", "yes か no") if (r.get("bar_title") or "yes") not in ("yes", "no") else None,
        ("bar_short", "短縮名は 10 文字まで（, \" 改行は不可）") if not SHORT_RE.match(r.get("bar_short", "")) else None,
        ("bar_order", "数値") if r["bar_order"] and not _is_num(r["bar_order"]) else None,
        ("bar_max", "最大文字数は 1〜200 の整数") if r["bar_max"] and not (r["bar_max"].isdigit() and 1 <= int(r["bar_max"]) <= 200) else None,
    ]
    return [_err(i, c, m) for c, m in filter(None, checks)]


def _master_errors(i, r):
    checks = [
        ("code", "コードは英数字・_・- (20 文字まで)") if not CODE_RE.match(r["code"]) else None,
        ("name", "必須です") if not r["name"] else None,
        ("color", "色は #rrggbb") if r["color"] and not COLOR_RE.match(r["color"]) else None,
        ("order", "並び順は数値") if r["order"] and not _is_num(r["order"]) else None,
    ]
    return [_err(i, c, m) for c, m in filter(None, checks)]


def _holiday_errors(i, r):
    checks = [
        ("date", "日付は YYYY-MM-DD") if pdate(r["date"]) is None else None,
        ("type", "種類は 祝日 / 会社休日 / 出勤日") if r["type"] not in HOL_TYPES else None,
    ]
    return [_err(i, c, m) for c, m in filter(None, checks)]


def validate(kind, rows):
    """エラー: [{row, col, msg}] (row は 0 始まり)"""
    if kind == "tasks":
        codes = {k: {r["code"] for r in read_rows(k)} for k in master_kinds()}
        generic = [c | ({"required": "no"} if c["key"] in CORE_KEYS else {})  # 優先順位・重要度は列は必須・値は任意
                   for c in load_schema()[0] if (c["key"] not in CORE_KEYS or c["key"] in GENERIC_CORE) and c["type"] != "calc"]
        return ([e for i, r in enumerate(rows) for e in _task_errors(i, r, codes) + _extra_errors(i, r, generic, codes)]
                + _dup_errors(rows, "no", "No. ") + dep_errors(rows))
    if kind == "columns":
        return schema_errors(rows)
    if kind in master_kinds():
        return [e for i, r in enumerate(rows) for e in _master_errors(i, r)] + _dup_errors(rows, "code", "コード")
    if kind == "holidays":
        return [e for i, r in enumerate(rows) for e in _holiday_errors(i, r)] + _dup_errors(rows, "date", "日付")
    return []


def all_tasks():
    """全ファイルのタスク (マスタのコードの使用数はファイルをまたいで数える)"""
    return [r for p in task_files() for r in read_csv_file(p)[1]]


def usage_counts():
    tasks = all_tasks()
    return {kind: dict(Counter(t[c] for t in tasks for c in cols if t.get(c))) for kind, cols in master_uses().items()}


def ensure_masters():
    """コア列が使うマスタ (優先順位・重要度) が無ければ見本で作る"""
    for k, items in SAMPLE_MASTERS.items():
        p = MASTER / f"{k}.csv"
        if not p.exists():
            write_rows(k, [{"code": c, "name": n, "color": col, "order": str(i + 1)} for i, (c, n, col) in enumerate(items)], "", MASTER_FIELDS)
            note = f"マスタ {p.name} を見本の内容で作りました（{'・'.join(f'{c} {n}' for c, n, _ in items)}）"
            log.warning(note)
            MIGRATE_NOTES.append(note)


def move_legacy():
    """初回: data/tasks/ が空なら samples/tasks_master.csv をバックアップしてから data/tasks/ へ写す (元の場所にも残す)"""
    if task_files() or not LEGACY.exists():
        return
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-files"
    (BACKUP / stamp / "samples").mkdir(parents=True, exist_ok=True)
    shutil.copy2(LEGACY, BACKUP / stamp / "samples" / LEGACY.name)
    TASK_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(LEGACY, TASK_DIR / DEFAULT_TASK)
    note = (f"タスクのファイル置き場を data/tasks/ にしました。samples/{LEGACY.name} を data/tasks/{DEFAULT_TASK} へ写しました"
            f"（元のファイルは残しますが、以後は書き戻しません。バックアップ: data/backup/{stamp}/samples/）")
    log.warning(note)
    MIGRATE_NOTES.append(note)


def migrate_tasks(p):
    """新しいコア列 (no・priority・importance・…・actual_effort・unit_price) が無いタスク CSV に一度だけ追加する。直前のファイルはバックアップ。
    no は今の行の順に 1..N、先頭の列。priority / importance / depends / calendar は空欄で最後に足す"""
    head, rows = read_csv_file(p)
    miss = [k for k in ("no", "priority", "importance", "depends", "calendar", "actual_effort", "unit_price") if k not in head]
    if not head or not miss:
        return
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-migrate"
    new_head = ["no"] * ("no" in miss) + head + [k for k in miss if k != "no"]
    fill = lambda i: ({"no": str(i + 1)} if "no" in miss else {}) | {k: "" for k in miss if k != "no"}  # noqa: E731
    tok = CUR_FILE.set(p)
    write_rows("tasks", [r | fill(i) for i, r in enumerate(rows)], stamp, new_head)
    CUR_FILE.reset(tok)
    how = f"No. は今の行の順に 1〜{len(rows)}、ほかは空欄" if "no" in miss else "値は空欄"
    note = (f"タスク CSV {p.name} に列 {', '.join(miss)} を追加しました（{how}。ほかの列・行はそのまま。"
            f"元のファイル: data/backup/{stamp}/tasks/{p.name}）")
    log.warning(note)
    MIGRATE_NOTES.append(note)


def cleanup():
    """古い出力 (web/output のジョブ) と古いバックアップ (data/backup の世代) を消す。手動の退避 (manual-*) は消さない"""
    prm = load_params()
    days = int(prm["output_keep_days"]) if str(prm.get("output_keep_days", "")).isdigit() else 30
    keep = int(prm["backup_keep"]) if str(prm.get("backup_keep", "")).isdigit() else 100
    limit = dt.datetime.now().timestamp() - days * 86400
    old_out = [d for d in (OUTPUT.iterdir() if OUTPUT.exists() else []) if d.is_dir() and JOB_RE.match(d.name) and d.stat().st_mtime < limit]
    gens = sorted((d for d in (BACKUP.iterdir() if BACKUP.exists() else []) if d.is_dir() and re.match(r"^\d{8}-\d{6}", d.name)), key=lambda d: d.name)
    old_bak = gens[:max(0, len(gens) - keep)]
    [shutil.rmtree(d, ignore_errors=True) for d in old_out + old_bak]
    (old_out or old_bak) and log.info("古いファイルを片付けました: 出力 %d 件・バックアップ %d 世代", len(old_out), len(old_bak))
    return len(old_out), len(old_bak)


def ensure_params():
    """master/params.csv が無ければ既定値で作る (chart.py も同じファイルを読む)"""
    if not (MASTER / "params.csv").exists():
        write_rows("params", [{"key": d["key"], "value": d["default"], "label": d["label"]} for d in PARAM_DEFS], "")
        note = f"パラメータ master/params.csv を作りました（{'・'.join(f'{d['label']} {d['default']}' for d in PARAM_DEFS)}）"
        log.warning(note)
        MIGRATE_NOTES.append(note)


def prepare_data():
    ensure_params()
    ensure_masters()
    move_legacy()
    [migrate_tasks(p) for p in task_files()]


# ---------------- 画面 ----------------
@app.get("/")
def index():
    return send_from_directory(WEB / "static", "index.html")


@app.get("/favicon.ico")
def favicon():
    return "", 204


@app.after_request
def no_cache(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


# ---------------- API ----------------
@app.get("/api/data")
def api_data():
    prepare_data()
    years = {d.year for t in all_tasks()
             for d in (pdate(t.get(c, "")) for c in ("plan_start", "plan_end", "actual_start", "actual_end")) if d}
    years |= {dt.date.today().year}
    jp = [h for y in range(min(years) - 1, max(years) + 2) for h in (jp_holidays(y) or [])]
    cols, notes = load_schema()
    data = {k: read_rows(k) for k in all_kinds() if k != "tasks"} | {"columns": cols}  # タスクはファイルごとに /api/tasks
    return jsonify(data | {"files": files_info(),
        "schema_notices": REPAIR_NOTES, "migrate_notices": MIGRATE_NOTES,
        "masters": [{"kind": k, "label": MASTER_LABELS.get(k) or next((c["label"] for c in cols if c["type"] == f"code:{k}"), k),
                     "builtin": k in ("categories", "projects", "owners"), "fields": fields_of(k)} for k in master_kinds()], "core_keys": CORE_KEYS, "calc_keys": CALC_KEYS, "presets": load_presets(),
        "params": load_params(), "param_defs": PARAM_DEFS,
        "usage": usage_counts(), "settings": load_settings(), "jp": jp, "jp_available": jp_holidays(2026) is not None,
        "today": dt.date.today().isoformat(), "paths": {"tasks": str(TASK_DIR), "master": str(MASTER)}})


def files_info():
    def one(p):
        head, rows = read_csv_file(p)
        usage = {kind: dict(Counter(r[c] for r in rows for c in cols if r.get(c))) for kind, cols in master_uses().items()}
        return {"name": p.name, "rows": len(rows), "missing": missing_headers(head), "usage": usage,
                "mtime": dt.datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")}
    return [one(p) for p in task_files()]


@app.get("/api/files")
def api_files():
    return jsonify({"ok": True, "files": files_info()})


@app.get("/api/tasks")
def api_tasks():
    """1 ファイルのタスク (行の識別子付き)。必須の列が無ければ黙って直さずエラーを返す"""
    p = task_path()
    if not p.exists():
        return jsonify({"ok": False, "file": p.name, "tasks": [], "error": "タスクのファイルがありません"}), 404
    miss = missing_headers(task_header())
    return jsonify({"ok": not miss, "file": p.name, "header": task_header(), "version": file_version(p), "tasks": [] if miss else with_ids(read_rows("tasks")),
                    "error": f"タスク CSV に必須の列がありません: {', '.join(miss)}（{p.name}）" if miss else ""})


def unique_name(name):
    """同じ名前があれば _2, _3 … を付ける (上書きしない)"""
    stem = name[:-4]
    return next(n for n in (f"{stem}{'' if k == 1 else f'_{k}'}.csv" for k in range(1, 1000)) if not (TASK_DIR / n).exists())


def write_new_file(name, text):
    """新しいファイルとして書く。既にあれば書かない (False)"""
    TASK_DIR.mkdir(parents=True, exist_ok=True)
    try:
        with (TASK_DIR / name).open("x", encoding="utf-8-sig", newline="") as f:  # "x": 既存のファイルは決して上書きしない
            f.write(text)
        return True
    except FileExistsError:
        return False


@app.post("/api/files/upload")
def api_files_upload():
    """CSV を新しいファイルとして取り込む (既存のファイルは上書きしない。同名なら _2 などを付ける)。必須の列を確認"""
    f = request.files.get("file")
    if not f:
        return jsonify({"ok": False, "msg": "ファイルがありません"}), 400
    want = request.form.get("name") or Path(f.filename or "").name
    name = safe_name(want if want.lower().endswith(".csv") else f"{want}.csv")
    if not name:
        return jsonify({"ok": False, "msg": f"ファイル名が使えません: {want}（\\ / : * ? \" < > | は不可、80 文字まで、.csv）"}), 400
    raw = f.read()
    text = next((t for t in map(lambda enc: _decode(raw, enc), ("utf-8-sig", "cp932")) if t is not None), None)
    if text is None:
        return jsonify({"ok": False, "msg": "文字コードが読めません (UTF-8 か Shift_JIS)"}), 400
    rd = csv.DictReader(io.StringIO(text))
    head = [h.strip() for h in rd.fieldnames or []]
    nrows = sum(1 for _ in rd)
    if miss := [k for k in missing_headers(head) if k not in AUTO_ADD]:  # 値が任意の新しいコア列だけ足りないなら補って受け付ける
        return jsonify({"ok": False, "msg": f"必須の列がありません: {', '.join(miss)}", "missing": miss}), 400
    final = unique_name(name)
    if not write_new_file(final, text.replace("\r\n", "\n").replace("\n", "\r\n")):
        return jsonify({"ok": False, "msg": f"{final} は既にあります"}), 409
    added = [k for k in AUTO_ADD if k not in head]
    added and migrate_tasks(TASK_DIR / final)
    log.info("取り込み: %s (%d 行)", final, nrows)
    return jsonify({"ok": True, "name": final, "renamed": final != name, "rows": nrows, "added_columns": sorted(added)})


@app.post("/api/files/copy")
def api_files_copy():
    """ファイルをまるごと複製して新しいファイルにする (前回分のスナップショットなど)。同名は不可"""
    req = request.get_json(silent=True) or {}
    src = task_file(req.get("src"))
    name = safe_name(req.get("name") or f"{src.stem}_{dt.datetime.now():%Y%m%d-%H%M%S}.csv")
    if not name:
        return jsonify({"ok": False, "msg": "ファイル名が使えません（\\ / : * ? \" < > | は不可、80 文字まで、.csv）"}), 400
    if not write_new_file(name, read_text_any(src)):  # Access の SJIS のままでも複製できる (複製は UTF-8 BOM 付き)
        return jsonify({"ok": False, "msg": f"{name} は既にあります（別の名前にしてください）"}), 409
    return jsonify({"ok": True, "name": name})


@app.post("/api/validate/<kind>")
def api_validate(kind):
    if kind not in all_kinds():
        abort(404)
    rows = clean_rows(kind, (request.get_json(silent=True) or {}).get("rows"))
    return jsonify({"errors": validate(kind, rows)})


@app.post("/api/save/<kind>")
def api_save(kind):
    if kind not in all_kinds():
        abort(404)
    sent = (request.get_json(silent=True) or {}).get("rows")
    if kind == "tasks" and "file" not in request.args:  # どのファイルに書くかは必ず指定させる
        return jsonify({"ok": False, "msg": "保存するファイル (?file=) の指定がありません"}), 400
    ver = (request.get_json(silent=True) or {}).get("version")
    if kind == "tasks" and ver and ver != file_version(task_path()):
        return jsonify({"ok": False, "msg": f"{task_path().name} は読み込んだ後に外部（Access など）で更新されています。"
                        "画面を再読み込みして新しい内容を読んでから編集し直してください（上書きしません）", "stale": True}), 409
    if kind == "tasks" and isinstance(sent, list) and (bad := row_set_error(sent)):
        return jsonify({"ok": False, "msg": bad, "errors": [_err(-1, "rows", bad)]}), 422
    rows = clean_rows(kind, sent)
    errs = validate(kind, rows)
    if kind in master_kinds():  # タスクで使っているコードは削除できない
        left = {r["code"] for r in rows}
        errs += [_err(-1, "code", f"コード {code} はタスク {n} 件で使用中のため削除できません")
                 for code, n in sorted(usage_counts()[kind].items()) if code not in left]
    if errs:
        return jsonify({"ok": False, "errors": errs, "msg": errs[0]["msg"]}), 422
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    if kind == "columns":
        return save_schema(rows, stamp)
    if kind == "tasks" and (miss := missing_headers(task_header())):
        return jsonify({"ok": False, "msg": f"タスク CSV に必須の列がないため上書きしません: {', '.join(miss)}（CSV を直接直してください）"}), 422
    write_rows(kind, rows, stamp)
    cleanup()
    return jsonify({"ok": True, "saved": len(rows), "file": task_path().name if kind == "tasks" else None, "backup": str(BACKUP / stamp),
                    "version": file_version(task_path()) if kind == "tasks" else None})


def save_schema(rows, stamp):
    """列定義を保存。コア列は変えてよい項目だけ反映。新しく足した列はタスク CSV にも既定値で追加する"""
    core = {c["key"]: (i, c) for i, c in enumerate(CORE_COLUMNS + CALC_COLUMNS)}
    rows = [r | {"bar_title": r.get("bar_title") or "yes", "bar_short": r.get("bar_short") or ""} for r in rows]  # 古い画面・API からは無いことがある
    rows = [_editable(r, core_def(core[r["key"]][1], core[r["key"]][0] + 1)) if r["key"] in core else r for r in rows]
    write_rows("columns", rows, stamp, COL_FIELDS)
    REPAIR_NOTES.clear()
    for k in {r["type"][5:] for r in rows if r["type"].startswith("code:")} - set(BUILTIN_MASTERS):  # 新しいマスタは空で作る
        (MASTER / f"{k}.csv").exists() or write_rows(k, [], stamp, MASTER_FIELDS)
    added = sorted({k for p in task_files() for k in add_columns(p, rows, stamp)})  # 列定義は共通: 全ファイルに足す
    return jsonify({"ok": True, "saved": len(rows), "added_to_tasks": added, "backup": str(BACKUP / stamp)})


def add_columns(p, cols, stamp):
    head, trows = read_csv_file(p)
    new = [c for c in cols if c["key"] not in head and c["type"] != "calc"]  # 計算列は CSV に足さない
    if not new or not head:
        return []
    tok = CUR_FILE.set(p)
    write_rows("tasks", [t | {c["key"]: c["default"] for c in new} for t in trows], stamp, [*head, *(c["key"] for c in new)])
    CUR_FILE.reset(tok)
    return [c["key"] for c in new]


def load_presets():
    try:
        return json.loads(PRESETS.read_text(encoding="utf-8")) if PRESETS.exists() else {}
    except (ValueError, OSError):
        return {}


@app.post("/api/presets")
def api_presets():
    """フィルター条件の保存 {name, preset: {filters, sort}}。preset が null なら削除"""
    req = request.get_json(silent=True) or {}
    name = str(req.get("name") or "").strip()
    if not 1 <= len(name) <= 40 or len(json.dumps(req.get("preset"))) > 20000:
        return jsonify({"ok": False, "msg": "名前は 1〜40 文字"}), 400
    ps = load_presets()
    ps = {k: v for k, v in ps.items() if k != name} | ({name: req["preset"]} if req.get("preset") else {})
    PRESETS.write_text(json.dumps(ps, ensure_ascii=False, indent=2), encoding="utf-8")
    return jsonify({"ok": True, "presets": ps})


@app.post("/api/settings")
def api_settings():
    s = load_settings()
    s.update({k: str(v) for k, v in (request.get_json(silent=True) or {}).items() if k in DEFAULT_SETTINGS})
    s["grid_col_order"] = ",".join(k for k in s["grid_col_order"].split(",") if KEY_RE.match(k))[:4000]
    s["grid_hidden"] = ",".join(k for k in s["grid_hidden"].split(",") if KEY_RE.match(k))[:4000]
    s["grid_frozen"] = str(min(max(int(s["grid_frozen"]) if s["grid_frozen"].isdigit() else 0, 0), 30))
    s["open_files"] = "\n".join(dict.fromkeys(n for n in s["open_files"].split("\n") if safe_name(n)))[:8000]  # 名前に , を使えるよう改行区切り
    s.update({k: s[k] if safe_name(s[k]) else "" for k in ("cur_file", "out_file", "cmp_a", "cmp_b")})
    s["gantt_deps"] = "off" if s["gantt_deps"] == "off" else "on"
    s["gantt_collapsed"] = "\n".join(dict.fromkeys(k for k in s["gantt_collapsed"].split("\n") if k and len(k) <= 600 and not re.search(r"[\x00-\x08\x0b-\x1f]", k)))[:20000]
    s["gantt_span"] = s["gantt_span"] if s["gantt_span"] in ("auto", "fixed", "all") else "auto"
    s.update({k: s[k] if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s[k]) else "" for k in ("gantt_span_from", "gantt_span_to")})
    SETTINGS.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
    return jsonify({"ok": True, "settings": s})


@app.get("/api/jpholidays")
def api_jp():
    try:
        y = int(request.args.get("year", dt.date.today().year))
    except ValueError:
        abort(400)
    if not 1955 <= y <= 2100:
        abort(400)
    lst = jp_holidays(y)
    if lst is None:
        return jsonify({"ok": False, "msg": "jpholiday が入っていません (pip install jpholiday)"}), 501
    return jsonify({"ok": True, "year": y, "holidays": lst})


@app.get("/api/export/<kind>")
def api_export(kind):
    p = path_of(kind)
    if not p.exists():
        abort(404)
    if kind != "tasks":
        return send_file(p, mimetype="text/csv", as_attachment=True, download_name=p.name)
    return export_tasks(p, request.args.get("calc") == "1")


def export_tasks(p, with_calc):
    """タスク CSV のダウンロード: 保存されている列 (工数・単価は 2 桁の形に)。calc=1 なら計算列を後ろに足す (既定は付けない)"""
    head, _ = read_csv_file(p)
    rows = [r | {k: dec_str(r.get(k, "")) for k in EFFORT_KEYS if k in r} for r in read_rows("tasks")]
    hours, is_off = dec(load_params()["hours_per_day"]), work_calendar()
    calc = [{k: "" if v is None else f"{v:.2f}" for k, v in calc_values(r, hours, is_off).items()} for r in rows] if with_calc else [{} for _ in rows]
    fields = [*head, *(CALC_KEYS if with_calc else [])]
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=fields, lineterminator="\r\n", extrasaction="ignore")
    w.writeheader()
    w.writerows({k: (r | c).get(k, "") for k in fields} for r, c in zip(rows, calc))
    name = p.stem + ("_計算列付き" if with_calc else "") + ".csv"
    return send_file(io.BytesIO(("\ufeff" + buf.getvalue()).encode("utf-8")), mimetype="text/csv", as_attachment=True, download_name=name)


@app.post("/api/params")
def api_params():
    """パラメータの保存 (master/params.csv。前の内容はバックアップ)"""
    sent = (request.get_json(silent=True) or {}).get("values") or {}
    vals = load_params() | {k: str(v).strip() for k, v in sent.items() if k in {p["key"] for p in PARAM_DEFS}}
    if errs := param_errors(vals):
        return jsonify({"ok": False, "errors": errs, "msg": errs[0]["msg"]}), 422
    vals["hours_per_day"] = dec_str(vals["hours_per_day"])
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    write_rows("params", [{"key": d["key"], "value": vals[d["key"]], "label": d["label"]} for d in PARAM_DEFS], stamp)
    return jsonify({"ok": True, "params": load_params(), "backup": str(BACKUP / stamp)})


def _decode(raw, enc):
    try:
        return raw.decode(enc)
    except UnicodeDecodeError:
        return None


@app.post("/api/import/<kind>")
def api_import(kind):
    """CSV を読み込んで行を返す (保存は画面の「保存」で行う)"""
    if kind not in all_kinds():
        abort(404)
    if kind == "tasks":  # 読み込みは行の追加・削除になりうるので Web 画面では受け付けない
        return jsonify({"ok": False, "msg": "タスクの CSV 読み込みは使えません（行の追加・削除は CSV を直接編集してください）"}), 403
    f = request.files.get("file")
    if not f:
        abort(400, "ファイルがありません")
    raw = f.read()
    text = next((t for t in map(lambda enc: _decode(raw, enc), ("utf-8-sig", "cp932")) if t is not None), None)
    if text is None:
        return jsonify({"ok": False, "msg": "文字コードが読めません (UTF-8 か Shift_JIS)"}), 400
    rd = csv.DictReader(io.StringIO(text))
    head = [h.strip() for h in rd.fieldnames or []]
    miss = missing_headers(head) if kind == "tasks" else [c for c in fields_of(kind) if c not in head]
    if miss:
        return jsonify({"ok": False, "msg": f"必須の列がありません: {', '.join(miss)}", "missing": miss}), 400
    raw_rows = [{(k or "").strip(): v for k, v in r.items() if k} for r in rd]
    rows = clean_rows(kind, raw_rows)  # Excel の 2026/10/5 形式も yyyy-mm-dd に直す (追加の列も残す)
    return jsonify({"ok": True, "rows": rows, "header": head, "errors": validate(kind, rows)})


@app.post("/api/generate")
def api_generate():
    s = load_settings()
    req = request.get_json(silent=True) or {}
    s.update({k: str(v) for k, v in req.items() if k in DEFAULT_SETTINGS})
    # 入力値を厳密に確認 (任意の引数・パスを渡さない)
    choice = {"view": ("all", "project", "owner"), "range": ("week", "month", "year"), "workdays": ("on", "off"),
              "jp_holidays": ("on", "off"), "inazuma": ("on", "off"), "deps": ("on", "off"), "effort_cols": ("on", "off"), "page": ("a4-landscape", "a4-portrait", "a3-landscape", ""),
              "split_by": ("", "level1", "project", "owner"), "format": ("pdf", "png")}
    bad = next((k for k, ok in choice.items() if s[k] not in ok), None)
    if bad:
        return jsonify({"ok": False, "msg": f"{bad} の値が不正です: {s[bad]}"}), 400
    bad = next((k for k in ("today", "date_from", "date_to") if s[k] and pdate(s[k]) is None), None)
    if bad:
        return jsonify({"ok": False, "msg": f"{bad} は YYYY-MM-DD"}), 400
    if not re.fullmatch(r"[a-z]{3}(,[a-z]{3})*", s["weekend"] or "sat,sun"):
        return jsonify({"ok": False, "msg": "週末の指定が不正です"}), 400
    if s["view"] == "owner" and s["split_by"] in ("level1", "project"):
        return jsonify({"ok": False, "msg": "担当者ビューの改ページは「担当者ごと」か「なし」です"}), 400
    prepare_data()
    cleanup()
    if req.get("file"):
        CUR_FILE.set(task_file(req["file"]))
    s["out_file"] = task_path().name
    SETTINGS.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")  # 正しい設定だけ記憶
    if miss := missing_headers(task_header()):
        return jsonify({"ok": False, "msg": f"タスク CSV に必須の列がありません: {', '.join(miss)}"}), 422
    errs = validate("tasks", read_rows("tasks"))
    if errs:
        return jsonify({"ok": False, "msg": f"タスクに {len(errs)} 件のエラーがあります。先に修正して保存してください",
                        "errors": errs[:20]}), 422
    job = dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    jdir = OUTPUT / job
    jdir.mkdir(parents=True)
    out = jdir / ("gantt.pdf" if s["format"] == "pdf" and s["page"] else "gantt.png")
    cmd = [sys.executable, str(CHART), "gantt2", str(task_path()), "--layout", "clean", "--grid", "auto",
           "--bars", "split", "--patterns", "off", "--actual-style", "flat",
           "--today-band", "#d8f5a2", "--inazuma-color", "#c92a2a",
           "--legend", "header-split" if s["page"] else "inline",
           "--master", str(MASTER), "--jp-holidays", s["jp_holidays"], "--workdays", s["workdays"],
           "--weekend", s["weekend"] or "sat,sun", "--view", s["view"], "--range", s["range"],
           "--inazuma", s["inazuma"], "--deps", s["deps"], "--today", s["today"] or dt.date.today().isoformat(), "-o", str(out)]
    if s["page"]:
        cmd += ["--page", s["page"], "--bookmarks", "on"]  # PDF のしおり (プロジェクト＞大項目＞中項目)
    else:
        cmd += ["--min-day-px", "24" if s["range"] == "week" else "8"]
    if s["split_by"]:
        cmd += ["--split-by", s["split_by"]]
    if s.get("effort_cols") == "on":  # clean の列 ＋ 工数・金額 (既定は OFF = 今までどおり)
        cmd += ["--columns", "plan_start,plan_end,plan_days,actual_start,actual_end,actual_days,progress,"
                "actual_effort,unit_price,plan_effort,plan_amount,actual_amount", "--no-column", "on"]
    if s["date_from"]:
        cmd += ["--from", s["date_from"]]
    if s["date_to"]:
        cmd += ["--to", s["date_to"]]
    view_ja = {"all": "全体", "project": "プロジェクト別", "owner": "担当者別"}[s["view"]]
    range_ja = {"week": "週次", "month": "月次", "year": "年間"}[s["range"]]
    cmd += ["--title", (s["title"] or f"{view_ja} {range_ja}")[:100]]
    try:
        env = {**__import__("os").environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"}  # Windows でも子プロセスの出力を UTF-8 にそろえる
        cp = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300, cwd=str(BASE), env=env)
    except subprocess.TimeoutExpired:
        return jsonify({"ok": False, "msg": "時間切れ (300 秒)"}), 500
    log = (cp.stdout + cp.stderr).strip()
    if cp.returncode != 0:
        last = next((ln for ln in reversed(log.splitlines()) if ln.strip()), "")
        return jsonify({"ok": False, "msg": f"作成に失敗しました: {last[:300]}", "log": log[-3000:]}), 500
    page_no = lambda n: int(m.group(1)) if (m := re.search(r"_p(\d+)\.png$", n)) else 0  # noqa: E731
    pngs = sorted((p.name for p in jdir.glob("*.png")), key=page_no)
    zp = jdir / "gantt_png.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for n in pngs:
            z.write(jdir / n, n)
    res = {"ok": True, "job": job, "file": task_path().name, "pngs": [f"/output/{job}/{n}" for n in pngs], "zip": f"/output/{job}/gantt_png.zip",
           "log": log[-3000:]}
    if (jdir / "gantt.pdf").exists():
        res["pdf"] = f"/output/{job}/gantt.pdf"
    return jsonify(res)


@app.get("/output/<job>/<name>")
def output_file(job, name):
    if not JOB_RE.match(job) or not FILE_RE.match(name):
        abort(404)
    p = OUTPUT / job / name
    if not p.is_file():
        abort(404)
    return send_file(p, as_attachment=request.args.get("dl") == "1", download_name=name)


def main():
    ap = argparse.ArgumentParser(description="ガントチャート入力 Web UI")
    ap.add_argument("--host", default="127.0.0.1", help="待ち受けアドレス (既定 127.0.0.1 = このPCだけ)")
    ap.add_argument("--port", type=int, default=8050)
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--open", action="store_true", help="起動したらブラウザで開く")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    load_schema()  # 起動時にもコア列を確認 (欠けていれば復元して警告)
    prepare_data()  # 新しいコア列の移行・マスタの見本
    cleanup()  # 古い出力・バックアップを片付ける (残す日数・世代は 設定 > パラメータ)
    a.host not in ("127.0.0.1", "localhost") and log.warning("%s で待ち受けます。信頼できる社内ネットワークだけで使ってください（認証はありません）", a.host)
    url = f"http://{'127.0.0.1' if a.host in ('0.0.0.0', '::') else a.host}:{a.port}/"
    a.open and __import__("threading").Timer(1.5, __import__("webbrowser").open, [url]).start()
    print(f"http://{a.host}:{a.port}/ を開いてください  (タスク: {TASK_DIR}, マスタ: {MASTER})")
    app.run(host=a.host, port=a.port, debug=a.debug, use_reloader=False)


if __name__ == "__main__":
    main()
