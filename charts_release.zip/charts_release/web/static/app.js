"use strict";
/* ガントチャート入力 UI (バニラ JS・外部ライブラリなし) */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
let KINDS = ["columns", "categories", "projects", "owners", "holidays", "tasks"];  // 保存の順番 (列定義 → マスタ → タスク)。読み込みで作り直す
let MASTERS = ["categories", "projects", "owners"];  // 組み込み ＋ 列定義の code:<名前> で使うマスタ (サーバーが返す)
const isMaster = kind => MASTERS.includes(kind);
const masterUses = kind => (S.data.columns || []).filter(c => c.type === `code:${kind}`).map(c => c.key);  // そのマスタを使う列
const ROWS_FIXED = new Set(["tasks"]);  // タスクは行の追加・複写・削除・並べ替え不可 (セルの値の編集だけ。サーバーも 1 対 1 を確認)
const KIND_JA = { priorities: "優先順位", importance: "重要度", tasks: "タスク", categories: "カテゴリ", projects: "プロジェクト", owners: "担当者", holidays: "休日", columns: "列定義" };
const WK = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
const WK_JA = "日月火水木金土";
const S = { data: {}, dirty: new Set(), files: new Map(), cur: "", fileList: [], settings: {}, jp: [], usage: {}, undo: [], sort: {}, today: "", coreKeys: [], notices: [], migrateNotices: [], closedNotices: new Set(), tasksError: "", presets: {} };

/* ---------- 日付・カレンダー ---------- */
const dn = s => {
  const n = /^\d{4}-\d{2}-\d{2}$/.test(s || "") ? Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)) / 864e5 : null;
  return n !== null && ds(n) === s ? n : null;  // 2026-02-31 のような存在しない日付は無効
};
/* 表示は yyyy/mm/dd (ブラウザの言語に依らない)、保存は yyyy-mm-dd。入力は 2026/10/15・2026-10-15・10/15 を受け付ける */
const fmtDate = s => (/^\d{4}-\d{2}-\d{2}$/.test(s || "") ? s.replace(/-/g, "/") : s || "");
const normDate = (raw, ref = "") => {
  const v = String(raw ?? "").trim(), pad = x => String(x).padStart(2, "0");
  const ymd = v.match(/^(\d{4})[/.-](\d{1,2})[/.-](\d{1,2})$/), md = v.match(/^(\d{1,2})[/.-](\d{1,2})$/);
  const year = (ref || S.settings.today || S.today || new Date().toISOString()).slice(0, 4);
  return ymd ? `${ymd[1]}-${pad(ymd[2])}-${pad(ymd[3])}` : md ? `${year}-${pad(md[1])}-${pad(md[2])}` : v;
};
const ds = n => new Date(n * 864e5).toISOString().slice(0, 10);
const wday = n => new Date(n * 864e5).getUTCDay();
const range = (a, b) => (b < a ? [] : Array.from({ length: b - a + 1 }, (_, k) => a + k));
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const calendar = () => {
  const wk = new Set((S.settings.weekend || "sat,sun").split(",").map(w => WK[w]).filter(v => v !== undefined));
  const jp = S.settings.jp_holidays === "on" ? S.jp : [];
  const hol = new Map([...jp, ...S.data.holidays.filter(h => h.type !== "出勤日")].map(h => [h.date, h]));
  const work = new Set(S.data.holidays.filter(h => h.type === "出勤日").map(h => h.date));
  const isOff = n => !work.has(ds(n)) && (hol.has(ds(n)) || wk.has(wday(n)));
  const nwork = (a, b) => range(a, b).filter(n => !isOff(n)).length;
  /* タスクごとの日数: 稼働カレンダーが「暦日」なら休日も数える (バッチなど毎日動くもの)。空欄・休日除外は稼働日 */
  const ndays = (t, a, b) => (isCalDay(t) ? Math.max(0, b - a + 1) : nwork(a, b));
  return { hol, work, isOff, nwork, ndays };
};

/* ---------- 工数・単価・金額: 小数 2 桁、端数は四捨五入 (half-up)。浮動小数は使わず、文字列 → 100 倍の整数 (BigInt) で計算 ---------- */
const EFFORT_KEYS = ["actual_effort", "unit_price"];  // 保存する列 (手入力)
const CALC_KEYS = ["plan_effort", "plan_amount", "actual_amount"];  // 計算列 (保存しない)
const toCents = raw => {  // "1,234.565" → 123457n。空欄・数値でない・負 → null
  const m = String(raw ?? "").normalize("NFKC").replace(/,/g, "").trim().replace(/^[¥$\\]/, "").match(/^(\d{1,12})(?:\.(\d+))?$/);
  if (!m) return null;
  const f = (m[2] || "").padEnd(3, "0");
  return BigInt(m[1]) * 100n + BigInt(f.slice(0, 2)) + (+f[2] >= 5 ? 1n : 0n);  // 3 桁目が 5 以上なら切り上げ (0 以上なので half-up = 四捨五入)
};
const mulCents = (a, b) => (a === null || b === null ? null : (a * b + 50n) / 100n);  // 2 桁 × 2 桁 → 4 桁を 2 桁に四捨五入
const sumCents = xs => (xs.some(x => x !== null) ? xs.filter(x => x !== null).reduce((a, x) => a + x, 0n) : null);
const fmtCents = (c, sep = true) => {  // 123457n → "1,234.57" (sep=false なら保存形 "1234.57")。null → ""
  if (c === null || c === undefined) return "";
  const t = c.toString().padStart(3, "0"), i = t.slice(0, -2);
  return `${sep ? i.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : i}.${t.slice(-2)}`;
};
const dec2 = raw => (toCents(raw) === null ? String(raw ?? "").trim() : fmtCents(toCents(raw), false));  // 保存の形 (読めない値はそのまま → 検証でエラー)
const hoursCents = () => toCents(S.params?.hours_per_day) ?? 800n;  // 工数の基準値 (時間/日)
const planDaysOf = t => { const [a, b] = [dn(t.plan_start), dn(t.plan_end)]; return a !== null && b !== null && b >= a ? S.cal.ndays(t, a, b) : null; };
/* タスクの工数・金額 (100 倍の整数か null)。予定は参考値: 予定日数 (稼働カレンダーどおり) × 基準値 */
const effortOf = t => {
  const n = planDaysOf(t), price = toCents(t.unit_price), act = toCents(t.actual_effort), pe = n === null ? null : BigInt(n) * hoursCents();
  return { actual_effort: act, unit_price: price, plan_effort: pe, plan_amount: mulCents(pe, price), actual_amount: mulCents(act, price) };
};
/* 親の行: 子の合計 (単価は空欄) */
const effortSum = ts => (vals => ({ ...Object.fromEntries(["actual_effort", ...CALC_KEYS].map(k => [k, sumCents(vals.map(v => v[k]))])), unit_price: null }))(ts.map(effortOf));
const EFFORT_TIP = {
  plan_effort: () => `予定工数（参考）= 予定日数 × 工数の基準値 ${fmtCents(hoursCents())} 時間/日。予定日数は稼働カレンダーどおり（休日除外 = 稼働日、暦日 = 暦の日数）。保存されない参考値です`,
  plan_amount: () => "予定金額（参考）= 予定工数（参考）× 単価。保存されない参考値です（小数 2 桁、四捨五入）",
  actual_amount: () => "実績金額 = 実績工数 × 単価（小数 2 桁、四捨五入）。保存されない計算値です",
  actual_effort: () => "実績工数（手入力・0 以上・小数 2 桁。3 桁目は四捨五入）", unit_price: () => "単価（手入力・0 以上・小数 2 桁。3 桁目は四捨五入）",
};
const effText = (t, k) => fmtCents(effortOf(t)[k]);

/* ---------- 設定タブ: 休日 / パラメータ (master/params.csv。全ファイル共通) ---------- */
const PARAM_INFO = [["端数処理", "四捨五入（ROUND_HALF_UP）・小数 2 桁（固定）"], ["保存先", "master/params.csv（出力の chart.py も同じ値を使います）"]];
const PARAM_INT = { output_keep_days: 3650, backup_keep: 10000 };  // 整数のパラメータ (上限)
const paramErr = (k, v) => (k === "hours_per_day" ? ((c => c === null || c <= 0n)(toCents(v)) && "0 より大きい数値（小数 2 桁）")
  : k === "currency" ? !(v.length >= 1 && v.length <= 10) && "1〜10 文字"
  : PARAM_INT[k] ? !(/^\d+$/.test(v) && +v >= 1 && +v <= PARAM_INT[k]) && `1〜${PARAM_INT[k]} の整数` : null) || "";
const renderParams = () => {
  const box = $("#params-form");
  if (!box) return;
  const row = d => el("label", { class: "prm" }, el("span", { class: "prm-l", text: d.label }),
    el("input", { "data-param": d.key, class: d.key === "hours_per_day" ? "num" : "", inputmode: d.key === "hours_per_day" ? "decimal" : null,
      value: d.key === "hours_per_day" ? fmtCents(toCents(S.params[d.key])) : S.params[d.key] ?? "" }),
    el("span", { class: "prm-err err-text", "data-err": d.key }));
  box.replaceChildren(...S.paramDefs.map(row),
    ...PARAM_INFO.map(([l, v]) => el("div", { class: "prm info" }, el("span", { class: "prm-l", text: l }), el("span", { class: "muted", text: v }))));
  $("#params-state").textContent = "";
};
const bindParams = () => {
  $("#params-form").addEventListener("input", e => {  // 入力したらすぐ予定工数・金額を計算し直す (保存は「パラメータを保存」)
    const k = e.target.dataset.param, v = e.target.value.trim(), m = paramErr(k, v);
    $(`[data-err=${k}]`).textContent = m;
    if (!m) { S.params = { ...S.params, [k]: k === "hours_per_day" ? dec2(v) : v }; S.taskSpec = null; renderAll(); }
    $("#params-state").textContent = "未保存の変更があります（予定工数・金額は新しい値で表示中）";
  });
  $("#params-form").addEventListener("change", e => e.target.dataset.param === "hours_per_day" && !paramErr("hours_per_day", e.target.value) && (e.target.value = fmtCents(toCents(e.target.value))));
  $("#btn-params-save").addEventListener("click", async () => {
    const values = Object.fromEntries($$("[data-param]").map(i => [i.dataset.param, i.value.trim()]));
    const r = await post("/api/params", { values });
    if (!r.ok) return msg(`パラメータを保存できません: ${r.msg}`, false);
    S.params = r.params; renderParams(); renderAll(); msg(`パラメータを保存しました（master/params.csv。バックアップ: ${r.backup}）`);
  });
  $$("#tab-holidays .subtabs button").forEach(b => b.addEventListener("click", () => {
    $$("#tab-holidays .subtabs button").forEach(x => x.classList.toggle("on", x === b));
    $$("#tab-holidays .subpane").forEach(p => (p.hidden = p.id !== `set-${b.dataset.sub}`));
  }));
};

/* ---------- 共通 ---------- */
const api = async (url, opt = {}) => {
  const r = await fetch(url, { headers: opt.body && !(opt.body instanceof FormData) ? { "Content-Type": "application/json" } : {}, ...opt });
  const j = await r.json().catch(() => ({ ok: false, msg: `HTTP ${r.status}` }));
  return { status: r.status, ...j };
};
const post = (url, obj) => api(url, { method: "POST", body: JSON.stringify(obj) });
const msg = (text, ok = true) => Object.assign($("#msg"), { hidden: !text, textContent: text, className: ok ? "ok" : "err" });
const el = (tag, attrs = {}, ...kids) => {
  const svg = ["svg", "g", "rect", "line", "text", "polyline", "polygon", "circle", "path", "title"].includes(tag);
  const e = svg ? document.createElementNS("http://www.w3.org/2000/svg", tag) : document.createElement(tag);
  Object.entries(attrs).filter(([, v]) => v !== undefined && v !== null && v !== false)
    .forEach(([k, v]) => (k === "text" ? (e.textContent = v) : k.startsWith("on") ? e.addEventListener(k.slice(2), v) : e.setAttribute(k, v)));
  kids.flat().filter(Boolean).forEach(k => e.append(k));
  return e;
};
/* ---------- タスクのファイル (1 ファイル = 1 タブ)。未保存・元に戻すはファイルごと ---------- */
const curFile = () => S.files.get(S.cur);
const dirtyFiles = () => [...S.files].filter(([, f]) => f.dirty).map(([n]) => n);
const openTasks = () => [...S.files.values()].flatMap(f => f.tasks);  // ガントの日付の範囲は開いている全ファイルで共通
const setDirty = (kind, on, file = S.cur) => {
  if (kind !== "tasks") return on ? S.dirty.add(kind) : S.dirty.delete(kind);
  const f = S.files.get(file);
  f && (f.dirty = on);
  dirtyFiles().length ? S.dirty.add("tasks") : S.dirty.delete("tasks");
};
const isDirty = kind => (kind === "tasks" ? !!curFile()?.dirty : S.dirty.has(kind));
const markDirty = kind => { setDirty(kind, true); updateDirty(); };
const updateDirty = () => {
  const d = $("#dirty"), label = k => (k === "tasks" ? `タスク（${dirtyFiles().join("・")}）` : KIND_JA[k]);
  d.className = S.dirty.size ? "unsaved" : "saved";
  d.textContent = S.dirty.size ? `未保存: ${[...S.dirty].map(label).join("・")}` : "保存済み";
  renderFileTabs();
  $$("#tabs button").forEach(b => b.classList.toggle("dirty", S.dirty.has(b.dataset.tab) || (b.dataset.tab === "gantt" && S.dirty.has("tasks"))));
};
const addUndo = (kind, rows, dirty) => {
  S.undo.push({ kind, rows, dirty, file: kind === "tasks" ? S.cur : null });
  S.undo.splice(0, Math.max(0, S.undo.length - 50));
};
const pushUndo = kind => addUndo(kind, JSON.stringify(S.data[kind]), isDirty(kind));
const undo = () => {
  const u = S.undo.pop();
  if (!u) return msg("元に戻す操作はありません", false);
  if (u.view) return TF.restoreView(u.view), msg(`表示の条件を 1 つ前に戻しました（残り ${S.undo.length}）`);  // 「初期状態に戻す」の取り消し
  u.file && u.file !== S.cur && switchFile(u.file);  // 別のファイルの操作ならそのタブに移ってから戻す
  S.data[u.kind] = JSON.parse(u.rows);
  u.file && (curFile().tasks = S.data.tasks);
  setDirty(u.kind, u.dirty, u.file || S.cur);
  updateDirty(); renderAll(); msg(`${u.file ? `タスク（${u.file}）` : KIND_JA[u.kind]} を 1 つ前に戻しました（残り ${S.undo.length}）`);
};

/* ---------- 検証 (サーバーと同じ規則) ---------- */
const codesOf = kind => new Set((S.data[kind] || []).map(r => r.code));
const isNum = (v, lo = -Infinity, hi = Infinity) => v !== "" && !isNaN(+v) && +v >= lo && +v <= hi;
const taskErrors = r => {
  const codes = { project: codesOf("projects"), category: codesOf("categories"), owner: codesOf("owners") };
  const d = Object.fromEntries(["plan_start", "plan_end", "actual_start", "actual_end"].map(c => [c, dn(r[c])]));
  return [
    ...["no", "project", "level1", "level3", "category", "owner", "plan_start", "plan_end"].filter(c => !r[c]).map(c => [c, "必須です"]),
    r.no && !/^[1-9]\d{0,8}$/.test(r.no) && ["no", "No. は 1 以上の整数"],
    ...["project", "category", "owner"].filter(c => r[c] && !codes[c].has(r[c])).map(c => [c, `マスタにないコード: ${r[c]}`]),
    ...Object.keys(d).filter(c => r[c] && d[c] === null).map(c => [c, "日付は YYYY-MM-DD"]),
    d.plan_start !== null && d.plan_end !== null && d.plan_end < d.plan_start && ["plan_end", "予定終了が予定開始より前"],
    d.actual_start !== null && d.actual_end !== null && d.actual_end < d.actual_start && ["actual_end", "実績終了が実績開始より前"],
    r.actual_end && !r.actual_start && ["actual_start", "実績終了があるのに実績開始が空"],
    r.progress !== "" && !isNum(r.progress, 0, 100) && ["progress", "進捗は 0〜100 の数値"],
    ...EFFORT_KEYS.filter(k => (r[k] ?? "") !== "" && toCents(r[k]) === null).map(k => [k, "0 以上の数値（小数 2 桁。3 桁目は四捨五入）"]),
  ].filter(Boolean);
};
/* ---------- 影響タスク (depends): 先行タスクの No.。同じファイルの中だけ・循環は禁止 (サーバーの dep_errors と同じ) ---------- */
const NO_RE = /^[1-9]\d{0,8}$/;
const depTokens = v => String(v ?? "").trim().split(/[\s,、，]+/).filter(Boolean);
/* g: Map(No. → 先行の No. の配列) → Map(循環に入る No. → その No. から始まる道筋 [12, 15, 20, 12]) */
const findCycles = g => {
  const state = new Map(), out = new Map();
  const visit = (n, stack) => {
    state.set(n, 1); stack.push(n);
    (g.get(n) || []).forEach(m => (state.get(m) === 1
      ? stack.slice(stack.indexOf(m)).forEach((k, _, ring) => out.has(k) || out.set(k, [...ring.slice(ring.indexOf(k)), ...ring.slice(0, ring.indexOf(k)), k]))
      : !state.has(m) && visit(m, stack)));
    stack.pop(); state.set(n, 2);
  };
  [...g.keys()].forEach(n => state.has(n) || visit(n, []));
  return out;
};
const depRowError = (r, nos) => {
  const toks = depTokens(r.depends), dup = [...new Set(toks.filter((x, i) => toks.indexOf(x) !== i))];
  return [[toks.every(x => NO_RE.test(x)), `影響タスクは No. の整数をカンマ区切りで（例 3, 5）: ${toks.filter(x => !/^\d+$/.test(x)).join(" ")}`],
    [!dup.length, `同じ No. が重複: ${dup.join(", ")}`], [!toks.includes(r.no), "自分自身の No. は指定できません"],
    [toks.every(x => nos.has(x)), `No. ${toks.filter(x => !nos.has(x)).join(", ")} はこのファイルにありません`]].find(([ok]) => !ok)?.[1] ?? null;
};
const depErrors = rows => {
  const nos = new Set(rows.map(r => r.no).filter(n => NO_RE.test(n || "")));
  const first = rows.map((r, i) => ({ i, r, m: depRowError(r, nos) }));
  const cyc = findCycles(new Map(first.filter(x => !x.m && nos.has(x.r.no)).map(({ r }) => [r.no, depTokens(r.depends).filter(x => nos.has(x))])));
  return first.filter(x => x.m || cyc.has(x.r.no)).map(({ i, r, m }) => ({ i, e: ["depends", m || `循環参照: ${cyc.get(r.no).join(" → ")}`] }));
};
/* 先行・後続の関係 (ガントの影響線・強調用) */
const depGraph = tasks => {
  const byNo = new Map(tasks.map((t, ti) => [t.no, ti]).filter(([n]) => n));
  const preds = tasks.map((t, ti) => depTokens(t.depends).map(n => byNo.get(n)).filter(p => p !== undefined && p !== ti));
  const succs = preds.reduce((m, ps, ti) => (ps.forEach(p => m[p].push(ti)), m), tasks.map(() => []));
  return { byNo, preds, succs };
};
const depTip = (r, tasks = S.data.tasks) => {
  const byNo = new Map(tasks.map(t => [t.no, t]));
  const lines = depTokens(r.depends).map(n => (byNo.has(n) ? `No.${n} ${byNo.get(n).level3}（予定終了 ${fmtDate(byNo.get(n).plan_end)}）` : `No.${n}（このファイルにありません）`));
  return lines.length ? `影響タスク（先に終わらせるタスク）:\n${lines.join("\n")}` : "先に終わらせるタスクの No.（カンマ区切り、例 3, 5）";
};
/* No. を変えたとき: その No. を影響タスクに書いている行も直すか聞く */
const renumberRefs = (rows, oldNo, newNo) => {
  const refs = rows.filter(r => depTokens(r.depends).includes(oldNo));
  if (!refs.length || !NO_RE.test(oldNo) || !NO_RE.test(newNo) || oldNo === newNo) return 0;
  if (!confirm(`No. ${oldNo} → ${newNo}：参照している ${refs.length} 件の影響タスクも更新しますか`)) return 0;
  refs.forEach(r => (r.depends = depTokens(r.depends).map(x => (x === oldNo ? newNo : x)).join(", ")));
  return refs.length;
};
/* 追加列の検証 (列定義の型・必須・min/max/regex。サーバーの value_error と同じ) */
const TYPE_RE = /^(text|date|int|percent|number|bool|code:[a-z][a-z0-9_]{0,30}|select:[^/]+(\/[^/]+)*)$/;
const RESERVED_KINDS = ["tasks", "holidays", "columns", "settings", "presets", "backup", "params"];
const parseRule = v => {
  const out = {};
  let rest = (v || "").trim();
  while (rest) {
    if (rest.startsWith("regex=")) { new RegExp(rest.slice(6)); return { ...out, regex: rest.slice(6) }; }
    const [tok, ...more] = rest.split(";"), [k, val] = tok.split("=").map(x => x?.trim());
    if (!["min", "max"].includes(k) || !isNum(val ?? "")) throw new Error(`検証の書式が違います: ${tok}（例 min=0;max=100;regex=^A）`);
    out[k] = +val; rest = more.join(";").trim();
  }
  return out;
};
const safeRule = v => { try { return parseRule(v); } catch { return {}; } };
const TYPE_OK = { date: v => dn(v) !== null, int: v => /^-?\d+$/.test(v), number: v => isNum(v), percent: v => isNum(v, 0, 100),
  bool: v => ["1", "0", "-1", "true", "false", "yes", "no", "はい", "いいえ"].includes(v.toLowerCase()) };  // -1 = Access の Yes
const TYPE_MSG = { date: "日付は YYYY-MM-DD", int: "整数で入力", number: "数値で入力", percent: "0〜100 の数値", bool: "はい/いいえ (1/0)" };
const valueError = (c, v) => {
  if (!v) return c.required === "yes" ? "必須です" : null;
  if (TYPE_OK[c.type] && !TYPE_OK[c.type](v)) return TYPE_MSG[c.type];
  if (c.type.startsWith("code:") && !codesOf(c.type.slice(5)).has(v)) return `マスタにないコード: ${v}`;
  if (c.type.startsWith("select:") && !c.type.slice(7).split("/").includes(v)) return `選択肢にない値: ${v}（${c.type.slice(7)}）`;
  const rule = safeRule(c.validation), n = ["int", "number", "percent"].includes(c.type) && isNum(v) ? +v : [...v].length;
  return [["min" in rule && n < rule.min, `${rule.min} 以上にしてください`], ["max" in rule && n > rule.max, `${rule.max} 以下にしてください`],
    ["regex" in rule && !new RegExp(rule.regex).test(v), `書式が違います（${rule.regex}）`]].find(([bad]) => bad)?.[1] ?? null;
};
const GENERIC_CORE = ["priority", "importance", "calendar"];
const isCalDay = t => t?.calendar === "暦日";  // 稼働カレンダー = 暦日 (休日も数える)  // コア列だが値の検証は追加列と同じ (値は任意)
const extraCols = () => (S.data.columns || []).filter(c => (!S.coreKeys.includes(c.key) || GENERIC_CORE.includes(c.key)) && c.type !== "calc")
  .map(c => (S.coreKeys.includes(c.key) ? { ...c, required: "no" } : c));
const extraErrors = r => extraCols().map(c => [c.key, valueError(c, String(r[c.key] ?? ""))]).filter(([, m]) => m);
const isCore = r => S.coreKeys.includes(r.key) || (S.calcKeys || []).includes(r.key);  // 計算列も消せない・キー/型は変えられない
const isCalcCol = r => (S.calcKeys || []).includes(r.key);
const columnErrors = r => {
  const core = isCore(r) && S.coreTypes[r.key];
  const bad = () => { try { parseRule(r.validation); return null; } catch (e) { return e.message; } };
  return [
    !/^[^,"\r\n]{1,40}$/.test(r.key) && ["key", "キーは 1〜40 文字（, \" 改行は不可）"],
    !r.label && ["label", "必須です"],
    !TYPE_RE.test(r.type) && !(isCalcCol(r) && r.type === "calc") && ["type", "型は text / int / number / percent / bool / date / code:マスタ名 / select:高/中/低"],
    isCalcCol(r) && r.type !== "calc" && ["type", "計算列の型は変更できません（calc）"],
    !isCalcCol(r) && r.type === "calc" && ["type", "型 calc は計算列（システム）だけが使えます"],
    r.type.startsWith("code:") && RESERVED_KINDS.includes(r.type.slice(5)) && ["type", "そのマスタ名は使えません"],
    core && r.type !== core && ["type", `コア列の型は変更できません（${core}）`],
    core && r.required !== "yes" && ["required", "コア列は必須から外せません"],
    !["yes", "no"].includes(r.required) && ["required", "yes か no"],
    !["yes", "no"].includes(r.visible) && ["visible", "yes か no"],
    r.width && !(/^\d+$/.test(r.width) && +r.width >= 30 && +r.width <= 600) && ["width", "幅は 30〜600 の整数"],
    r.order !== "" && !isNum(r.order) && ["order", "並び順は数値"],
    bad() && ["validation", bad()],
    !["none", "inside", "right", "left", "below", "above"].includes(r.bar_pos) && ["bar_pos", "バー表示位置を選んでください"],
    !["yes", "no", "", undefined].includes(r.bar_title) && ["bar_title", "yes か no"],
    !/^[^,"\r\n]{0,10}$/.test(r.bar_short ?? "") && ["bar_short", "短縮名は 10 文字まで（, \" 改行は不可）"],
    r.bar_order && !isNum(r.bar_order) && ["bar_order", "数値"],
    r.bar_max && !(/^\d+$/.test(r.bar_max) && +r.bar_max >= 1 && +r.bar_max <= 200) && ["bar_max", "1〜200 の整数"],
  ].filter(Boolean);
};
const dupErrors = (rows, col, label) => rows.map((r, i) => [r, i, rows.findIndex(x => x[col] === r[col])])
  .filter(([r, i, f]) => r[col] && f !== i).map(([, i, f]) => ({ i, e: [col, `${label}が重複（${f + 1} 行目）`] }));
const masterErrors = r => [
  !/^[A-Za-z0-9_-]{1,20}$/.test(r.code) && ["code", "コードは英数字・_・-（20 文字まで）"],
  !r.name && ["name", "必須です"],
  r.color && !/^#[0-9a-fA-F]{6}$/.test(r.color) && ["color", "色は #rrggbb"],
  r.order !== "" && !isNum(r.order) && ["order", "並び順は数値"],
].filter(Boolean);
const holidayErrors = r => [
  dn(r.date) === null && ["date", "日付は YYYY-MM-DD"],
  !["祝日", "会社休日", "出勤日"].includes(r.type) && ["type", "種類は 祝日 / 会社休日 / 出勤日"],
].filter(Boolean);
const errorsOf = kind => {
  const rows = S.data[kind];
  const per = { tasks: r => [...taskErrors(r), ...extraErrors(r)], holidays: holidayErrors, columns: columnErrors }[kind] || masterErrors;
  const [dcol, dlabel] = { holidays: ["date", "日付"], columns: ["key", "キー"] }[kind] || ["code", "コード"];
  const dup = kind === "tasks" ? [...dupErrors(rows, "no", "No. "), ...depErrors(rows)] : dupErrors(rows, dcol, dlabel);
  return [...rows.flatMap((r, i) => per(r).map(e => ({ i, e }))), ...dup];
};

/* ---------- 表 (グリッド) ---------- */
const byOrder = rows => [...(rows || [])].sort((a, b) => (+a.order || 0) - (+b.order || 0));
const opts = kind => () => byOrder(S.data[kind]).map(r => [r.code, `${r.code} ${r.name}`]);  // マスタの並び順
/* タスクの列は列定義 (S.data.columns) から作る。コア列 → 追加列 → CSV にだけある列 → 計算列 */
const editorOf = type => (type.startsWith("code:") ? { t: "select", o: opts(type.slice(5)) }
  : type.startsWith("select:") ? { t: "select", o: () => type.slice(7).split("/").map(v => [v, v]) }
  : type === "bool" ? { t: "select", o: () => [["1", "はい"], ["0", "いいえ"]] }
  : type === "date" ? { t: "date" } : ["int", "number", "percent"].includes(type) ? { t: "number" } : {});
const schemaCols = () => [...(S.data.columns || [])].sort((a, b) => (+a.order || 0) - (+b.order || 0));
const csvOnlyKeys = () => {
  const known = new Set((S.data.columns || []).map(c => c.key));
  return [...new Set((S.data.tasks || []).flatMap(Object.keys))].filter(k => !known.has(k) && k !== "_rid");
};
const CALC_COLS = [
    { id: "pw", h: "稼働(予)", calc: r => { const [a, b] = [dn(r.plan_start), dn(r.plan_end)]; return a !== null && b >= a ? `${S.cal.ndays(r, a, b)}${isCalDay(r) ? " 暦" : ""}` : ""; } },
    { id: "cd", h: "暦日(予)", calc: r => { const [a, b] = [dn(r.plan_start), dn(r.plan_end)]; return a !== null && b >= a ? b - a + 1 : ""; } },
];
/* 計算列 (列定義の type calc): 表では読み取りだけ。予定の 2 つは参考値 (灰色・斜体) */
const calcSpec = c => ({ id: c.key, h: c.label || c.key, w: +c.width || undefined, type: "num", calcCol: true, cls: `num${c.key.startsWith("plan_") ? " ref" : ""}`,
  tip: EFFORT_TIP[c.key]?.(), calc: r => effText(r, c.key) });
const buildTaskSpec = () => [
  ...schemaCols().filter((c, i, all) => c.key && c.visible !== "no" && all.findIndex(x => x.key === c.key) === i)
    .map(c => (c.type === "calc" ? calcSpec(c) : { k: c.key, h: c.label || c.key, w: +c.width || undefined, type: c.type, ...editorOf(c.type), ...(EFFORT_KEYS.includes(c.key) ? { t: "dec2" } : {}) })),
  ...csvOnlyKeys().map(k => ({ k, h: k, w: 110, type: "text", csvOnly: true })),
  ...CALC_COLS.map(c => ({ ...c, type: "num" })),
];
const YN = () => [["yes", "はい"], ["no", "いいえ"]];
const TYPES = ["text", "int", "number", "percent", "bool", "date", "code:projects", "code:categories", "code:owners", "select:高/中/低"];
/* ---------- 表の見た目: 列の並び (ドラッグ) と左の固定。settings.json に保存。CSV の列順には使わない ---------- */
const colKey = c => c.k || c.id;
const viewOrder = () => (S.settings.grid_col_order || "").split(",").filter(Boolean);
const applyViewOrder = spec => {
  const order = viewOrder(), rank = c => (order.includes(colKey(c)) ? order.indexOf(colKey(c)) : order.length + spec.indexOf(c));
  return [...spec].sort((a, b) => rank(a) - rank(b));  // 並びを保存した後に増えた列は後ろへ
};
const viewHidden = () => (S.settings.grid_hidden || "").split(",").filter(Boolean);  // 表で隠した列 (表示だけ)
const frozenN = () => clamp(+S.settings.grid_frozen || 0, 0, SPECS.tasks.length);
const saveView = async patch => {
  Object.assign(S.settings, patch);
  S.taskSpec = null; renderGrid("tasks");
  hiddenBtn(); typeof TF !== "undefined" && TF.presetState();
  const r = await post("/api/settings", { grid_col_order: S.settings.grid_col_order || "", grid_frozen: S.settings.grid_frozen || "0", grid_hidden: S.settings.grid_hidden || "" });
  r.ok || msg("表示設定を保存できませんでした", false);
};
const moveColumn = (from, to, after) => {
  const ids = SPECS.tasksAll.map(colKey).filter(id => id !== from), at = ids.indexOf(to) + (after ? 1 : 0);
  saveView({ grid_col_order: [...ids.slice(0, at), from, ...ids.slice(at)].join(",") });
  msg("列の並びを変えました（表示だけ。CSV の列の順番は変わりません）");
};
const freezeTo = id => saveView({ grid_frozen: String(SPECS.tasks.findIndex(c => colKey(c) === id) + 1) });
const unfreeze = () => saveView({ grid_frozen: "0" });
const resetColumns = () => saveView({ grid_col_order: "" });
const hideColumn = id => (SPECS.tasks.length > 1 ? saveView({ grid_hidden: [...new Set([...viewHidden(), id])].join(","), grid_frozen: "0" }) : msg("最後の列は隠せません", false));
const showAllColumns = () => saveView({ grid_hidden: "" });
const hiddenBtn = () => {  // 「隠した列を表示 (N)」: 隠した列があるときだけ
  const b = $("#btn-show-cols"), names = viewHidden().map(id => SPECS.tasksAll.find(c => colKey(c) === id)?.h || id);
  b && Object.assign(b, { hidden: !names.length, textContent: `隠した列を表示（${names.length}）`, title: names.join("、") });
};
/* 左から N 列 (＋行番号) を横スクロールで固定。幅は描いた後に測る */
const applyFreeze = tbl => {
  const lead = $$("thead th", tbl).length - SPECS.tasks.length, n = frozenN() ? lead + frozenN() : 0;
  const lefts = $$("thead th", tbl).slice(0, n).reduce((xs, th) => [...xs, xs[xs.length - 1] + th.offsetWidth], [0]);
  $$("tr", tbl).forEach(tr => [...tr.children].forEach((td, j) => {
    const on = j < n;
    td.classList.toggle("frz", on); td.classList.toggle("frz-edge", on && j === n - 1);
    td.style.left = on ? `${lefts[j]}px` : "";
  }));
};
const SPECS = {
  get tasksAll() { return (S.taskSpec ||= applyViewOrder(buildTaskSpec())); },  // 隠した列も含む (フィルター・並べ替えはこちら)
  get tasks() { const h = viewHidden(); return this.tasksAll.filter(c => !h.includes(colKey(c))); },
  columns: [{ k: "key", h: "キー", w: 110, ro: isCore }, { k: "label", h: "表示名", w: 120 }, { k: "type", h: "型", w: 150, ro: isCore, list: "type-list" },
    { k: "required", h: "必須", t: "select", o: YN, w: 70, ro: isCore }, { k: "width", h: "幅", t: "number", w: 60 },
    { k: "visible", h: "表に表示", t: "select", o: YN, w: 70 }, { k: "order", h: "並び順", t: "number", w: 60 },
    { k: "default", h: "既定値", w: 80, ro: isCore }, { k: "validation", h: "検証 (min/max/regex)", w: 170, ro: isCore },
    { k: "bar_pos", h: "バー表示位置", t: "select", o: () => Object.entries(Gantt.BAR_POS_JA), w: 100 },
    { k: "bar_order", h: "バー内の順", t: "number", w: 60 }, { k: "bar_max", h: "最大文字数", t: "number", w: 60 },
    { k: "bar_title", h: "ラベル表示", t: "select", o: () => [["yes", "見出しあり"], ["no", "値だけ"]], w: 90 }, { k: "bar_short", h: "短縮名", w: 70 },
    { h: "種別", calc: r => (isCalcCol(r) ? "計算列（保存されない・削除不可）" : isCore(r) ? "コア列（削除不可）" : "追加列") }],
  categories: null, projects: null,
  owners: [{ k: "code", h: "コード", w: 80 }, { k: "name", h: "名前", w: 140 }, { k: "dept", h: "部署", w: 140 },
    { k: "color", h: "色", t: "color" }, { k: "order", h: "並び順", t: "number", w: 70 }, { h: "使用数", calc: (r) => S.usage.owners?.[r.code] ?? 0 }],
  holidays: [{ k: "date", h: "日付", t: "date" }, { h: "曜日", calc: r => (dn(r.date) === null ? "" : WK_JA[wday(dn(r.date))]) },
    { k: "name", h: "名前", w: 220 }, { k: "type", h: "種類", t: "select", o: () => ["祝日", "会社休日", "出勤日"].map(v => [v, v]), w: 100 }],
};
const masterSpec = kind => [{ k: "code", h: "コード", w: 80 }, { k: "name", h: "名前", w: 180 }, { k: "color", h: "色", t: "color" },
  { k: "order", h: "並び順", t: "number", w: 70 }, { h: "使用数", calc: r => S.usage[kind]?.[r.code] ?? 0 }];
SPECS.categories = masterSpec("categories");
SPECS.projects = masterSpec("projects");
const emptyRow = kind => (kind === "tasks"
  ? Object.fromEntries([...schemaCols().filter(c => S.savedKeys.has(c.key)).map(c => [c.key, c.default || ""]), ...csvOnlyKeys().map(k => [k, ""])])
  : kind === "columns" ? { key: "", label: "", type: "text", required: "no", width: "", visible: "yes",
    order: String(Math.max(0, ...S.data.columns.map(c => +c.order || 0)) + 1), default: "", validation: "", bar_pos: "none", bar_order: "", bar_max: "", bar_title: "yes", bar_short: "" }
  : Object.fromEntries(SPECS[kind].filter(c => c.k).map(c => [c.k, c.k === "type" ? "会社休日" : ""])));

const usageLive = kind => openTasks().flatMap(t => masterUses(kind).map(k => t[k]).filter(Boolean))
  .reduce((m, code) => ({ ...m, [code]: (m[code] || 0) + 1 }), {});

const visibleRows = kind => {
  return kind === "tasks" ? TF.apply(S.data.tasks) : S.data[kind];  // タスクは列ごとのフィルター・並べ替えを反映
};

const cellInput = (kind, row, c) => {
  const common = { "data-k": c.k, style: c.w ? `width:${c.w}px` : undefined, disabled: c.ro?.(row) ? "disabled" : null,
    title: c.ro?.(row) ? "コア列は変更できません" : kind === "tasks" && c.k === "depends" ? depTip(row) : undefined };
  if (c.t === "select") {
    const list = c.o();
    const extra = row[c.k] && !list.some(([v]) => v === row[c.k]) ? [[row[c.k], `⚠ ${row[c.k]}`]] : [];
    const s = el("select", common, el("option", { value: "", text: "" }), ...[...list, ...extra].map(([v, t]) => el("option", { value: v, text: t })));
    s.value = row[c.k] ?? "";
    return s;
  }
  if (c.t === "dec2")  // 工数・単価: 右寄せ、2 桁 (1,234.50)。入力は 1234.5・1,234.5 も可、確定で 2 桁に四捨五入
    return el("input", { ...common, class: "num", inputmode: "decimal", "data-dec": "1", title: common.title || EFFORT_TIP[c.k]?.(), value: toCents(row[c.k]) === null ? row[c.k] ?? "" : fmtCents(toCents(row[c.k])) });
  const inp = el("input", { ...common, "data-date": c.t === "date" ? "1" : null, placeholder: c.t === "date" ? "yyyy/mm/dd" : null,
    style: c.t === "date" ? "width:92px" : common.style, type: c.t === "color" ? "color" : c.t === "number" ? "number" : "text",
    min: c.t === "number" && c.k === "progress" ? 0 : undefined, max: c.k === "progress" ? 100 : undefined,
    step: c.k === "progress" ? 5 : c.t === "number" ? "any" : undefined, list: c.list });
  inp.value = c.t === "color" ? row[c.k] || "#888888" : c.t === "date" ? fmtDate(row[c.k]) : row[c.k] ?? "";
  return inp;
};

const renderGrid = kind => {
  const tbl = $(`#grid-${kind}`), spec = SPECS[kind], rows = visibleRows(kind);
  kind === "tasks" && ($("#btn-export-tasks").href = `/api/export/tasks?file=${enc(S.cur)}${$("#exp-calc")?.checked ? "&calc=1" : ""}`);
  const errs = errorsOf(kind), errMap = new Map(errs.map(({ i, e: [c, m] }) => [`${i}:${c}`, m]));
  const idx = new Map(S.data[kind].map((r, i) => [r, i]));
  const locked = kind === "tasks" && TF.active();  // 並べ替え・フィルター中は行の移動をしない
  const fixed = ROWS_FIXED.has(kind);
  const head = el("tr", {}, !fixed && el("th", { class: "ro" }), el("th", { class: "ro", text: "#" }),
    ...spec.map((c, j) => kind === "tasks" ? TF.th(c, j) : el("th", { class: c.k ? "" : "ro", "data-j": j, text: c.h + (S.sort[kind]?.k === c.k && c.k ? (S.sort[kind].dir > 0 ? " ▲" : " ▼") : "") })),
    !fixed && el("th", { class: "ro" }));
  const body = rows.map(r => {
    const i = idx.get(r), used = isMaster(kind) ? S.usage[kind]?.[r.code] || 0 : 0;
    const lock = used ? `タスク ${used} 件で使用中のため削除できません` : kind === "columns" && isCore(r) ? "コア列は削除できません" : "";
    return el("tr", { "data-i": i, draggable: "false" },
      !fixed && el("td", { class: locked ? "handle off" : "handle", title: locked ? "並べ替え・フィルター中は移動できません" : "ドラッグで移動", text: "⋮⋮" }), el("td", { class: "calc", text: i + 1 }),
      ...spec.map(c => (c.k ? el("td", { class: errMap.has(`${i}:${c.k}`) ? "err" : "", title: errMap.get(`${i}:${c.k}`) }, cellInput(kind, r, c))
        : el("td", { class: `calc ${c.cls || ""}`, title: c.tip, text: c.calc(r) }))),
      !fixed && el("td", { class: "act" }, el("button", { "data-up": i, disabled: locked ? "disabled" : null, title: "上へ", text: "↑" }),
        el("button", { "data-down": i, disabled: locked ? "disabled" : null, title: "下へ", text: "↓" }),
        lock && kind === "columns" ? el("span", { class: "muted core-lock", title: lock, text: "🔒" })
          : el("button", { "data-del": i, disabled: lock ? "disabled" : null, title: lock || "行を削除", text: "削除" })));
  });
  tbl.replaceChildren(el("thead", {}, head), el("tbody", {}, body));
  kind === "tasks" && updateTaskBar(rows.length, errs.length);
  kind === "tasks" && applyFreeze(tbl);
  kind === "columns" && renderCsvOnly();
};

const refreshErrors = kind => {
  const errMap = new Map(errorsOf(kind).map(({ i, e: [c, m] }) => [`${i}:${c}`, m]));
  $$(`#grid-${kind} tbody tr`).forEach(tr => $$("td", tr).filter(td => td.firstChild?.dataset?.k).forEach(td => {
    const m = errMap.get(`${tr.dataset.i}:${td.firstChild.dataset.k}`);
    td.classList.toggle("err", !!m); m ? (td.title = m) : td.removeAttribute("title");  // 固定列の class は残す
  }));
  kind === "tasks" && updateTaskBar(visibleRows("tasks").length, errMap.size);
};
const updateTaskBar = (n, nerr) => {
  $("#task-count").textContent = `${n} / ${S.data.tasks.length} 件表示　エラー ${nerr} 件`;
  $("#btn-clear-filter").disabled = !Object.keys(TF.F.filters).length;
  $("#btn-clear-sort").disabled = TF.F.sortDefault;
  TF.renderChips();
};

const editKind = (kind, fn) => { pushUndo(kind); fn(S.data[kind]); markDirty(kind); renderAll(); };
const bindGrid = kind => {
  const tbl = $(`#grid-${kind}`);
  tbl.addEventListener("focusin", e => {
    if (!e.target.dataset.k) return;
    e.target._before = JSON.stringify(S.data[kind]);
    e.target._old = S.data[kind][+e.target.closest("tr")?.dataset.i]?.[e.target.dataset.k];  // No. の付け替え用
  });
  tbl.addEventListener("input", e => {
    const k = e.target.dataset.k, i = +e.target.closest("tr")?.dataset.i;
    if (!k) return;
    if (e.target._before) { addUndo(kind, e.target._before, isDirty(kind)); e.target._before = null; }
    const row = S.data[kind][i];
    kind === "tasks" && TF.pin(row);  // 編集中の行は条件から外れても表示したまま
    row[k] = e.target.dataset.date ? normDate(e.target.value, row[k]) : e.target.value.trim();
    markDirty(kind); refreshErrors(kind);
    k === "depends" && (e.target.title = depTip(row));
    const calcs = $$("td.calc", e.target.closest("tr")).slice(1);  // 先頭の td.calc は行番号
    SPECS[kind].filter(c => c.calc).forEach((c, j) => calcs[j] && (calcs[j].textContent = c.calc(S.data[kind][i])));
  });
  tbl.addEventListener("change", e => {
    const i = +e.target.closest("tr")?.dataset.i;
    e.target.dataset.date && (e.target.value = fmtDate(S.data[kind][i][e.target.dataset.k]));  // 入力を yyyy/mm/dd にそろえる
    if (e.target.dataset.dec) {  // 工数・単価: 保存の形 (1234.50) にして、表示は 1,234.50
      const row = S.data[kind][i], k = e.target.dataset.k;
      row[k] = dec2(row[k]); e.target.value = toCents(row[k]) === null ? row[k] : fmtCents(toCents(row[k]));
      refreshErrors(kind); renderSoon();
    }
    if (kind === "tasks" && e.target.dataset.k === "no" && renumberRefs(S.data.tasks, e.target._old, S.data.tasks[i].no)) {
      e.target._old = S.data.tasks[i].no; markDirty("tasks"); return renderSoon();
    }
    (kind !== "tasks" || e.target.tagName === "SELECT") && renderSoon();
  });
  tbl.addEventListener("click", e => {
    const b = e.target.closest("button"), th = e.target.closest("th[data-j]");
    if (th && kind === "tasks" && Date.now() - (S.colDragJustEnded || 0) < 300) return;  // 列ドラッグの直後
    if (th && kind === "tasks") return e.target.closest(".fbtn") ? TF.open(th.dataset.col, e.target.closest(".fbtn")) : TF.toggleSort(th.dataset.col);
    if (th) return sortBy(kind, SPECS[kind][+th.dataset.j].k);
    if (!b || ROWS_FIXED.has(kind)) return;  // タスクは行の操作なし
    const [up, down, del] = ["up", "down", "del"].map(a => b.dataset[a]);
    if (del !== undefined) editKind(kind, rows => rows.splice(+del, 1));
    if (up !== undefined && +up > 0) editKind(kind, rows => rows.splice(+up - 1, 0, ...rows.splice(+up, 1)));
    if (down !== undefined && +down < S.data[kind].length - 1) editKind(kind, rows => rows.splice(+down + 1, 0, ...rows.splice(+down, 1)));
  });
  !ROWS_FIXED.has(kind) && bindRowDrag(kind, tbl);
  kind === "tasks" && bindColumnDrag(tbl);
  tbl.addEventListener("paste", e => pasteInto(kind, e));
  bindCellTip(tbl);
};
/* エラーのあるセル: ポインターを載せる・フォーカスするとエラーの文を赤い札で見せる (title はタッチでは見えないため) */
const bindCellTip = tbl => {
  const tip = () => $("#cell-tip") || document.body.appendChild(el("div", { id: "cell-tip", hidden: "hidden" }));
  const show = td => {
    if (!td?.classList.contains("err") || !td.title) return (tip().hidden = true);
    const r = td.getBoundingClientRect();
    Object.assign(tip(), { hidden: false, textContent: td.title }).style.cssText = `left:${Math.max(8, Math.min(r.left, innerWidth - 430))}px;top:${r.bottom + 3}px`;
  };
  tbl.addEventListener("pointerover", e => show(e.target.closest("td")));
  tbl.addEventListener("focusin", e => show(e.target.closest("td")));
  tbl.addEventListener("input", e => setTimeout(() => show(e.target.closest("td")), 0));
  ["pointerleave", "focusout"].forEach(t => tbl.addEventListener(t, () => (tip().hidden = true)));
};
/* 見出しのドラッグで列を並べ替え (マウス・タッチ。6px 動かすまではクリック＝並べ替え) */
const bindColumnDrag = tbl => {
  let d = null;
  const thAt = e => document.elementFromPoint(e.clientX, e.clientY)?.closest?.("#grid-tasks th[data-col]");
  const mark = (th, after) => { $$("th.col-drop-l, th.col-drop-r", tbl).forEach(t => t.classList.remove("col-drop-l", "col-drop-r")); th?.classList.add(after ? "col-drop-r" : "col-drop-l"); };
  tbl.addEventListener("pointerdown", e => {
    const th = e.target.closest("th[data-col]");
    if (!th || e.target.closest(".fbtn") || e.button > 0) return;
    d = { id: th.dataset.col, x: e.clientX, y: e.clientY, on: false, pid: e.pointerId };
  });
  tbl.addEventListener("pointermove", e => {
    if (!d) return;
    if (!d.on && Math.hypot(e.clientX - d.x, e.clientY - d.y) < 6) return;
    if (!d.on) { d.on = true; try { tbl.setPointerCapture(d.pid); } catch { /* 合成イベントなど */ } tbl.querySelector(`th[data-col="${CSS.escape(d.id)}"]`)?.classList.add("col-dragging"); }
    const th = thAt(e), r = th?.getBoundingClientRect();
    d.to = th?.dataset.col; d.after = r && e.clientX > r.left + r.width / 2;
    mark(th && th.dataset.col !== d.id ? th : null, d.after);
  });
  const end = e => {
    const g = d; d = null;
    if (!g?.on) return;
    g.suppress = true; S.colDragJustEnded = Date.now();  // 直後の click (並べ替え) を無視
    mark(null); $$("th.col-dragging", tbl).forEach(t => t.classList.remove("col-dragging"));
    e.type === "pointerup" && g.to && g.to !== g.id && moveColumn(g.id, g.to, g.after);
  };
  tbl.addEventListener("pointerup", end);
  tbl.addEventListener("pointercancel", end);
  tbl.addEventListener("contextmenu", e => { const th = e.target.closest("th[data-col]"); th && (e.preventDefault(), openColMenu(th, e)); });
};
/* 見出しの右クリック (長押し) メニュー */
const openColMenu = (th, e) => {
  $("#col-menu")?.remove();
  const id = th.dataset.col, idx = SPECS.tasks.findIndex(c => colKey(c) === id), item = (text, fn, dis) =>
    el("button", { type: "button", text, disabled: dis ? "disabled" : null, onclick: () => { menu.remove(); fn(); } });
  const menu = el("div", { id: "col-menu", class: "fdrop colmenu" },
    item(`ここまで固定（左から ${idx + 1} 列）`, () => freezeTo(id)), item("固定解除", unfreeze, !frozenN()),
    item("列の並びを元に戻す", resetColumns, !viewOrder().length), item("この列を隠す（表示だけ）", () => hideColumn(id)));
  document.body.append(menu);
  Object.assign(menu.style, { left: `${clamp(e.clientX, 8, innerWidth - menu.offsetWidth - 8)}px`, top: `${clamp(e.clientY, 8, innerHeight - menu.offsetHeight - 8)}px` });
};
document.addEventListener("pointerdown", e => !e.target.closest?.("#col-menu") && $("#col-menu")?.remove(), true);
document.addEventListener("keydown", e => e.key === "Escape" && $("#col-menu")?.remove());
let renderTimer = 0;
const renderSoon = () => { clearTimeout(renderTimer); renderTimer = setTimeout(renderAll, 50); };

const sortBy = (kind, k) => {
  if (!k) return;
  const dir = S.sort[kind]?.k === k ? -S.sort[kind].dir : 1;
  S.sort[kind] = { k, dir };
  const key = v => (isNum(v) ? +v : v);
  editKind(kind, rows => rows.sort((a, b) => (key(a[k]) > key(b[k]) ? dir : key(a[k]) < key(b[k]) ? -dir : 0)));
};

const bindRowDrag = (kind, tbl) => {
  let from = null;
  tbl.addEventListener("pointerdown", e => { const td = e.target.closest("td.handle:not(.off)"); td && (td.parentElement.draggable = true); });
  tbl.addEventListener("dragstart", e => { from = +e.target.dataset.i; e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", ""); });
  tbl.addEventListener("dragover", e => {
    if (from === null) return;
    e.preventDefault();
    $$("tr.drop-before", tbl).forEach(t => t.classList.remove("drop-before"));
    e.target.closest("tbody tr")?.classList.add("drop-before");
  });
  tbl.addEventListener("drop", e => {
    e.preventDefault();
    const to = +e.target.closest("tbody tr")?.dataset.i;
    if (from !== null && !isNaN(to) && to !== from) editKind(kind, rows => rows.splice(to > from ? to - 1 : to, 0, ...rows.splice(from, 1)));
    from = null; renderAll();
  });
};

const pasteInto = (kind, e) => {
  const text = e.clipboardData.getData("text/plain");
  const inp = e.target;
  if (!inp.dataset?.k || !/[\t\n]/.test(text.trim())) return;
  e.preventDefault();
  const cols = SPECS[kind].filter(c => c.k).map(c => c.k), c0 = cols.indexOf(inp.dataset.k);
  const isDate = new Set(SPECS[kind].filter(c => c.t === "date").map(c => c.k));
  const lines = text.replace(/\r/g, "").replace(/\n$/, "").split("\n").map(l => l.split("\t"));
  const vis = visibleRows(kind), r0 = vis.indexOf(S.data[kind][+inp.closest("tr").dataset.i]);
  const fixed = ROWS_FIXED.has(kind), fit = fixed ? lines.slice(0, vis.length - r0) : lines;  // タスクは行を増やさない
  editKind(kind, rows => fit.forEach((cells, dr) => {
    const target = vis[r0 + dr] || rows[rows.push(emptyRow(kind)) - 1];
    kind === "tasks" && TF.pin(target);
    cells.forEach((v, dc) => { const k = cols[c0 + dc]; k && (target[k] = isDate.has(k) ? normDate(v, target[k]) : v.trim()); });
  }));
  const cut = lines.length - fit.length, ncol = Math.max(...lines.map(l => l.length));
  msg(`${fit.length} 行 × ${ncol} 列を貼り付けました` + (cut ? `。表示中の行が足りないため残り ${cut} 行は貼り付けていません（行は追加できません）` : ""), !cut);
};

const copyTSV = async () => {
  const cols = SPECS.tasks.filter(c => c.k).map(c => c.k);
  const tsv = [cols, ...visibleRows("tasks").map(r => cols.map(c => r[c]))].map(r => r.join("\t")).join("\n");
  await navigator.clipboard?.writeText(tsv).then(() => msg("表示中の行をコピーしました（Excel に貼り付けできます）"), () => msg("コピーできませんでした（ブラウザの許可が必要）", false));
};

/* ---------- 保存 ---------- */
const enc = encodeURIComponent;
const saveFile = async name => {
  const f = S.files.get(name);
  if (f.error) throw new Error(`${name}: ${f.error}`);
  const r = await post(`/api/save/tasks?file=${enc(name)}`, { rows: f.tasks, version: f.version });  // 版が違えば (Access から書き出し直された) 上書きしない
  if (r.stale) throw new Error(`タスク（${name}）: ${r.msg}`);
  r.ok && (f.version = r.version);
  const detail = (r.errors || []).slice(0, 8).map(e => (e.row >= 0 ? `${e.row + 1} 行目 ${e.col}: ` : "") + e.msg).join("\n");
  if (!r.ok) throw new Error(`タスク（${name}）: ${detail || r.msg}`);
  setDirty("tasks", false, name);
  return `${name} ${r.saved} 行`;
};
const saveKind = async kind => {
  if (kind === "tasks") return (await Promise.all(dirtyFiles().map(saveFile))).join("、");  // ファイルごとに保存 (バックアップもファイルごと)
  const r = await post(`/api/save/${kind}`, { rows: S.data[kind] });
  const detail = (r.errors || []).slice(0, 8).map(e => (e.row >= 0 ? `${e.row + 1} 行目 ${e.col}: ` : "") + e.msg).join("\n");
  if (!r.ok) throw new Error(`${KIND_JA[kind]}: ${detail || r.msg}`);
  S.dirty.delete(kind);
  return `${KIND_JA[kind]} ${r.saved} 行` + (r.added_to_tasks?.length ? `（タスク CSV に列 ${r.added_to_tasks.join("・")} を追加）` : "");
};
const saveAll = async () => {
  const kinds = KINDS.filter(k => S.dirty.has(k));
  const settingsChanged = S.dirty.has("settings");
  if (!kinds.length && !settingsChanged) return msg("変更はありません");
  try {
    const done = [];
    for (const k of kinds) done.push(await saveKind(k)); // 順番に保存 (マスタ → タスク)
    if (settingsChanged) { await post("/api/settings", S.settings); S.dirty.delete("settings"); done.push("設定"); }
    await reload(false);
    msg(`保存しました: ${done.join("、")}（バックアップ: data/backup/）`);
  } catch (err) { msg("保存できませんでした\n" + err.message, false); }
  updateDirty();
};

/* ---------- 休日タブ ---------- */
const renderWeekend = () => {
  const cur = new Set((S.settings.weekend || "sat,sun").split(","));
  $("#weekend").replaceChildren(...Object.keys(WK).map(w => el("label", {},
    el("input", { type: "checkbox", value: w, checked: cur.has(w) ? "checked" : null, onchange: () => {
      S.settings.weekend = $$("#weekend input:checked").map(i => i.value).join(",");
      S.dirty.add("settings"); updateDirty(); renderAll();
    } }), ` ${WK_JA[WK[w]]}`)));
};
let jpPreview = [];
const showJP = async () => {
  const r = await api(`/api/jpholidays?year=${+$("#jp-year").value}`);
  if (!r.ok) return msg(r.msg, false);
  jpPreview = r.holidays;
  const have = new Set(S.data.holidays.map(h => h.date));
  $("#jp-list").replaceChildren(...jpPreview.map(h => el("tr", {}, el("td", { text: h.date }), el("td", { text: WK_JA[wday(dn(h.date))] }),
    el("td", { text: h.name }), el("td", { class: "muted", text: have.has(h.date) ? "登録済み" : "" }))));
  $("#btn-jp-add").disabled = !jpPreview.length;
};
const addJP = () => {
  const have = new Set(S.data.holidays.map(h => h.date));
  const add = jpPreview.filter(h => !have.has(h.date));
  editKind("holidays", rows => rows.push(...add.map(h => ({ ...h }))));
  msg(`${add.length} 件追加しました（保存で CSV に書き込みます）`); showJP();
};

/* ---------- 出力タブ ---------- */
const fillForm = () => Object.entries(S.settings).forEach(([k, v]) => { const f = $(`#out-form [name=${k}]`); f && (f.value = v); });
const generate = async e => {
  e.preventDefault();
  if (S.dirty.has("tasks") || KINDS.some(k => S.dirty.has(k))) {
    if (!confirm("未保存の変更があります。保存してから作成しますか？")) return;
    await saveAll();
    if (S.dirty.size) return;
  }
  const form = Object.fromEntries(new FormData($("#out-form")));
  Object.assign(S.settings, form);
  $("#btn-gen").disabled = true; $("#gen-status").textContent = "作成中…（数秒〜数十秒）";
  const r = await post("/api/generate", { ...S.settings, today: form.today || S.today, file: $("#out-file").value });
  $("#btn-gen").disabled = false;
  $("#gen-status").textContent = r.ok ? `${r.file}: ${r.pngs.length} ページ作成しました` : "";
  $("#out-log").hidden = !r.log; $("#out-log").textContent = r.log || "";
  if (!r.ok) return msg((r.msg || "作成できませんでした") + (r.errors ? "\n" + r.errors.map(x => `${x.row + 1} 行目 ${x.col}: ${x.msg}`).join("\n") : ""), false);
  msg("");
  $("#out-links").replaceChildren(...[r.pdf && el("a", { class: "btn", href: `${r.pdf}?dl=1`, text: "PDF をダウンロード" }),
    el("a", { class: "btn", href: `${r.zip}?dl=1`, text: "PNG（ZIP）をダウンロード" }),
    r.pdf && el("a", { class: "btn", href: r.pdf, target: "_blank", text: "PDF を開く" })].filter(Boolean));
  $("#out-pages").replaceChildren(...r.pngs.map((u, k) => el("div", {}, el("div", { class: "muted", text: `ページ ${k + 1} / ${r.pngs.length}` }),
    el("img", { src: u, alt: `ページ ${k + 1}`, loading: "lazy" }))));
};

const fillOutFile = () => {
  const s = $("#out-file"), cur = s.value || S.settings.out_file || S.cur;
  s.replaceChildren(...S.fileList.map(f => el("option", { value: f.name, text: `${f.name}（${f.rows} 行）` })));
  s.value = S.fileList.some(f => f.name === cur) ? cur : S.cur;
};
/* ---------- 全体 ---------- */
const fillFilters = () => [["#g-project", "projects"]].forEach(([sel, kind]) => {
  const s = $(sel), cur = s.value;
  s.replaceChildren(el("option", { value: "", text: "（すべて）" }), ...S.data[kind].map(r => el("option", { value: r.code, text: `${r.code} ${r.name}` })));
  s.value = cur;
});
const renderNotices = () => {
  const items = [S.tasksError && ["err", S.tasksError + "　→ CSV を直接直してから再読み込みしてください（自動では直しません）"],
    ...S.notices.map(n => ["warn", `列定義を自動で修復しました: ${n}`])].filter(Boolean).filter(([, t]) => !S.closedNotices.has(t));
  const close = key => el("button", { class: "notice-x", title: "閉じる", text: "×", onclick: () => { S.closedNotices.add(key); renderNotices(); } });
  const migrate = S.migrateNotices.length && !S.closedNotices.has("migrate") &&  // 移行・見本作成はまとめて 1 つ
    el("div", { class: "notice info" }, el("div", {}, el("b", { text: "自動で更新しました（データはバックアップ済み）" }),
      el("ul", {}, ...S.migrateNotices.map(n => el("li", { text: n })))), close("migrate"));
  $("#notices").replaceChildren(...items.map(([cls, t]) => el("div", { class: `notice ${cls}` }, el("span", { text: t }), close(t))),
    ...[migrate].filter(Boolean));
};
const renderCsvOnly = () => {
  const keys = csvOnlyKeys();
  $("#csv-only").replaceChildren(...(keys.length ? [el("span", { text: "タスク CSV にあって列定義にない列（text として表示中）: " }),
    ...keys.map(k => el("button", { text: `「${k}」を列定義に追加`, onclick: () => editKind("columns", rows => rows.push({ ...emptyRow("columns"), key: k, label: k })) }))] : []));
};
const renderAll = () => {
  S.taskSpec = null;  // 列定義が変わったかもしれないので作り直す
  renderFileTabs();
  renderNotices();
  S.cal = calendar();
  S.usage = Object.fromEntries(MASTERS.map(k => [k, Object.entries(closedUsage(k)).reduce((m, [c, n]) => ({ ...m, [c]: (m[c] || 0) + n }), usageLive(k))]));
  fillFilters();
  KINDS.forEach(renderGrid);
  !$("#tab-gantt").hidden && window.Gantt?.render();
  hiddenBtn(); typeof TF !== "undefined" && S.presets && TF.presetState();  // バー表示 (列定義) などが変わったら「変更あり」を更新
  !$("#tab-compare").hidden && window.Compare?.render();
  fillOutFile();
};
const fetchFile = async name => {
  const r = await api(`/api/tasks?file=${enc(name)}`);
  return { tasks: r.tasks || [], error: r.error || (r.status === 404 ? "ファイルがありません" : ""), dirty: false, version: r.version || "" };
};
const loadFiles = async names => {
  const got = await Promise.all(names.map(async n => [n, await fetchFile(n)]));
  S.files = new Map(got);
};
const reload = async (all = true) => {
  const d = await api("/api/data");
  setupMasters(d.masters);
  KINDS.filter(k => k !== "tasks").forEach(k => (S.data[k] = d[k]));
  Object.assign(S, { jp: d.jp, today: d.today, coreKeys: d.core_keys, notices: d.schema_notices, migrateNotices: d.migrate_notices || [], presets: d.presets || {}, fileList: d.files });
  all && (S.settings = d.settings, TF.initRange(S.settings));
  $("#g-deps") && ($("#g-deps").checked = S.settings.gantt_deps !== "off");  // 影響線を表示 (共通条件)
  const known = new Set(d.files.map(f => f.name)), saved = (S.settings.open_files || "").split("\n").filter(n => known.has(n));
  const open = all ? (saved.length ? saved : d.files.slice(0, 1).map(f => f.name)) : [...S.files.keys()].filter(n => known.has(n));
  await loadFiles(open);
  all && TF.initTree(S.settings);  // ツリーの開閉 (共通条件): ファイルを読んでから、無い道筋を外す
  window.Compare?.invalidate();
  S.cur = S.files.has(S.cur) ? S.cur : S.files.has(S.settings.cur_file) ? S.settings.cur_file : open[0] || "";
  S.data.tasks = curFile()?.tasks || [];
  S.tasksError = curFile()?.error || "";
  Object.assign(S, { calcKeys: d.calc_keys || [], params: d.params || {}, paramDefs: d.param_defs || [] });
  S.coreTypes ||= Object.fromEntries(d.columns.filter(c => d.core_keys.includes(c.key)).map(c => [c.key, c.type]));
  S.savedKeys = new Set(d.columns.map(c => c.key));  // 新しい行に入れるのは保存済みの列だけ (入力途中のキーを混ぜない)
  if (all) { S.undo = []; S.dirty.clear(); }
  $("#jp-year").value ||= (S.settings.today || d.today).slice(0, 4);
  renderWeekend(); renderParams(); fillForm(); TF.fillPresets(); renderAll(); updateDirty();
};
/* マスタのタブ: 組み込み (カテゴリ・プロジェクト・担当者) 以外は列定義の code:<名前> から自動で作る */
const setupMasters = list => {
  MASTERS = list.map(m => m.kind);
  KINDS = ["columns", ...MASTERS, "holidays", "tasks"];
  list.forEach(m => { KIND_JA[m.kind] = m.label; });
  list.filter(m => !m.builtin && !$(`#tab-${m.kind}`)).forEach(m => {
    SPECS[m.kind] = masterSpec(m.kind);
    $("#tabs button[data-tab=holidays]").before(el("button", { "data-tab": m.kind, text: m.label }));
    const add = el("button", { text: "＋ 行を追加", onclick: () => editKind(m.kind, rows => rows.push(emptyRow(m.kind))) });
    const sort = el("button", { text: "並び順で整列", onclick: () => editKind(m.kind, rows => rows.sort((a, b) => (+a.order || 0) - (+b.order || 0))) });
    $("#tab-holidays").before(el("section", { id: `tab-${m.kind}`, class: "tab", hidden: "hidden" },
      el("div", { class: "toolbar" }, add, sort, el("a", { class: "btn", href: `/api/export/${m.kind}`, text: "CSV ダウンロード" })),
      el("p", { class: "hint", text: `マスタ ${m.kind}.csv（列定義の型 code:${m.kind} の列で使います）。タスクで使っているコードは削除できません。` }),
      el("div", { class: "grid-wrap" }, el("table", { class: "grid", id: `grid-${m.kind}` }))));
    S.data[m.kind] = [];
    bindGrid(m.kind);
  });
};
/* 閉じているファイルの使用数はサーバーの集計 (files[].usage)。開いているファイルは画面の値 (未保存を含む) で数える */
const closedUsage = kind => S.fileList.filter(f => !S.files.has(f.name)).reduce((m, f) =>
  Object.entries(f.usage?.[kind] || {}).reduce((a, [c, n]) => ({ ...a, [c]: (a[c] || 0) + n }), m), {});
const saveOpenTabs = () => {  // S.settings も更新 (出力などで設定をまとめて送っても古い値で上書きしない)
  Object.assign(S.settings, { open_files: [...S.files.keys()].join("\n"), cur_file: S.cur });
  return post("/api/settings", { open_files: S.settings.open_files, cur_file: S.cur });
};
const switchFile = name => {
  if (!S.files.has(name) || name === S.cur) return;
  S.cur = name; S.data.tasks = curFile().tasks; S.tasksError = curFile().error;
  TF.F.pinned.clear(); Gantt.G.sel = null;
  renderAll(); updateDirty(); saveOpenTabs();
};
const openFile = async name => {
  if (!name) return;
  S.files.has(name) || S.files.set(name, await fetchFile(name));
  S.cur = "";  // 切り替えを必ず行う
  switchFile(name);
};
const closeFile = name => {
  const f = S.files.get(name);
  if (f?.dirty && !confirm(`${name} に未保存の変更があります。閉じると変更は失われます（ファイルは消えません）。閉じますか？`)) return;
  S.files.delete(name);
  S.undo = S.undo.filter(u => u.file !== name);
  setDirty("tasks", false, name);
  name === S.cur && (S.cur = "", S.data.tasks = [], S.tasksError = "");
  S.files.size && !S.cur ? switchFile([...S.files.keys()][0]) : (renderAll(), updateDirty(), saveOpenTabs());
};
const refreshFileList = async () => { S.fileList = (await api("/api/files")).files || S.fileList; };
const uploadFile = async inp => {
  const fd = new FormData();
  fd.append("file", inp.files[0]);
  const r = await api("/api/files/upload", { method: "POST", body: fd });
  inp.value = "";
  if (!r.ok) return msg(`取り込めませんでした: ${r.msg}`, false);
  await refreshFileList(); await openFile(r.name);
  msg(`新しいファイル ${r.name}（${r.rows} 行）として取り込みました` + (r.renamed ? "（同じ名前のファイルがあるため名前を変えました。既存のファイルは上書きしていません）" : ""));
};
const copyFile = async () => {
  if (!S.cur) return;
  if (curFile().dirty && !confirm("未保存の変更は複製に含まれません（保存済みの内容を複製します）。続けますか？")) return;
  const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const name = prompt("新しいファイルの名前（.csv）", `${S.cur.replace(/\.csv$/, "")}_前回_${stamp}.csv`);
  if (!name) return;
  const r = await post("/api/files/copy", { src: S.cur, name: /\.csv$/i.test(name) ? name : `${name}.csv` });
  if (!r.ok) return msg(`複製できませんでした: ${r.msg}`, false);
  await refreshFileList(); await openFile(r.name);
  msg(`複製して ${r.name} を作りました（元のファイルはそのまま）`);
};
const renderFileTabs = () => $$(".file-tabs").forEach(box => {
  const closed = S.fileList.filter(f => !S.files.has(f.name));
  box.replaceChildren(
    ...[...S.files].map(([n, f]) => el("span", { class: `ftab${n === S.cur ? " active" : ""}${f.dirty ? " dirty" : ""}`, "data-file": n, title: n },
      el("button", { class: "ftab-name", text: n + (f.dirty ? " ●" : ""), onclick: () => switchFile(n) }),
      el("button", { class: "ftab-x", title: "タブを閉じる（ファイルは消えません）", text: "×", onclick: () => closeFile(n) }))),
    el("select", { class: "file-open", title: "data/tasks/ のファイルをタブで開く", onchange: e => openFile(e.target.value) },
      el("option", { value: "", text: closed.length ? "＋ ファイルを開く…" : "（ほかのファイルはありません）" }),
      ...closed.map(f => el("option", { value: f.name, text: `${f.name}（${f.rows} 行・${f.mtime}）` }))),
    el("label", { class: "btn", title: "CSV を新しいファイルとして data/tasks/ に取り込みます（既存のファイルは上書きしません）" }, "ファイルを取り込む",
      el("input", { type: "file", accept: ".csv,text/csv", hidden: "hidden", onchange: e => uploadFile(e.target) })),
    el("button", { title: "いまのファイルを丸ごと複製して新しいファイルにします（前回分の保存などに）", text: "複製して新しいファイル", onclick: copyFile, disabled: S.cur ? null : "disabled" }),
    el("span", { class: "shared-badge", title: "フィルター・並べ替え・列の並び・固定・ガントの表示・バー表示はすべてのファイルのタブで共通です", text: "共通条件" }));
});
const showTab = t => {
  $$("#tabs button").forEach(b => b.classList.toggle("active", b.dataset.tab === t));
  $$("section.tab").forEach(s => (s.hidden = s.id !== `tab-${t}`));
  location.hash = t;
  t === "gantt" && window.Gantt?.render(true);
  t === "compare" && window.Compare?.render();
};
const importCSV = async inp => {
  const kind = inp.dataset.import, fd = new FormData();
  fd.append("file", inp.files[0]);
  const r = await api(`/api/import/${kind}`, { method: "POST", body: fd });
  inp.value = "";
  if (!r.ok) return msg(r.msg, false);
  editKind(kind, rows => rows.splice(0, rows.length, ...r.rows));
  msg(`${r.rows.length} 行を読み込みました（エラー ${r.errors.length} 件）。「保存」で CSV に書き込みます`, !r.errors.length);
};

document.addEventListener("DOMContentLoaded", async () => {
  $("#tabs").addEventListener("click", e => e.target.dataset.tab && showTab(e.target.dataset.tab));
  $("#btn-save").addEventListener("click", saveAll);
  $("#btn-undo").addEventListener("click", undo);
  bindParams();
  $("#exp-calc").addEventListener("change", () => renderGrid("tasks"));
  $$("[data-add]").filter(b => !ROWS_FIXED.has(b.dataset.add)).forEach(b => b.addEventListener("click", () => editKind(b.dataset.add, rows => rows.push(emptyRow(b.dataset.add)))));
  $("#btn-clear-filter").addEventListener("click", () => TF.clearFilters());
  $("#btn-clear-sort").addEventListener("click", () => TF.clearSort());
  $$(".btn-reset-view").forEach(b => b.addEventListener("click", e => TF.openReset(e.currentTarget)));
  $$("[data-sort-order]").forEach(b => b.addEventListener("click", () => editKind(b.dataset.sortOrder, rows => rows.sort((a, c) => (+a.order || 0) - (+c.order || 0)))));
  $("#btn-hol-sort").addEventListener("click", () => editKind("holidays", rows => rows.sort((a, b) => a.date.localeCompare(b.date))));
  $$("[data-import]").filter(i => !ROWS_FIXED.has(i.dataset.import)).forEach(i => i.addEventListener("change", () => importCSV(i)));
  $("#btn-copy-tsv").addEventListener("click", copyTSV);
  $("#btn-jp").addEventListener("click", showJP);
  $("#btn-jp-add").addEventListener("click", addJP);
  $("#out-form").addEventListener("submit", generate);
  KINDS.forEach(bindGrid);
  document.addEventListener("keydown", e => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === "s") { e.preventDefault(); saveAll(); }
    if (mod && e.key.toLowerCase() === "z" && !["INPUT", "SELECT", "TEXTAREA"].includes(document.activeElement?.tagName)) { e.preventDefault(); undo(); }
  });
  window.addEventListener("beforeunload", e => S.dirty.size && (e.preventDefault(), (e.returnValue = "")));
  await reload();
  showTab(location.hash.slice(1) || "tasks");
});
