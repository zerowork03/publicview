"use strict";
/* 比較: 2 つのファイル (A=前回, B=今回) を同じ共通条件 (フィルター・プロジェクト・表示・日付の範囲) で見比べる。
   ガント (横並び / 上下、スクロール同期、前回の予定を破線で重ねる) と差分表 (No. で対応付け、無ければ階層で) */
window.Compare = (() => {
  const C = { a: "", b: "", cache: new Map(), pairs: [], ghost: new Map(), ga: null, gb: null, first: true };
  const ST_JA = { chg: "変更", add: "追加", del: "削除", same: "同じ" };
  const tasksOf = name => S.files.get(name)?.tasks ?? C.cache.get(name)?.tasks ?? [];  // 開いているファイルは画面の値 (未保存を含む)
  const load = async name => { name && !S.files.has(name) && !C.cache.has(name) && C.cache.set(name, await fetchFile(name)); };
  const pathKey = t => [t.project, t.level1, t.level2, t.level3].join("\u0001");
  const pname = code => S.data.projects.find(p => p.code === code)?.name || code;
  const pathText = t => [pname(t.project), t.level1, t.level2, t.level3].filter(Boolean).join(" ＞ ");

  /* ---------- 対応付け: まず No.、残りはプロジェクト＋大・中項目＋タスク名 ---------- */
  const match = (A, B) => {
    const used = new Set(), take = b => (b && !used.has(b) ? (used.add(b), b) : null);
    const firstBy = (rows, key) => rows.reduce((m, t) => (key(t) && !m.has(key(t)) ? m.set(key(t), t) : m), new Map());
    const noB = firstBy(B, t => t.no);
    const byNo = A.map(a => ({ a, b: take(a.no ? noB.get(a.no) : null), by: "No." }));
    const pathB = firstBy(B.filter(b => !used.has(b)), pathKey);
    const byPath = byNo.map(p => (p.b ? p : (b => ({ a: p.a, b, by: b ? "階層" : "" }))(take(pathB.get(pathKey(p.a))))));
    return [...byPath, ...B.filter(b => !used.has(b)).map(b => ({ a: null, b, by: "" }))];
  };
  const keys = () => [...new Set([...(S.data.columns || []).map(c => c.key), ...[...tasksOf(C.a), ...tasksOf(C.b)].flatMap(Object.keys)])].filter(k => k !== "_rid");
  const labelOf = k => S.data.columns.find(c => c.key === k)?.label || k;
  /* 比べる値: 工数・単価は数値として (8 と 8.00 は同じ)、計算列はその場で計算した値 */
  const valOf = (t, k) => (CALC_KEYS.includes(k) ? effText(t, k) : EFFORT_KEYS.includes(k) && toCents(t[k]) !== null ? fmtCents(toCents(t[k])) : t[k] ?? "");
  const fmt = (k, v) => {
    const c = S.data.columns.find(x => x.key === k);
    return !v ? "（空）" : c?.type === "date" ? fmtDate(v) : c?.type.startsWith("code:") ? `${v} ${S.data[c.type.slice(5)]?.find(m => m.code === v)?.name || ""}`.trim() : v;
  };
  /* 遅れ (日): 実績終了 (無ければ着手済みか予定終了を過ぎていれば今日) − 予定終了。早い分は 0 */
  const delayOf = t => {
    const pe = dn(t?.plan_end), tn = dn(S.settings.today || S.today), ae = dn(t?.actual_end), as = dn(t?.actual_start);
    if (!t || pe === null) return null;
    const end = ae ?? (as !== null || pe < tn ? tn : null);
    return end === null ? 0 : Math.max(0, end - pe);
  };
  const diffOf = p => {
    const changed = p.a && p.b ? keys().filter(k => valOf(p.a, k) !== valOf(p.b, k)) : [];
    const [ea, eb, da, db] = [dn(p.a?.plan_end), dn(p.b?.plan_end), delayOf(p.a), delayOf(p.b)];
    return { ...p, changed, st: !p.a ? "add" : !p.b ? "del" : changed.length ? "chg" : "same",
      shift: ea !== null && eb !== null ? eb - ea : null, delay: p.a && p.b && da !== null && db !== null ? db - da : null };
  };
  const shared = t => (!$("#g-project").value || t.project === $("#g-project").value) && (!$("#g-usefilter").checked || TF.passes(t));
  const noOf = r => +(r.b || r.a).no || 1e9;
  const diffRows = () => C.pairs.map(diffOf);
  const visibleDiff = rows => rows.filter(r => ($("#cmp-same").checked || r.st !== "same") && shared(r.b || r.a)).sort((x, y) => noOf(x) - noOf(y));

  /* ---------- 差分表 ---------- */
  const days = n => (n === null ? "" : n === 0 ? "±0" : n > 0 ? `+${n}` : `${n}`);
  const dayCell = (n, tip) => el("td", { class: `num ${n > 0 ? "late" : n < 0 ? "early" : ""}`, title: tip, text: days(n) });
  const diffRow = r => el("tr", { class: `st-${r.st}`, "data-st": r.st },
    el("td", {}, el("span", { class: `badge st-${r.st}`, text: ST_JA[r.st] })),
    el("td", { class: "num", text: r.a && r.b && r.a.no !== r.b.no ? `${r.a.no} → ${r.b.no}` : (r.b || r.a).no }),
    el("td", { class: "path", title: r.by ? `対応付け: ${r.by}` : "", text: pathText(r.b || r.a) }),
    el("td", { class: "chg-list" }, ...(r.st === "chg" ? r.changed.map(k => el("span", { class: "chg", "data-k": k },
      el("b", { text: `${labelOf(k)}: ` }), el("s", { text: fmt(k, valOf(r.a, k)) }), " → ", el("ins", { text: fmt(k, valOf(r.b, k)) })))
      : [el("span", { class: "muted", text: r.st === "add" ? "今回のファイルにだけある" : r.st === "del" ? "前回のファイルにだけある" : "" })])),
    dayCell(r.shift, "今回の予定終了 − 前回の予定終了（暦日）"),
    dayCell(r.delay, "遅れ（実績終了または今日 − 予定終了）の今回 − 前回"),
    el("td", { class: "num", text: r.a && r.b ? (r.a.progress === r.b.progress ? `${r.b.progress}%` : `${r.a.progress}% → ${r.b.progress}%`) : `${(r.b || r.a).progress}%` }),
    effCell(r, "actual_effort", "実績工数の差（今回 − 前回）"), effCell(r, "plan_effort", "予定工数（参考）の差（今回 − 前回）"),
    effCell(r, "actual_amount", "実績金額の差（今回 − 前回）"), effCell(r, "plan_amount", "予定金額（参考）の差（今回 − 前回）"));
  /* 工数・金額の差 (今回 − 前回)。どちらかが空欄なら空欄 */
  const effDiff = (r, k) => {
    const [a, b] = [r.a && effortOf(r.a)[k], r.b && effortOf(r.b)[k]];
    if (a === null || b === null || a === undefined || b === undefined) return "";
    const d = b - a;
    return d === 0n ? "±0.00" : `${d > 0n ? "+" : "−"}${fmtCents(d > 0n ? d : -d)}`;
  };
  const effCell = (r, k, tip) => (t => el("td", { class: `num ${t.startsWith("+") ? "late" : t.startsWith("−") ? "early" : ""}${k.startsWith("plan_") ? " ref" : ""}`, title: tip, text: t }))(effDiff(r, k));
  const renderDiff = () => {
    const all = diffRows(), rows = visibleDiff(all), n = st => all.filter(r => r.st === st).length;
    $("#cmp-summary").textContent = `変更 ${n("chg")}・追加 ${n("add")}・削除 ${n("del")}・同じ ${n("same")}　（共通条件で表示 ${rows.length} 件）`;
    $("#cmp-table").replaceChildren(
      el("thead", {}, el("tr", {}, ...["状態", "No.", "タスク", "変わった項目（前回 → 今回）", "予定終了の差（日）", "遅れの差（日）", "進捗", "実績工数の差", "予定工数の差（参考）", "実績金額の差", "予定金額の差（参考）"].map(h => el("th", { text: h })))),
      el("tbody", {}, ...rows.map(diffRow)));
  };

  /* ---------- ガント (2 つ) ---------- */
  const pane = id => el("div", { class: "cmp-pane" }, el("div", { class: "cmp-title", id: `${id}-title` }),
    el("div", { id: `${id}-gantt`, class: "gantt compact" },
      el("div", { class: "g-lh" }, el("div", { id: `${id}-thead` })), el("div", { class: "g-rh", id: `${id}-rhead-wrap` }, el("svg", { id: `${id}-rhead` })),
      el("div", { class: "g-lb", id: `${id}-lbody-wrap` }, el("div", { id: `${id}-table` })), el("div", { class: "g-rb", id: `${id}-scroll` }, el("svg", { id: `${id}-chart` }))),
    el("div", { id: `${id}-tip`, class: "tip", hidden: "hidden" }), el("span", { id: `${id}-ro`, hidden: "hidden" }));
  const setup = () => {
    if (C.ga) return;
    $("#cmp-gantts").replaceChildren(pane("ca"), pane("cb"));
    const both = () => [...tasksOf(C.a), ...tasksOf(C.b)], cols = ["plan_start", "plan_end", "progress", "depends"];
    C.ga = makeGantt({ id: "ca", tasks: () => tasksOf(C.a), spanTasks: both, cols });
    C.gb = makeGantt({ id: "cb", tasks: () => tasksOf(C.b), spanTasks: both, cols, ghost: t => ($("#cmp-ghost").checked ? C.ghost.get(t) : null) });
    [C.ga, C.gb].forEach(g => g.init());
    const sync = (from, to) => from.addEventListener("scroll", () => {  // スクロールを合わせる (横並びは縦も)
      to.scrollLeft !== from.scrollLeft && (to.scrollLeft = from.scrollLeft);
      $("#cmp-view").value === "side" && to.scrollTop !== from.scrollTop && (to.scrollTop = from.scrollTop);
    });
    sync($("#ca-scroll"), $("#cb-scroll")); sync($("#cb-scroll"), $("#ca-scroll"));
  };

  /* ---------- 共通条件 (編集タブと同じ部品の値を使う) ---------- */
  const MIRROR = [["#cmp-zoom", "#g-zoom"], ["#cmp-project", "#g-project"], ["#cmp-inazuma", "#g-inazuma"], ["#cmp-deps", "#g-deps"], ["#cmp-usefilter", "#g-usefilter"], ["#cmp-effort", "#g-effort"]];
  const mirrorIn = () => MIRROR.forEach(([m, g]) => {
    m === "#cmp-project" && ($(m).innerHTML = $(g).innerHTML);
    $(g).type === "checkbox" ? ($(m).checked = $(g).checked) : ($(m).value = $(g).value);
  });
  const condText = () => {
    const f = Object.keys(TF.F.filters).map(id => SPECS.tasks.find(c => colKey(c) === id)?.h || id);
    return `共通条件: フィルター ${f.length ? f.join("・") : "なし"}　表示 ${$("#g-zoom").selectedOptions[0]?.textContent}　プロジェクト ${$("#g-project").selectedOptions[0]?.textContent}`
      + ($("#g-usefilter").checked ? "" : "（表の条件は使わない）");
  };
  const pick = () => {
    const names = S.fileList.map(f => f.name), ok = n => names.includes(n);
    C.b = ok(C.b) ? C.b : ok(S.settings.cmp_b) ? S.settings.cmp_b : S.cur;
    C.a = ok(C.a) && C.a !== C.b ? C.a : ok(S.settings.cmp_a) && S.settings.cmp_a !== C.b ? S.settings.cmp_a : names.find(n => n !== C.b) || C.b;
    [["#cmp-a", C.a], ["#cmp-b", C.b]].forEach(([sel, v]) => {
      $(sel).replaceChildren(...S.fileList.map(f => el("option", { value: f.name, text: `${f.name}${S.files.get(f.name)?.dirty ? " ●" : ""}` })));
      $(sel).value = v;
    });
  };
  const title = (id, role, name) => ($(`#${id}-title`).textContent = `${role}: ${name}${S.files.get(name)?.dirty ? "（未保存の変更を含む）" : ""}${C.a === C.b ? "（A と B が同じファイル）" : ""}`);
  const render = async () => {
    setup(); pick(); mirrorIn();
    await Promise.all([load(C.a), load(C.b)]);
    C.pairs = match(tasksOf(C.a), tasksOf(C.b));
    C.ghost = new Map(C.pairs.filter(p => p.a && p.b).map(p => [p.b, p.a]));
    const view = $("#cmp-view").value;
    $("#cmp-cond").textContent = condText();
    $("#cmp-gantts").className = `cmp-gantts ${view}`;
    $("#cmp-gantts").hidden = view === "diff"; $("#cmp-diff").hidden = view !== "diff";
    $$(".cmp-g-only").forEach(e => (e.hidden = view === "diff")); $$(".cmp-d-only").forEach(e => (e.hidden = view !== "diff"));
    title("ca", "A（前回）", C.a); title("cb", "B（今回）", C.b);
    view === "diff" ? renderDiff() : [C.ga, C.gb].forEach(g => g.render(C.first));
    view !== "diff" && (C.first = false, $("#cb-scroll").scrollLeft = $("#ca-scroll").scrollLeft);
  };
  const choose = () => {
    C.a = $("#cmp-a").value; C.b = $("#cmp-b").value;
    post("/api/settings", { cmp_a: C.a, cmp_b: C.b });
    Object.assign(S.settings, { cmp_a: C.a, cmp_b: C.b }); C.first = true; render();
  };
  document.addEventListener("DOMContentLoaded", () => {
    ["#cmp-a", "#cmp-b"].forEach(s => $(s).addEventListener("change", choose));
    $("#cmp-swap").addEventListener("click", () => { [$("#cmp-a").value, $("#cmp-b").value] = [C.b, C.a]; choose(); });
    MIRROR.forEach(([m, g]) => $(m).addEventListener("change", () => {
      $(g).type === "checkbox" ? ($(g).checked = $(m).checked) : ($(g).value = $(m).value);
      m === "#cmp-zoom" && (C.first = true);
      m === "#cmp-deps" && ((S.settings.gantt_deps = $(m).checked ? "on" : "off"), post("/api/settings", { gantt_deps: S.settings.gantt_deps }));
      render();
    }));
    ["#cmp-view", "#cmp-ghost", "#cmp-same"].forEach(s => $(s).addEventListener("change", () => { s === "#cmp-view" && (C.first = true); render(); }));
    $("#cmp-today").addEventListener("click", () => { C.first = true; render(); });
  });
  return { render, match, diffRows: () => C.pairs.map(diffOf), visibleDiff, delayOf, invalidate: () => C.cache.clear(), C };
})();
