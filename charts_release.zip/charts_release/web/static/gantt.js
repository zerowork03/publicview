"use strict";
/* ガント編集 (SVG + Pointer Events)。chart.py の clean / split と同じ見た目の規則:
   上レーン＝予定 (淡色＋枠、進捗は濃い塗り)、下レーン＝実績 (塗り)、予定超過＝赤、今日＝黄緑、休日＝灰色 */
/* makeGantt(P): ガントを 1 つ作る。P = { id: DOM の接頭辞 ("g" = 編集タブ), main, edit, tasks(), spanTasks(), ghost?(t), cols? }
   表示・プロジェクト・イナズマ線・表の条件 (#g-zoom 等) は全インスタンス共通 (＝共通条件) */
const makeGantt = P => {
  const D = name => document.getElementById(name === "gantt" ? (P.id === "g" ? "gantt" : `${P.id}-gantt`) : `${P.id}-${name}`);
  const T = () => P.tasks();
  /* 行の中: 進捗のつまみの帯 (0〜8) → 予定 (9〜18) → 実績 (21〜30)。つまみと端の当たり判定は縦に重ならない */
  const ROW = 35, HEAD = 44, LANE = 9, TRACK = 9, PY = 9, AY = 21, NOTE_H = 14, ABOVE_H = 13;  // ABOVE_H: 「バーの上」の欄 (つまみの帯のさらに上)
  const OP_JA = { "plan-move": "移動", "plan-l": "開始日", "plan-r": "終了日", "act-move": "実績の移動", "act-l": "実績開始日", "act-r": "実績終了日", prog: "進捗" };
  const FONT = '"Noto Sans CJK JP", "Noto Sans JP", "Yu Gothic UI", Meiryo, sans-serif', NOTE_FONT = `10.5px ${FONT}`, IN_FONT = `8.5px ${FONT}`;
  const measure = (ctx => (text, font = NOTE_FONT) => ((ctx.font = font), ctx.measureText(text).width))(document.createElement("canvas").getContext("2d"));

  /* ---------- バーの周りの表示 (列定義の bar_pos: inside / right / left / below / above) ---------- */
  const BAR_POS_JA = { none: "なし", above: "バーの上", inside: "バー内", right: "バーの右", left: "バーの左", below: "バーの下" };
  const BUILTIN_MASTERS = ["categories", "projects", "owners"];  // 名前だけ出す。ほかのマスタ (優先順位など) は「コード 名前」
  const barCols = pos => (S.data.columns || []).filter(c => c.bar_pos === pos)
    .sort((a, b) => (+a.bar_order || 0) - (+b.bar_order || 0) || (+a.order || 0) - (+b.order || 0));
  const TRUE = new Set(["1", "-1", "true", "yes", "はい"]);  // -1 = Access の Yes
  const fieldText = (t, c) => {
    if (c.type === "calc") return effText(t, c.key);  // 計算列 (予定工数・金額)
    if (EFFORT_KEYS.includes(c.key)) return toCents(t[c.key]) === null ? String(t[c.key] ?? "") : fmtCents(toCents(t[c.key]));
    const v = String(t[c.key] ?? "");
    if (!v) return "";
    if (c.type.startsWith("code:")) {
      const name = S.data[c.type.slice(5)]?.find(m => m.code === v)?.name;
      return !name ? v : BUILTIN_MASTERS.includes(c.type.slice(5)) || name === v ? name : `${v} ${name}`;
    }
    return c.type === "date" ? fmtDate(v) : c.type === "percent" ? `${v}%` : c.type === "bool" ? (TRUE.has(v.toLowerCase()) ? `${c.label}✓` : "") : v;
  };
  const cut = (text, max) => (+max && [...text].length > +max ? [...text].slice(0, +max).join("") + "…" : text);
  const slotOf = (t, pos) => {
    const parts = barCols(pos).map(c => [c, fieldText(t, c)]).filter(([, v]) => v);
    const titled = ([c, v]) => (c.bar_title !== "no" && c.type !== "bool" ? `${c.bar_short || c.label}: ${cut(v, c.bar_max)}` : cut(v, c.bar_max));
    return { text: parts.map(titled).join("・"), tip: parts.map(([c, v]) => `${c.label}: ${v}`).join("\n") };
  };
  /* 行の高さ: 上・下の欄に出すものがある行だけ高くする。offOf = バー (つまみの帯) までの上の余白 */
  const offOf = r => (r.leaf && slotOf(r.t, "above").text ? ABOVE_H : 0);
  const hOf = r => ROW + offOf(r) + (r.leaf && slotOf(r.t, "below").text ? NOTE_H : 0);
  const yb = i => G.ys[i] + (G.offs[i] || 0);  // バーの行の上端 (つまみの帯の上)
  const fitText = (text, px) => {
    const ch = [...text];
    if (measure(text) <= px) return text;
    const k = range(0, ch.length - 1).reverse().find(n => measure(ch.slice(0, n).join("") + "…") <= px) ?? 0;
    return ch.slice(0, k).join("") + "…";
  };
  const OVR = "#e03131", INZ = "#c92a2a", BAND = "#d8f5a2", SLATE = "#4f5f70";
  const todayOn = () => $("#g-todayband")?.checked !== false;  // 今日の帯 (表示の条件・プリセットに入る)
  const WEEK_PPD = 28;  // 編集できるのは週表示だけ
  const G = { ppd: 28, n0: 0, n1: 0, rows: [], ys: [0], offs: [], drag: null, lastTap: null, sel: null, hover: null, dep: null, reveal: new Set(), revealOf: null, depErr: new Map() };  // reveal: 絞り込みの外でも一時的に出す行
  const editable = () => !!P.edit && G.ppd === WEEK_PPD;
  const coarse = () => G.coarse || matchMedia("(pointer: coarse)").matches;  // タッチなら当たりを広く
  /* 端の当たり: マウス 8px・タッチ 14px。短いバーでも本体 (移動) が 1/3 は残るよう、はみ出す側に広げる */
  const edgeZones = (x0, x1, y, h, roles, tips) => {
    const E = coarse() ? 14 : 8, inside = Math.min(E / 2, (x1 - x0) / 3), out = E - inside;
    return [[x0 - out, roles[0], tips[0]], [x1 - inside, roles[1], tips[1]]].map(([x, role, tip]) =>
      el("rect", { x, y, width: E, height: h, fill: "transparent", class: "edge", "data-role": role }, el("title", { text: tip })));
  };
  /* 進捗のつまみ: バーの上の細い帯だけに置く ▼。0%・100% でも端の当たりとは重ならない */
  const progKnob = (y0, px, c, prog) => {
    const W = coarse() ? 20 : 14, tip = `進捗 ${prog}%（ドラッグで変更・ダブルクリックで入力）`;
    return el("g", { class: "knob", "data-role": "prog" },
      el("rect", { x: px - W / 2, y: y0, width: W, height: TRACK - 0.5, fill: "transparent", "data-role": "prog" }),
      el("polygon", { points: `${px - 4.5},${y0 + 1} ${px + 4.5},${y0 + 1} ${px},${y0 + TRACK - 1}`, fill: mix(c, 0.1), stroke: "#fff", "stroke-width": 0.8, "data-role": "prog" }),
      el("title", { text: tip }));
  };
  const mix = (hex, f) => "#" + [1, 3, 5].map(i => Math.round(parseInt(hex.slice(i, i + 2), 16) * (1 - f) + 255 * f).toString(16).padStart(2, "0")).join("");
  const X = n => (n - G.n0) * G.ppd;
  const todayN = () => dn(S.settings.today || S.today);
  const validPlan = t => dn(t.plan_start) !== null && dn(t.plan_end) !== null;  // 日付が不正な行もバーなしで表に残す
  const colorOf = t => S.data.categories.find(c => c.code === t.category)?.color || "#868e96";
  const pname = code => S.data.projects.find(p => p.code === code)?.name || code;

  /* ---------- 行 (階層: プロジェクト＞大項目＞中項目＞タスク) ---------- */
  /* 親の行には key (道筋)、どの行にも anc (上の親の key の並び) */
  const nest = (items, d, anc = []) => [...new Set(items.map(x => (x.path.length === d ? x : x.path[d])))].flatMap(k => {
    if (typeof k !== "string") return [{ leaf: true, depth: d, label: k.t.level3, t: k.t, ti: k.ti, anc }];
    const sub = items.filter(x => x.path.length > d && x.path[d] === k), key = treeAnc(sub[0].t)[d];
    return [{ leaf: false, depth: d, label: k, tasks: sub.map(x => x.t), key, anc }, ...nest(sub, d + 1, [...anc, key])];
  });
  /* 折りたたんだ親の下は隠す (親の行と集計バーは残す)。G.inTree = 折りたたむ前にこの欄にあるタスク */
  const fold = rows => {
    const C = new Set(TF.F.tree || []);
    G.inTree = new Set(rows.filter(r => r.leaf).map(r => r.ti));
    return rows.filter(r => !r.anc.some(k => C.has(k)));
  };
  /* 検索条件 (プロジェクト・タスク表の条件) に合うか */
  const condOK = t => { const pf = $("#g-project").value; return (!pf || t.project === pf) && (!$("#g-usefilter")?.checked || TF.passes(t)); };
  /* 階層の並び: プロジェクト (マスターの順) ＞ 親は最初に出てきた順 ＞ 親の中では No. 順 (chart.py と同じ)。keep で残す行を選ぶ */
  const tree = keep => {
    const pord = Object.fromEntries(S.data.projects.map((p, i) => [p.code, +p.order || i]));
    const all = T().map((t, ti) => ({ t, ti, path: [pname(t.project), t.level1, t.level2].filter(Boolean) }));
    const pkey = (x, d) => x.path.slice(0, d + 1).join("\u0001");
    const first = all.reduce((m, x) => (x.path.forEach((_, d) => m.has(pkey(x, d)) || m.set(pkey(x, d), x.ti)), m), new Map());  // 親は最初に出てきた順
    const byParent = (a, b) => [0, 1, 2].reduce((acc, d) => acc || (first.get(pkey(a, d)) ?? -1) - (first.get(pkey(b, d)) ?? -1), 0);
    const no = x => (/^\d+$/.test(x.t.no || "") ? +x.t.no : 1e9);
    return fold(nest(all.filter(keep).sort((a, b) => (pord[a.t.project] ?? 999) - (pord[b.t.project] ?? 999) || byParent(a, b) || no(a) - no(b) || a.ti - b.ti), 0));
  };
  const buildRows = () => {
    if (P.only) { const set = new Set(P.only()); return tree(x => set.has(x.ti)); }  // 下の欄: 連鎖のタスクだけを同じ階層で (親の集計も表示中のタスクだけ)
    const pf = $("#g-project").value, useTF = $("#g-usefilter")?.checked;  // タスク表の条件 (共通条件) で絞り込む
    return tree(x => G.reveal.has(x.ti) || ((!pf || x.t.project === pf) && (!useTF || TF.passes(x.t))));
  };

  /* ---------- 予定・実績の値 ---------- */
  const barsOf = t => {
    const tn = todayN(), as = dn(t.actual_start), ae = dn(t.actual_end);
    return { ps: dn(t.plan_start), pe: dn(t.plan_end) + 1, as, ae: ae !== null ? ae + 1 : as !== null ? Math.max(tn + 1, as + 1) : null,
      running: as !== null && ae === null, done: ae !== null, prog: clamp(+t.progress || 0, 0, 100), cal: isCalDay(t) };
  };
  const aggOf = all => {
    const ts = all.filter(validPlan);
    if (!ts.length) return null;
    /* 進捗の重み: 暦日のタスクがあるときは各タスク自身の日数 (暦日 / 稼働日)。無ければ従来どおり暦の日数 (出力を変えない) */
    const own = ts.some(isCalDay) && S.settings.workdays === "on";
    const b = ts.map(barsOf), started = b.filter(x => x.as !== null), w = b.map((x, k) => (own ? S.cal.ndays(ts[k], x.ps, x.pe - 1) : x.pe - x.ps)), wsum = w.reduce((a, v) => a + v, 0);
    return { ps: Math.min(...b.map(x => x.ps)), pe: Math.max(...b.map(x => x.pe)), as: started.length ? Math.min(...started.map(x => x.as)) : null,
      ae: started.length ? Math.max(...started.map(x => x.ae)) : null, running: started.length > 0 && !b.every(x => x.done),
      done: b.every(x => x.done), prog: wsum ? b.reduce((a, x, i) => a + x.prog * w[i], 0) / wsum : 0, n: ts.length };
  };
  const progressPoint = b => {
    if (S.settings.workdays !== "on" || b.cal) return b.ps + (b.prog / 100) * (b.pe - b.ps);  // 暦日のタスクは暦の軸で
    const wds = range(b.ps, b.pe - 1).filter(n => !S.cal.isOff(n)), T = (b.prog / 100) * wds.length, k = Math.floor(T);
    return !wds.length ? b.ps + (b.prog / 100) * (b.pe - b.ps) : k >= wds.length ? b.pe : wds[k] + (T - k);
  };

  /* ---------- 描画 ---------- */
  /* 表示期間 (共通条件): auto = 検索条件に合うタスク / fixed = 指定の期間 / all = 全タスク。下の欄は固定以外なら自分のタスク */
  const spanMode = () => TF.F.range || { mode: "auto" };
  const fixedSpan = r => r.mode === "fixed" && dn(r.from) !== null && dn(r.to) !== null && dn(r.to) >= dn(r.from) ? [dn(r.from), dn(r.to)] : null;
  const span = () => {
    const r = spanMode(), fx = fixedSpan(r);
    if (fx) return fx;
    const pool = P.spanOwn ? P.spanOwn() : (P.spanTasks?.() || T());
    const ts = P.spanOwn || r.mode === "all" ? pool : pool.filter(t => condOK(t) || [...G.reveal].some(ti => T()[ti] === t));
    const ns = ts.flatMap(t => ["plan_start", "plan_end", "actual_start", "actual_end"].map(c => dn(t[c]))).filter(v => v !== null);
    const tn = todayN();
    return [Math.min(tn, ...ns) - 7, Math.max(tn, ...ns) + 14];
  };
  const dayColor = n => {
    const d = ds(n), h = S.cal.hol.get(d);
    return S.cal.work.has(d) ? "#555" : h ? (h.type === "会社休日" ? "#b07070" : "#c0504d") : wday(n) === 0 ? "#c0504d" : wday(n) === 6 ? "#4f81bd" : "#555";
  };
  /* 月表示: 「YYYY年MM月」の行と「第N週」の行 (週は月曜始まり、1 日を含む週が第1週) */
  const MONTH_PPD = 12;
  const weekOfMonth = n => { const first = dn(ds(n).slice(0, 8) + "01"); return Math.floor((+ds(n).slice(8) - 1 + ((wday(first) + 6) % 7)) / 7) + 1; };
  const segs = (days, cut) => days.filter((n, k) => k === 0 || cut(n)).map((n, k, a) => [n, a[k + 1] ?? G.n1 + 1]);
  const monthStart = n => ds(n).endsWith("-01");
  /* 縦の線: 見出しとチャートで同じ位置・同じ色 (見出しの境目がそのまま下へ続く) */
  const gridDays = days => days.filter(n => G.ppd >= 12 && G.ppd !== MONTH_PPD || wday(n) === 1 || monthStart(n));
  const lineStyle = n => (monthStart(n) ? ["#6f7680", 1.2] : wday(n) === 1 ? ["#a3aab3", 0.9] : ["#d5d9de", 0.6]);
  const fitLabel = (cands, w) => cands.find(t => measure(t, `11px ${FONT}`) + 3 <= w) ?? "";
  const monthHeader = (days, W) => {
    const tn = todayN();
    return [
      ...segs(days, monthStart).map(([a, b]) => el("text", { x: (X(a) + X(b)) / 2, y: 15, "text-anchor": "middle", "font-size": 11, fill: "#333", class: "mh-month",
        text: fitLabel([`${ds(a).slice(0, 4)}年${ds(a).slice(5, 7)}月`, `${+ds(a).slice(5, 7)}月`], X(b) - X(a)) })),
      el("rect", { x: X(tn) + 1, y: 23, width: G.ppd - 2, height: 18, rx: 2, fill: BAND, stroke: "#82b81a" }),
      ...segs(days, n => wday(n) === 1 || monthStart(n)).map(([a, b]) => el("text", { x: (X(a) + X(b)) / 2, y: 36, "text-anchor": "middle", "font-size": 11, fill: "#555", class: "mh-week",
        "data-day": ds(a), text: fitLabel([`第${weekOfMonth(a)}週`, `${weekOfMonth(a)}`], X(b) - X(a)) })),  // 月は上の行にあるので付けない
      el("line", { x1: 0, x2: W, y1: 21, y2: 21, stroke: "#d5d9de" }),
    ];
  };
  const headerLines = days => gridDays(days).map(n => {
    const [c, w] = lineStyle(n);
    return el("line", { x1: X(n), x2: X(n), y1: monthStart(n) ? 0 : 21, y2: HEAD, stroke: c, "stroke-width": w, class: "hl-grid" });
  });
  const header = W => {
    const days = range(G.n0, G.n1), tn = todayN();
    if (G.ppd === MONTH_PPD) return [...headerLines(days), ...monthHeader(days, W)];
    const starts = days.filter(n => ds(n).endsWith("-01"));
    const months = [...(starts[0] === undefined || X(starts[0]) - X(G.n0) > 60 ? [G.n0] : []), ...starts];  // 左端の月名は重なるなら省略
    const showDays = G.ppd >= 12 && G.ppd !== MONTH_PPD;
    return [
      ...months.map(n => el("text", { x: X(n) + 3, y: 15, "font-size": 11, fill: "#333", text: ds(n).slice(0, 7).replace("-", "/") })),
      ...months.map(n => el("line", { x1: X(n), x2: X(n), y1: 0, y2: HEAD, stroke: "#8a929c" })), ...headerLines(days),
      ...(showDays ? days.map(n => el("g", {}, n === tn && el("rect", { x: X(n) + 1, y: 22, width: G.ppd - 2, height: 18, rx: 3, fill: BAND, stroke: "#82b81a" }),
        el("text", { x: X(n) + G.ppd / 2, y: 35, "text-anchor": "middle", "font-size": G.ppd >= 20 ? 11 : 9, fill: n === tn ? "#1d3d00" : dayColor(n),
          "font-weight": n === tn ? "bold" : null, text: +ds(n).slice(8) }))) :
        [el("rect", { x: X(tn) - 1, y: 22, width: Math.max(G.ppd, 3) + 2, height: 18, fill: BAND }),
          el("text", { x: X(tn) + 4, y: 35, "font-size": 10, fill: "#1d3d00", "font-weight": "bold", text: `今日 ${ds(tn).slice(5).replace("-", "/")}` })]),
    ];
  };
  const background = H => {
    const days = range(G.n0, G.n1), tn = todayN();
    const off = G.ppd >= 8 ? days.filter(S.cal.isOff).map(n => el("rect", { x: X(n), y: 0, width: G.ppd, height: H, fill: "#e3e8ef", opacity: 0.75 })) : [];
    const lines = gridDays(days).map(n => {
      const [c, w] = lineStyle(n);
      return el("line", { x1: X(n), x2: X(n), y1: 0, y2: H, stroke: c, "stroke-width": w, class: "bg-grid" });
    });
    const bandW = G.ppd < 6 ? 7 * G.ppd : G.ppd, bandX = G.ppd < 6 ? X(tn - ((wday(tn) + 6) % 7)) : X(tn);
    return [...off, todayOn() && el("rect", { x: bandX, y: 0, width: bandW, height: H, fill: BAND, opacity: 0.8 }), ...lines].filter(Boolean);
  };
  /* 前回の予定 (比較の B 側): 予定が違う行だけ破線の枠で重ねる */
  const ghostOf = (r, i) => {
    const g = r.leaf && P.ghost?.(r.t);
    if (!g || !validPlan(g) || (g.plan_start === r.t.plan_start && g.plan_end === r.t.plan_end)) return null;
    const [a, b] = [dn(g.plan_start), dn(g.plan_end) + 1];
    return el("rect", { x: X(a), y: yb(i) + PY - 2.5, width: Math.max(0, X(b) - X(a)), height: LANE + 5, fill: "none", stroke: "#7048e8",
      "stroke-width": 1.3, "stroke-dasharray": "4 2", class: "ghost", "pointer-events": "none" });
  };
  const lanes = (r, i) => [ghostOf(r, i), ...lanesOf(r, i)];
  const lanesOf = (r, i) => {
    const y0 = yb(i), b = r.leaf ? (validPlan(r.t) ? barsOf(r.t) : null) : aggOf(r.tasks);
    if (!b) return [];
    const c = r.leaf ? colorOf(r.t) : SLATE, ti = r.leaf ? r.ti : null;
    const ed = r.leaf && editable(), role = name => (ed ? name : null), pw = Math.max(0, X(b.pe) - X(b.ps)), px = X(b.ps) + (pw * b.prog) / 100;
    const inTip = r.leaf && slotOf(r.t, "inside").tip;
    const tip = r.leaf ? `${r.t.level3}${inTip ? "\n" + inTip : ""}\n予定 ${r.t.plan_start}〜${r.t.plan_end}（${b.cal ? "暦日" : "稼働"} ${S.cal.ndays(r.t, b.ps, b.pe - 1)} 日${b.cal ? "・稼働カレンダー: 暦日（休日も数える）" : ""}）\n実績 ${r.t.actual_start || "－"}〜${r.t.actual_end || (b.running ? "進行中" : "－")}\n進捗 ${b.prog}%` : P.only ? `${r.label}（この欄に表示中の ${b.n} 件だけの集計）\n予定 ${fmtDate(ds(b.ps))}〜${fmtDate(ds(b.pe - 1))}\n進捗 ${Math.round(b.prog)}%` : null;
    const plan = el("g", { "data-ti": ti },
      el("rect", { x: X(b.ps), y: y0 + PY, width: pw, height: LANE, fill: mix(c, 0.72), stroke: c, "stroke-width": 0.9, class: ed ? "drag" : null, "data-role": role("plan-move") },
        tip && el("title", { text: ed ? `移動（ドラッグ）\n${tip}` : tip })),
      el("rect", { x: X(b.ps), y: y0 + PY, width: (pw * b.prog) / 100, height: LANE, fill: mix(c, 0.3), opacity: 0.85, "pointer-events": "none" }),
      ed && el("rect", { x: X(b.ps), y: y0 + PY - 1.6, width: pw, height: 0.8, fill: mix(c, 0.45), "pointer-events": "none", class: "ptrack" }),
      ...(ed ? edgeZones(X(b.ps), X(b.pe), y0 + PY, LANE + 1, ["plan-l", "plan-r"], [`開始日 ${fmtDate(r.t.plan_start)}（ドラッグで変更）`, `終了日 ${fmtDate(r.t.plan_end)}（ドラッグで変更）`]) : []),
      ed && progKnob(y0, px, c, b.prog));
    const note = r.leaf ? barLabels(r.t, b, y0) : [];
    if (b.as === null) return [plan, ...note, ed && el("rect", { x: X(G.n0), y: y0 + AY, width: X(G.n1 + 1), height: LANE, fill: "transparent", "data-role": "act-new", "data-ti": ti })];
    const okEnd = Math.min(b.ae, Math.max(b.pe, b.as)), tipX = X(b.ae);
    const act = el("g", { "data-ti": ti },
      el("rect", { x: X(b.as), y: y0 + AY, width: Math.max(0, X(okEnd) - X(b.as)), height: LANE, fill: c, class: ed ? "drag" : null, "data-role": role("act-move") }),
      b.ae > b.pe && el("rect", { x: X(Math.max(b.pe, b.as)), y: y0 + AY, width: Math.max(0, X(b.ae) - X(Math.max(b.pe, b.as))), height: LANE, fill: OVR, class: ed ? "drag" : null, "data-role": role("act-move") }),
      b.running && el("polygon", { points: `${tipX},${y0 + AY - 1} ${tipX + 6},${y0 + AY + LANE / 2} ${tipX},${y0 + AY + LANE + 1}`, fill: b.ae > b.pe ? OVR : c }),
      ...(ed ? edgeZones(X(b.as), X(b.ae) + (b.running ? 3 : 0), y0 + AY - 1, LANE + 2, ["act-l", "act-r"],
        [`実績開始日 ${fmtDate(r.t.actual_start)}（ドラッグで変更）`, b.running ? "実績終了日: 進行中（右端をドラッグで設定）" : `実績終了日 ${fmtDate(r.t.actual_end)}（ドラッグで変更）`]) : []));
    return [plan, act, ...note];
  };
  const label = (cls, x, y, text, tip, room, extra = {}) => room > 14 && text &&
    el("text", { x, y, "font-size": 10.5, fill: "#6b7280", class: `bl ${cls}`, ...extra }, fitText(text, room), el("title", { text: tip }));
  const barLabels = (t, b, y0) => {
    const L = Object.fromEntries(["inside", "right", "left", "below", "above"].map(p => [p, slotOf(t, p)]));
    const pw = X(b.pe) - X(b.ps), fits = L.inside.text && measure(L.inside.text, IN_FONT) <= pw - 6;  // 入らなければ右へ回す
    const right = [!fits && L.inside, L.right].filter(x => x?.text);
    const x0 = X(Math.min(b.ps, b.as ?? b.ps)), x1 = X(Math.max(b.pe, b.ae ?? b.pe)) + (b.running ? 7 : 0), W = X(G.n1 + 1);
    return [
      fits && el("text", { x: X(b.ps) + 3, y: y0 + PY + LANE - 1.6, "font-size": 8.5, fill: "#1f2933", class: "bl bl-in", "pointer-events": "none" }, L.inside.text),
      label("bl-r", x1 + 5, y0 + ROW / 2 + 3.5, right.map(x => x.text).join("・"), right.map(x => x.tip).join("\n"), W - x1 - 10),
      label("bl-l", x0 - 5, y0 + ROW / 2 + 3.5, L.left.text, L.left.tip, x0 - 6, { "text-anchor": "end" }),
      label("note-t bl-b", x0 + 1, y0 + AY + LANE + 12, L.below.text, L.below.tip, W - x0 - 6),
      label("bl-a", x0 + 1, y0 - 2.5, L.above.text, L.above.tip, W - x0 - 6),  // つまみの帯より上 (重ならない)
    ].filter(Boolean);
  };
  const inazuma = () => {
    const tn = todayN(), xt = X(tn + 0.5);
    const due = r => { const b = r.leaf && validPlan(r.t) && barsOf(r.t); return b && !b.done && (b.as !== null || b.ps <= tn) ? b : null; };
    const vOf = (r, i) => { const b = due(r); return b ? [X(progressPoint(b)), yb(i) + PY + LANE / 2] : null; };  // 進捗点 (無ければ今日の線のまま)
    const pts = G.rows.flatMap((r, i) => [[xt, G.ys[i]], vOf(r, i), [xt, G.ys[i + 1]]].filter(Boolean));
    const vtx = G.rows.map(vOf).filter(p => p && Math.abs(p[0] - xt) > 0.5);
    const P = pts.map(p => p.join(",")).join(" ");
    return [el("polyline", { points: P, fill: "none", stroke: "#fff", "stroke-width": 4, "stroke-linejoin": "round", opacity: 0.9, "pointer-events": "none" }),
      el("polyline", { points: P, fill: "none", stroke: INZ, "stroke-width": 1.4, "stroke-linejoin": "round", "pointer-events": "none" }),
      ...vtx.map(([x, y]) => el("circle", { cx: x, cy: y, r: 2.6, fill: INZ, stroke: "#fff", "stroke-width": 0.8, "pointer-events": "none" }))];
  };
  /* ---------- 影響線 (depends): 先行の予定バーの終わり → このタスクの予定バーの始まり (かぎ形＋小さな矢じり) ---------- */
  const DEP_C = "#3d4b5c";  // 関係を示すだけ (日付の矛盾の判定はしない)
  const depsOn = () => !!$("#g-deps")?.checked;
  const depLines = () => {
    const dg = G.dep, at = taskRowAt();
    const wk = G.ppd >= 12, d = wk ? 6 : 3, sw = wk ? 1.3 : 0.6, ah = wk ? 4 : 2.5;  // 年・月表示は細く
    const mid = i => yb(i) + PY + LANE / 2, bar = ti => at.has(ti) && (G.rows[at.get(ti)].leaf ? validPlan(T()[ti]) && barsOf(T()[ti]) : aggOf(G.rows[at.get(ti)].tasks));
    const head = (x, y, c) => el("polygon", { points: `${x},${y} ${x - ah * 1.3},${y - ah * 0.8} ${x - ah * 1.3},${y + ah * 0.8}`, fill: c });
    const name = ti => `No.${T()[ti].no} ${T()[ti].level3}`;
    const link = (p, s) => {
      const [i, j] = [at.get(s), at.get(p)], bs = bar(s), bp = bar(p), c = DEP_C;
      if (i !== undefined && i === j) return null;  // 同じ折りたたんだ親の中どうし
      const g = (...kids) => el("g", { class: "dep", "data-a": p, "data-b": s, "pointer-events": "none" }, ...kids, el("title", { text: `${name(p)} → ${name(s)}` }));
      if (i !== undefined && j !== undefined && bs && bp) {
        const [x1, y1, x2, y2] = [X(bp.pe), mid(j), X(bs.ps), mid(i)], yM = G.ys[Math.max(i, j)];
        const path = x2 - d >= x1 + d ? `M${x1},${y1} H${x1 + d} V${y2} H${x2 - ah}` : `M${x1},${y1} H${x1 + d} V${yM} H${x2 - 2 * d} V${y2} H${x2 - ah}`;
        return g(el("path", { d: path, fill: "none", stroke: c, "stroke-width": sw }), head(x2, y2, c));  // 後が先に始まるときは行の境目を回る
      }
      if (i !== undefined && bs)  // 先行が表示されていない (絞り込み・別のプロジェクト): 短い線と No.
        return g(el("path", { d: `M${X(bs.ps) - 3.5 * d},${mid(i)} H${X(bs.ps) - ah}`, fill: "none", stroke: c, "stroke-width": sw, "stroke-dasharray": "3 2" }),
          head(X(bs.ps), mid(i), c), wk && el("text", { x: X(bs.ps) - 3.5 * d - 2, y: mid(i) + 3, "font-size": 9, fill: c, "text-anchor": "end", text: `No.${T()[p].no}` }));
      if (j !== undefined && bp)  // 後のタスクが表示されていない
        return g(el("path", { d: `M${X(bp.pe)},${mid(j)} H${X(bp.pe) + 3.5 * d}`, fill: "none", stroke: c, "stroke-width": sw, "stroke-dasharray": "3 2" }),
          wk && el("text", { x: X(bp.pe) + 3.5 * d + 2, y: mid(j) + 3, "font-size": 9, fill: c, text: `→No.${T()[s].no}` }));
      return null;
    };
    return dg.preds.flatMap((ps, s) => ps.map(p => link(p, s))).filter(Boolean);
  };
  /* タスク → 行の番号。折りたたみで隠れたタスクは、表示中のいちばん外側の折りたたんだ親の行 */
  const taskRowAt = () => {
    const at = new Map(G.rows.map((r, i) => [r.leaf ? r.ti : null, i]).filter(([ti]) => ti !== null));
    const pk = new Map(G.rows.map((r, i) => [!r.leaf && isFolded(r) ? r.key : null, i]).filter(([k]) => k !== null));  // 折りたたんだ親だけ
    [...(G.inTree || [])].filter(ti => !at.has(ti)).forEach(ti => { const k = treeAnc(T()[ti]).find(k => pk.has(k)); k && at.set(ti, pk.get(k)); });
    return at;
  };
  /* ポインターを載せた行 (なければ選んだ行) の先行・後続を強調 */
  const focusDeps = () => {
    const ti = G.hover ?? G.sel, has = ti !== null && ti !== undefined && !!G.dep, on = has && depsOn();
    const pre = new Set(has ? G.dep.preds[ti] : []), suc = new Set(has ? G.dep.succs[ti] : []);  // 表の強調は影響線の表示に関係なく
    D("chart").classList.toggle("dep-focus", on && (pre.size + suc.size) > 0);
    D("chart").querySelectorAll(".dep").forEach(a => a.classList.toggle("hl", on && (+a.dataset.a === ti || +a.dataset.b === ti)));
    D("table").querySelectorAll(".gt-row[data-ti]").forEach(r => {
      r.classList.toggle("dep-pred", pre.has(+r.dataset.ti)); r.classList.toggle("dep-succ", suc.has(+r.dataset.ti));
    });
  };
  const hoverAt = e => {
    const ti = e.target.closest?.("[data-ti]")?.dataset.ti, v = ti === undefined || ti === "" ? null : +ti;
    v !== G.hover && ((G.hover = v), focusDeps());
  };

  /* ---------- 左の表 (タスク名・日付・稼働日数・進捗) ---------- */
  const NAME_W = 210;
  const ALL_COLS = [
    { k: "plan_start", h: "予定開始", date: true }, { k: "plan_end", h: "予定終了", date: true }, { k: "pw", h: "稼働(予)", calc: true },
    { k: "actual_start", h: "実績開始", date: true }, { k: "actual_end", h: "実績終了", date: true }, { k: "aw", h: "稼働(実)", calc: true },
    { k: "progress", h: "進捗%", num: true }, { k: "depends", h: "影響", dep: true },
  ];
  const BASE_COLS = ALL_COLS.filter(c => !P.cols || P.cols.includes(c.k));
  /* 工数・金額の列 (ツールバーの「工数・金額」で表示。読み取りだけ。親の行は子の合計、単価は空欄) */
  const effOn = () => !!$("#g-effort")?.checked;
  const effCols = () => [...EFFORT_KEYS, ...CALC_KEYS].map(k => ({ k, h: S.data.columns.find(c => c.key === k)?.label || k, eff: true, ref: k.startsWith("plan_") }));
  const colsNow = () => [...BASE_COLS, ...(effOn() ? effCols() : [])];
  let COLS = BASE_COLS;
  const dateTip = v => (dn(v) !== null ? `${fmtDate(v)}（${WK_JA[wday(dn(v))]}）` : null);
  const pathOf = t => [pname(t.project), t.level1, t.level2, t.level3].filter(Boolean).join(" ＞ ");
  const rowValues = r => {
    const b = r.leaf ? (validPlan(r.t) ? barsOf(r.t) : null) : aggOf(r.tasks);
    if (!b) return r.leaf ? { ...r.t, pw: "", aw: "", ...effVals(r) } : effVals(r);  // 日付が不正: 入力値のまま (赤で表示)
    const nd = (a, z) => (r.leaf ? S.cal.ndays(r.t, a, z) : S.cal.nwork(a, z));  // 親の行は既定のカレンダー
    return { plan_start: ds(b.ps), plan_end: ds(b.pe - 1), pw: nd(b.ps, b.pe - 1),
      actual_start: b.as === null ? "" : ds(b.as), actual_end: b.done ? ds(b.ae - 1) : b.running ? "進行中" : "",
      aw: b.as === null ? "" : nd(b.as, b.ae - 1), progress: Math.round(b.prog), ...effVals(r) };
  };
  const effVals = r => effOn() ? Object.fromEntries(Object.entries(r.leaf ? effortOf(r.t) : effortSum(r.tasks)).map(([k, c]) => [k, fmtCents(c)])) : {};
  const cellOf = (r, c, v, err) => {
    const cls = ["gt-c", c.date || c.calc || c.num ? "num" : "", v === "進行中" ? "run" : "", err ? "err" : ""].filter(Boolean).join(" ");
    if (c.eff) return el("span", { class: `gt-c num eff${c.ref ? " ref" : ""}`, title: `${EFFORT_TIP[c.k]?.() || ""}${r.leaf ? "" : "\n親の行: 子のタスクの合計"}`, text: v ?? "" });
    if (r.leaf && editable() && !c.calc && !c.dep)
      return el("input", { class: cls, type: "text", inputmode: c.num ? "numeric" : null, "data-ti": r.ti, "data-k": c.k,
        value: c.date ? fmtDate(r.t[c.k]) : r.t[c.k], placeholder: c.k === "actual_end" && v === "進行中" ? "進行中" : null,
        title: err || (c.date ? dateTip(r.t[c.k]) || "yyyy/mm/dd で入力（10/15 だけでも可）" : "0〜100") });
    if (c.dep) return depCell(r, err);
    const cal = r.leaf && c.calc && v !== "" && isCalDay(r.t);  // 暦日のタスク: 日数に「暦」の印
    return el("span", { class: cls + (cal ? " cal" : ""), title: err || (cal ? "稼働カレンダー: 暦日（休日も数える）" : c.date ? dateTip(v) : null), text: c.date ? fmtDate(v) : v });
  };
  /* 影響 (depends) の欄: No. ごとのリンク (押すとその行へ)。週表示ならダブルクリックで入力 */
  const taskName = ti => `No.${T()[ti].no} ${T()[ti].level3}`;
  const depCell = (r, err) => {
    if (!r.leaf) return el("span", { class: "gt-c gt-dep" });
    const links = depTokens(r.t.depends).map(no => {
      const ti = G.dep?.byNo.get(no);
      return el("a", { class: `dep-link${ti === undefined ? " missing" : ""}`, href: "#", "data-no": no, title: ti === undefined ? `No.${no} はこのファイルにありません` : `${taskName(ti)} へ移動` , text: no });
    });
    return el("span", { class: `gt-c gt-dep${err ? " err" : ""}`, "data-ti": r.ti, "data-k": "depends",
      title: err || (editable() && P.edit ? "ダブルクリックで入力（No. をカンマ区切り）" : null) },
      ...links.flatMap((a, k) => (k ? [",", a] : [a])));
  };
  const editDeps = span => {
    const ti = +span.dataset.ti, inp = el("input", { class: "gt-c gt-dep-in", type: "text", "data-ti": ti, "data-k": "depends", value: T()[ti].depends || "", placeholder: "例 3,5" });
    span.replaceWith(inp); inp.focus(); inp.select();
  };
  const rowErrs = r => new Map([...(r.leaf ? taskErrors(r.t) : []), ...(r.leaf ? (G.depErr.get(r.ti) ? [["depends", G.depErr.get(r.ti)]] : []) : [])]);
  const noCell = r => el("span", { class: "gt-c gt-no num", title: r.leaf ? taskName(r.ti) : null, text: r.leaf ? r.t.no : "" });
  /* 影響の No. を押した: その行を選んで見える所へ。絞り込みで隠れていれば案内を出す */
  const jumpTo = no => {
    const ti = G.dep?.byNo.get(no);
    if (ti === undefined) return msg(`No.${no} はこのファイルにありません`, false);
    const anc = treeAnc(T()[ti]);  // 折りたたんだ親の中なら、その上の親をすべて開く
    anc.some(k => TF.F.tree.includes(k)) && TF.setTree(TF.F.tree.filter(k => !anc.includes(k)));
    if (!G.rows.some(r => r.leaf && r.ti === ti)) return P.only ? window.Gantt.jumpTo(no) : hiddenNotice(ti);  // 下の欄に無ければ上のガントで
    closeJump(); select(ti, true, true);
  };
  const closeJump = () => D("gantt").querySelector(".g-jump")?.remove();
  const hiddenNotice = ti => {
    closeJump();
    const btn = (text, fn) => el("button", { text, onclick: () => { closeJump(); fn(); render(); select(ti, true, true); } });
    D("gantt").append(el("div", { class: "g-jump", role: "alert" },
      el("span", { text: `${taskName(ti)} は絞り込みで表示されていません` }),
      btn("一時的に表示", () => G.reveal.add(ti)),
      btn("絞り込みを解除", () => { $("#g-project").value = ""; TF.passes(T()[ti]) || TF.clearFilters(); }),
      el("button", { class: "notice-x", title: "閉じる", text: "×", onclick: closeJump })));
  };
  const isFolded = r => (TF.F.tree || []).includes(r.key);
  const togOf = r => el("span", { class: "gt-tog", role: "button", "data-key": r.key, "aria-expanded": String(!isFolded(r)),
    title: isFolded(r) ? "展開する（下の行を表示）" : "折りたたむ（集計バーだけ残す）", text: isFolded(r) ? "▶ " : "▼ " });
  const tableRow = (r, i) => {
    const v = rowValues(r), errs = rowErrs(r);
    const cls = ["gt-row", r.leaf ? (i % 2 ? "odd" : "") : `parent d${Math.min(r.depth, 2)}`, r.leaf && r.ti === G.sel ? "sel" : "", r.leaf && G.reveal.has(r.ti) ? "revealed" : "",
      P.only && r.ti === P.source?.() ? "chain-src" : "", r.leaf && P.only && !condOK(r.t) ? "outfilter" : ""].filter(Boolean).join(" ");
    const owner = r.leaf && (S.data.owners.find(o => o.code === r.t.owner)?.name || r.t.owner);
    const off = offOf(r), note = hOf(r) - off > ROW;
    return el("div", { class: cls + (note ? " has-note" : ""), style: `height:${hOf(r)}px;padding-top:${off + (note ? 5 : 0)}px`, "data-ti": r.leaf ? r.ti : null,
      title: r.leaf && G.reveal.has(r.ti) ? "絞り込みの外 (一時的に表示中)" : r.leaf && P.only && !condOK(r.t) ? "タスク表の検索条件では表示されないタスク" : null },
      noCell(r), el("span", { class: "gt-name", style: `padding-left:${6 + r.depth * 13}px`, title: r.leaf ? `${pathOf(r.t)}（${owner}）` : r.label },
        ...(r.leaf ? [r.label] : [togOf(r), r.label])),
      ...COLS.map(c => cellOf(r, c, v[c.k], errs.get(c.k))));
  };
  const tableHead = () => el("div", { class: "gt-row gt-head" }, el("span", { class: "gt-c gt-h gt-no", text: "No." }),
    el("span", { class: "gt-name", text: `タスク（${G.rows.filter(r => r.leaf).length} 件）` }), ...COLS.map(c => el("span", { class: "gt-c gt-h", text: c.h.replace(/^(予定|実績|稼働)/, "$1\n") })));
  const parseCell = (k, raw, old) => (k === "progress" ? raw.trim() : k === "depends" ? depTokens(raw).join(",") : normDate(raw, old));
  const commitCell = inp => {
    const t = T()[+inp.dataset.ti], k = inp.dataset.k, val = parseCell(k, inp.value, t[k]);
    if (!editable() || val === t[k]) return render();
    pushUndo("tasks"); t[k] = val; markDirty("tasks"); renderAll();
    const err = new Map(taskErrors(t)).get(k);
    const err2 = err || (k === "depends" && G.depErr.get(+inp.dataset.ti));
    err2 ? msg(`「${t.level3}」${COLS.find(c => c.k === k).h}: ${err2}`, false) : msg("");
  };

  const select = (ti, scroll = false, flash = false) => {
    G.sel = ti;
    render();
    const idx = G.rows.findIndex(r => r.leaf && r.ti === ti), sc = D("scroll");
    scroll && idx >= 0 && (sc.scrollTop = Math.max(0, G.ys[idx] - sc.clientHeight / 3));
    const b = flash && idx >= 0 && validPlan(T()[ti]) && barsOf(T()[ti]);  // バーが横の画面の外なら寄せる
    b && (X(b.ps) < sc.scrollLeft || X(b.pe) > sc.scrollLeft + sc.clientWidth) && (sc.scrollLeft = Math.max(0, X(b.ps) - sc.clientWidth / 4));
    flash && D("table").querySelector(`.gt-row[data-ti="${ti}"]`)?.classList.add("flash");
  };
  const rowAt = e => {
    const y = e.clientY - D("chart").getBoundingClientRect().top;
    return G.rows[G.ys.findIndex((top, k) => k < G.rows.length && y >= top && y < G.ys[k + 1])];
  };

  const render = (scrollToday = false, fromPeer = false) => {
    if (!T() || (P.visible && !P.visible())) return;
    !fromPeer && P.peer && !G.peerQ && ((G.peerQ = true), requestAnimationFrame(() => { G.peerQ = false; P.peer()?.render(false, true); }));  // もう一方の欄 (上 ⇔ 影響タスクの欄) も
    G.ppd = +$("#g-zoom").value;
    P.main && typeof TF !== "undefined" && S.presets && TF.presetState();  // ガントの表示もプリセットに入る
    const zoomName = $("#g-zoom").selectedOptions[0]?.textContent.slice(0, 1) ?? "";
    Object.assign(D("ro"), { hidden: editable(), textContent: `${zoomName}表示は閲覧のみ（編集は週表示で）` });
    D("gantt").classList.toggle("readonly", !editable());
    COLS = colsNow(); D("gantt").classList.toggle("with-effort", effOn());
    [G.n0, G.n1] = span();
    G.rows = buildRows();
    G.ys = G.rows.map(hOf).reduce((ys, h) => (ys.push(ys[ys.length - 1] + h), ys), [0]);  // 各行の上端 (累積)
    G.offs = G.rows.map(offOf);
    G.revealOf !== T() && (G.reveal.clear(), (G.revealOf = T()));  // ファイルが替わったら一時表示は消す
    G.dep = depGraph(T());
    G.depErr = new Map(depErrors(T()).map(({ i, e }) => [i, e[1]]));  // 影響の欄の誤り (循環など、ファイル全体で判定)
    const W = X(G.n1 + 1), H = Math.max(G.ys[G.ys.length - 1], 40);
    const rowBg = G.rows.map((r, i) => el("rect", { x: 0, y: G.ys[i], width: W, height: hOf(r), fill: r.leaf ? (i % 2 ? "#fafbfc" : "#fff") : "#eef1f5" }));
    const sep = G.rows.map((r, i) => !r.leaf && r.depth === 0 && el("line", { x1: 0, x2: W, y1: G.ys[i], y2: G.ys[i], stroke: "#8a929c" }));
    const selBg = G.rows.map((r, i) => r.leaf && r.ti === G.sel && el("rect", { x: 0, y: G.ys[i], width: W, height: hOf(r), fill: "#ffe8a3", opacity: 0.55 }));
    D("chart").replaceChildren(...rowBg, ...background(H), ...selBg.filter(Boolean), ...sep.filter(Boolean), ...G.rows.flatMap(lanes).filter(Boolean),
      ...(depsOn() ? depLines() : []), ...($("#g-inazuma").checked ? inazuma() : []));
    Object.entries({ width: W, height: H }).forEach(([k, v]) => D("chart").setAttribute(k, v));
    D("rhead").replaceChildren(...header(W));
    Object.entries({ width: W, height: HEAD }).forEach(([k, v]) => D("rhead").setAttribute(k, v));
    const fa = document.activeElement, focusKey = fa && D("table").contains(fa) && [fa.dataset.ti, fa.dataset.k];
    D("table").replaceChildren(...G.rows.map(tableRow));
    D("thead").replaceChildren(tableHead());
    const sc = D("scroll");
    D("table").style.paddingBottom = `${sc.offsetHeight - sc.clientHeight}px`;  // 横スクロールバーの分だけ下に余白 (行をそろえる)
    focusKey && D("table").querySelector(`input[data-ti="${focusKey[0]}"][data-k="${focusKey[1]}"]`)?.focus();
    focusDeps();
    scrollToday && (D("scroll").scrollLeft = Math.max(0, X(todayN()) - D("scroll").clientWidth / 3));
    syncScroll();
  };
  const syncScroll = () => {
    D("rhead-wrap").scrollLeft = D("scroll").scrollLeft;
    D("lbody-wrap").scrollTop = D("scroll").scrollTop;
  };

  /* ---------- 編集 (ドラッグ) ---------- */
  const tipShow = (e, text) => Object.assign(D("tip"), { hidden: !text, textContent: text || "" }).style.cssText = `left:${e.clientX + 14}px;top:${e.clientY - 30}px`;
  const svgX = e => e.clientX - D("chart").getBoundingClientRect().left;
  const APPLY = {
    "plan-move": (o, d) => ({ plan_start: ds(dn(o.plan_start) + d), plan_end: ds(dn(o.plan_end) + d) }),
    "plan-l": (o, d) => ({ plan_start: ds(Math.min(dn(o.plan_start) + d, dn(o.plan_end))) }),
    "plan-r": (o, d) => ({ plan_end: ds(Math.max(dn(o.plan_end) + d, dn(o.plan_start))) }),
    "act-move": (o, d) => ({ actual_start: ds(dn(o.actual_start) + d), ...(o.actual_end && { actual_end: ds(dn(o.actual_end) + d) }) }),
    "act-l": (o, d) => ({ actual_start: ds(Math.min(dn(o.actual_start) + d, dn(o.actual_end || S.settings.today || S.today))) }),
    "act-r": (o, d) => (o.actual_end ? { actual_end: ds(Math.max(dn(o.actual_end) + d, dn(o.actual_start))) }
      : d === 0 ? {} : { actual_end: ds(Math.max(todayN() + d, dn(o.actual_start))), progress: "100" }),
    prog: (o, d, e) => {
      const b = barsOf(o), f = (svgX(e) - X(b.ps)) / (X(b.pe) - X(b.ps));
      return { progress: String(clamp(Math.round((f * 100) / 5) * 5, 0, 100)) };
    },
  };
  const describe = t => `${OP_JA[G.drag.role]}: ` + (({ prog: `${t.progress}%` })[G.drag.role] ||
    (G.drag.role.startsWith("plan") ? `予定 ${t.plan_start.slice(5)}〜${t.plan_end.slice(5)}（${isCalDay(t) ? "暦日" : "稼働"} ${S.cal.ndays(t, dn(t.plan_start), dn(t.plan_end))} 日）`
      : `実績 ${t.actual_start.slice(5)}〜${t.actual_end ? t.actual_end.slice(5) : "進行中"}`));
  const capture = e => { try { D("chart").setPointerCapture(e.pointerId); } catch { /* 合成イベントなど: なくても動く */ } };
  const down = e => {
    e.pointerType === "touch" && !G.coarse && ((G.coarse = true), render());  // 初めてのタッチで当たりを広げる (以後そのまま)
    /* タッチはブラウザが近くの要素へ寄せる (touch adjustment) ので、指の位置そのものの要素で判定する */
    const at = e.pointerType === "touch" ? document.elementFromPoint(e.clientX, e.clientY) || e.target : e.target;
    const tg = at.closest("[data-role]"), ti = tg?.closest("[data-ti]")?.dataset.ti ?? tg?.dataset.ti;
    const sc = D("scroll"), bg = !editable() || !tg || ti === undefined || ti === "" || tg.dataset.role === "act-new";
    if (bg && e.pointerType !== "mouse") {  // タッチ: 空き場所のドラッグでスクロール
      G.pan = { x: e.clientX, y: e.clientY, sl: sc.scrollLeft, st: sc.scrollTop };
      return capture(e);
    }
    if (bg) { const r = rowAt(e); return r?.leaf && select(r.ti); }  // 閲覧のみ・空き場所: クリックで行を選ぶだけ
    e.preventDefault();
    capture(e);
    G.drag = { ti: +ti, role: tg.dataset.role, x0: e.clientX, orig: { ...T()[+ti] }, snap: JSON.stringify(T()), dirty: S.dirty.has("tasks"), moved: false };
  };
  const move = e => {
    if (G.pan) return Object.assign(D("scroll"), { scrollLeft: G.pan.sl - (e.clientX - G.pan.x), scrollTop: G.pan.st - (e.clientY - G.pan.y) });
    if (!G.drag) return;
    const d = Math.round((e.clientX - G.drag.x0) / G.ppd);
    G.drag.moved ||= Math.abs(e.clientX - G.drag.x0) > 3;
    if (!G.drag.moved) return;
    Object.assign(T()[G.drag.ti], G.drag.orig, APPLY[G.drag.role](G.drag.orig, d, e));
    tipShow(e, describe(T()[G.drag.ti]));
    render();
  };
  const up = (e, cancel = false) => {
    const g = G.drag, p = G.pan;
    G.pan = null;
    if (p && !cancel && Math.hypot(e.clientX - p.x, e.clientY - p.y) < 6) { const r = rowAt(e); r?.leaf && select(r.ti); }  // タップで選択
    if (!g) return;
    G.drag = null; tipShow(e, "");
    if (cancel) { Object.assign(T()[g.ti], g.orig); return render(); }  // 中断されたら元に戻す
    const changed = JSON.stringify(T()[g.ti]) !== JSON.stringify(g.orig);
    if (changed) { addUndo("tasks", g.snap, g.dirty); markDirty("tasks"); renderAll(); return; }
    const now = Date.now(), dbl = G.lastTap && G.lastTap.ti === g.ti && now - G.lastTap.t < 400;
    G.lastTap = { ti: g.ti, t: now };
    g.ti !== G.sel && select(g.ti);
    if (dbl && ["prog", "plan-move"].includes(g.role)) { G.lastTap = null; askProgress(g.ti); }
  };
  const askProgress = ti => {
    const t = T()[ti], v = prompt(`「${t.level3}」の進捗（0〜100）`, t.progress);
    if (v === null || v.trim() === "") return;
    if (!isNum(v.trim(), 0, 100)) return msg("進捗は 0〜100 の数値です", false);
    pushUndo("tasks"); t.progress = String(Math.round(+v)); markDirty("tasks"); renderAll();
  };
  const startActual = e => {
    const tg = editable() && e.target.closest("[data-role=act-new]");
    if (!tg) return;
    const t = T()[+tg.dataset.ti], n = G.n0 + Math.floor(svgX(e) / G.ppd);
    if (!confirm(`「${t.level3}」の実績開始を ${ds(n)} にしますか？`)) return;
    pushUndo("tasks"); t.actual_start = ds(n); markDirty("tasks"); renderAll();
  };

  /* ---------- バー表示のクイック設定 (列定義の bar_pos を変える。保存で columns.csv に残る) ---------- */
  let barPop = null;
  const closeBarPop = () => { barPop?.remove(); barPop = null; };
  const setBar = (key, field, v) => editKind("columns", rows => rows.filter(c => c.key === key).forEach(c => (c[field] = v)));
  const barPopBody = () => [el("div", { class: "bp-row bp-head" }, ...["項目", "位置", "見出し", "短縮名"].map(t => el("span", { text: t })))].concat(
    [...S.data.columns].sort((a, b) => (+a.order || 0) - (+b.order || 0)).map(c => el("div", { class: "bp-row", "data-key": c.key },
      el("span", { text: c.label }),
      el("select", { "data-key": c.key, "data-f": "bar_pos", onchange: e => setBar(c.key, "bar_pos", e.target.value) },
        ...Object.entries(BAR_POS_JA).map(([v, t]) => el("option", { value: v, text: t, selected: (c.bar_pos || "none") === v ? "selected" : null }))),
      el("input", { type: "checkbox", "data-f": "bar_title", title: "値の前に見出し（短縮名か表示名）を付ける 例「担当: 鈴木」",
        checked: c.bar_title !== "no" ? "checked" : null, onchange: e => setBar(c.key, "bar_title", e.target.checked ? "yes" : "no") }),
      el("input", { type: "text", "data-f": "bar_short", maxlength: 10, placeholder: c.label, value: c.bar_short || "", title: "バーに出すときの短い見出し（空なら表示名）",
        onchange: e => setBar(c.key, "bar_short", e.target.value.trim()) }))));
  const openBarPop = btn => {
    barPop = el("div", { class: "fdrop barpop" }, el("div", { class: "fd-title", text: "バーの周りに出す項目" }),
      el("p", { class: "muted", text: "同じ位置の項目は「・」でつなぎます。見出しは「担当: 鈴木」のように付きます（短縮名があればそれを使用）。並び・最大文字数は列定義タブで。保存で列定義に残ります。" }), ...barPopBody());
    document.body.append(barPop);
    const r = btn.getBoundingClientRect();
    Object.assign(barPop.style, { left: `${clamp(r.left, 8, innerWidth - barPop.offsetWidth - 8)}px`, top: `${r.bottom + 2}px`, maxHeight: `${innerHeight - r.bottom - 12}px` });
  };

  const init = () => {
    const svg = D("chart");
    svg.addEventListener("pointerdown", down);
    svg.addEventListener("pointermove", move);
    svg.addEventListener("pointerup", up);
    svg.addEventListener("pointercancel", e => up(e, true));
    svg.addEventListener("dblclick", startActual);
    svg.addEventListener("pointerover", hoverAt);
    svg.addEventListener("pointerleave", () => ((G.hover = null), focusDeps()));
    D("scroll").addEventListener("scroll", syncScroll);
    // 左の表がフォーカス等で縦に動いたらチャートも合わせる (双方向)
    D("lbody-wrap").addEventListener("scroll", () => D("scroll").scrollTop !== D("lbody-wrap").scrollTop && (D("scroll").scrollTop = D("lbody-wrap").scrollTop));
    D("lbody-wrap").addEventListener("wheel", e => { D("scroll").scrollTop += e.deltaY; e.preventDefault(); }, { passive: false });
    const tbl = D("table");
    tbl.addEventListener("click", e => {
      const tg = e.target.closest(".gt-tog");
      if (tg) return e.stopPropagation(), TF.toggleTree(tg.dataset.key);  // 年・月表示でも開閉できる (表示だけ)
      const a = e.target.closest("a.dep-link");
      a && (e.preventDefault(), e.stopPropagation(), jumpTo(a.dataset.no));
    }, true);
    tbl.addEventListener("dblclick", e => {
      const sp = e.target.closest("span.gt-dep[data-ti]");
      sp && editable() && P.edit && !e.target.closest("a") && editDeps(sp);
    });
    tbl.addEventListener("click", e => { const row = e.target.closest(".gt-row[data-ti]"); row && +row.dataset.ti !== G.sel && e.target.tagName !== "INPUT" && select(+row.dataset.ti); });
    P.edit && bindEdit(tbl);
    if (!P.main) return;  // 共通の操作部品 (表示・プロジェクト等) は編集タブのインスタンスだけが受け持つ
    $("#g-barbtn").addEventListener("click", e => (barPop ? closeBarPop() : openBarPop(e.currentTarget)));
    document.addEventListener("pointerdown", e => barPop && !barPop.contains(e.target) && !e.target.closest("#g-barbtn") && closeBarPop(), true);
    document.addEventListener("keydown", e => e.key === "Escape" && closeBarPop());
    ["#g-zoom", "#g-project", "#g-inazuma", "#g-usefilter"].forEach(s => $(s).addEventListener("change", () => (s === "#g-project" || s === "#g-usefilter") && G.reveal.clear()));
    ["#g-zoom", "#g-project", "#g-inazuma", "#g-usefilter", "#g-todayband", "#g-effort"].forEach(s => $(s).addEventListener("change", () => render(s === "#g-zoom")));
    $("#g-deps").addEventListener("change", e => {  // 共通条件: 全タブ・比較でも同じ。設定に残す
      S.settings.gantt_deps = e.target.checked ? "on" : "off"; post("/api/settings", { gantt_deps: S.settings.gantt_deps });
      render(); window.Compare?.render?.();
    });
    $("#g-today").addEventListener("click", () => render(true));
  };
  const bindEdit = tbl => {  // 表のセルの入力 (編集できるインスタンスごと)
    tbl.addEventListener("focusin", e => e.target.dataset.k && e.target.select());
    tbl.addEventListener("change", e => e.target.dataset.k && commitCell(e.target));
    tbl.addEventListener("keydown", e => e.target.dataset.k && ({ Enter: () => e.target.blur(),
      Escape: () => { const k = e.target.dataset.k, v = T()[+e.target.dataset.ti][k]; e.target.value = k === "progress" || k === "depends" ? v ?? "" : fmtDate(v); e.target.blur(); } })[e.key]?.());
    tbl.addEventListener("focusout", e => e.target.classList.contains("gt-dep-in") && setTimeout(() => e.target.isConnected && render()));  // 変更なしで抜けたらリンクの表示に戻す
  };
  P.main && document.addEventListener("DOMContentLoaded", init);
  return { render, init, G, X, D, slotOf, jumpTo, condOK, span, BAR_POS_JA, yb, weekOfMonth, scrollToday: () => (D("scroll").scrollLeft = Math.max(0, X(todayN()) - D("scroll").clientWidth / 3)) };
};
window.makeGantt = makeGantt;
/* ツリーの開閉 (共通条件 TF.F.tree): 親の行は (プロジェクトのコード, 大項目, 中項目) の道筋のキーで表す。名前を変えたり無くなったキーは使われない */
const TREE_SEP = "\t";
const treeAnc = t => [t.project, t.level1, t.level2].filter(Boolean).map((_, d, p) => p.slice(0, d + 1).join(TREE_SEP));
const treeNodes = ts => new Map(ts.flatMap(t => treeAnc(t).map((k, d) => [k, d])));  // キー → 段 (0=プロジェクト 1=大 2=中)
window.Gantt = makeGantt({ id: "g", main: true, edit: true, tasks: () => S.data.tasks, spanTasks: () => openTasks(), peer: () => window.GFooterPeer });

/* ツリーの開閉ボタン (ガント編集・比較のツールバー)。状態は共通条件 TF.F.tree */
document.addEventListener("DOMContentLoaded", () => document.querySelectorAll(".tree-ctl").forEach(box => box.replaceChildren(
  ...[["すべて展開", () => TF.setTree([]), "すべての親を開く"], ["すべて折りたたむ", () => TF.treeLevel("all"), "すべての親を閉じる（集計バーだけ）"]]
    .map(([text, fn, title]) => el("button", { type: "button", text, title, onclick: fn })),
  el("span", { class: "muted", text: " 階層:" }),
  ...[["プロジェクト", 0], ["大", 1], ["中", 2]].map(([text, d]) => el("button", { type: "button", class: "tree-lv", text, "data-lv": d,
    title: `${["プロジェクト", "大項目", "中項目"][d]}まで表示（その下を折りたたむ）`, onclick: () => TF.treeLevel(d) })))));
