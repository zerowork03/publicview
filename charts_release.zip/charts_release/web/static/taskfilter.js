"use strict";
/* タスク表の並べ替え・フィルター (Excel 風)。保存される行の順番は変えない。
   フィルター: 列ごとに {vals: チェックした値 | null, conds: [{op, v}], join: "and" | "or"}。列どうしは AND。
   並べ替え: [{id, dir}] の順に比べる (並べ替え条件ダイアログ・見出しクリック・▾ メニューは同じ状態を見る)。
   見出しクリックは今のレベルを置き換えない: 無い列は最後のレベルに追加 (昇順)、ある列はその位置のまま昇順⇔降順。
   ただし既定の並び (No. 昇順、ユーザーが決めていない) だけのときは、クリックした列に置き換える。
   保存した条件 (プリセット) は読み込むと作業中の条件に写すだけ。あとの変更は作業中だけで、保存は「上書き保存」「別名で保存」のときだけ */
window.TF = (() => {
  const DEFAULT_SORT = () => [{ id: "no", dir: 1 }];  // 既定の表示順は No. の昇順 (行そのものの順番は変えない)
  const F = { filters: {}, sort: DEFAULT_SORT(), sortDefault: true, pinned: new Set(), drop: null, preset: null, range: { mode: "auto", from: "", to: "" }, tree: [] };  // preset = {name, base}
  const isDefaultSort = () => F.sortDefault;
  const setUserSort = levels => {  // 空になったら既定 (No. 昇順) に戻す
    F.sortDefault = !levels.length;
    F.sort = levels.length ? levels : DEFAULT_SORT();
  };
  const cols = () => SPECS.tasksAll;
  const colId = c => c.k || c.id;
  const colBy = id => cols().find(c => colId(c) === id);
  const kindOf = c => (c.calc || ["int", "number", "percent"].includes(c.type) ? "num" : c.type === "date" ? "date" : c.o ? "list" : "text");
  const valOf = (r, c) => String(c.calc ? c.calc(r) : r[c.k] ?? "");
  const numOf = (v, c) => { const x = String(v).replace(/,/g, ""); return x === "" ? (c.k === "progress" ? 0 : null) : isNaN(+x) ? null : +x; };  // 進捗の空欄は 0。1,234.50 も数値
  const BLANK = "（空欄）";
  const labelOf = (c, v) => (!v ? BLANK : c.o ? c.o().find(([x]) => x === v)?.[1] ?? `${v}（定義外）` : v);
  const nameOf = (c, v) => (!v ? BLANK : c.type?.startsWith("code:") ? labelOf(c, v).replace(/^\S+\s/, "") : labelOf(c, v));

  /* ---------- 条件 ---------- */
  const OPS = {
    text: [["contains", "含む"], ["ncontains", "含まない"], ["eq", "等しい"], ["ne", "等しくない"], ["starts", "で始まる"], ["ends", "で終わる"], ["blank", "空欄"], ["nonblank", "空欄以外"]],
    cmp: [["ge", "≥"], ["le", "≤"], ["gt", ">"], ["lt", "<"], ["eq", "="], ["ne", "≠"], ["blank", "空欄"], ["nonblank", "空欄以外"]],
  };
  const opsOf = c => (["num", "date"].includes(kindOf(c)) ? OPS.cmp : OPS.text);
  const opLabel = (c, op) => opsOf(c).find(([o]) => o === op)?.[1] ?? op;
  const noValue = op => op === "blank" || op === "nonblank";
  const CMP = { ge: d => d >= 0, le: d => d <= 0, gt: d => d > 0, lt: d => d < 0, eq: d => d === 0, ne: d => d !== 0 };
  const TEXT = { contains: (s, q) => s.includes(q), ncontains: (s, q) => !s.includes(q), eq: (s, q) => s === q, ne: (s, q) => s !== q,
    starts: (s, q) => s.startsWith(q), ends: (s, q) => s.endsWith(q) };
  const test = (c, { op, v }, raw) => {
    if (noValue(op)) return (raw === "") === (op === "blank");
    const k = kindOf(c);
    if (k === "num") { const n = numOf(raw, c); return n !== null && CMP[op](n - +v); }
    if (k === "date") return raw !== "" && CMP[op](raw.localeCompare(v));
    const q = v.toLowerCase(), texts = k === "list" ? [raw, labelOf(c, raw), nameOf(c, raw)] : [raw];  // コードは名前でも探せる
    const neg = { ne: "eq", ncontains: "contains" }[op], hit = texts.some(t => TEXT[neg || op](t.toLowerCase(), q));
    return neg ? !hit : hit;
  };
  const pass = (c, f, raw) => (!f.vals || f.vals.includes(raw)) &&
    (!f.conds?.length || (f.join === "or" ? f.conds.some(x => test(c, x, raw)) : f.conds.every(x => test(c, x, raw))));
  const passes = (r, except) => Object.entries(F.filters).every(([id, f]) => id === except || !colBy(id) || pass(colBy(id), f, valOf(r, colBy(id))));
  const cmp = (a, b, c) => {
    const [x, y] = [valOf(a, c), valOf(b, c)];
    if (!x || !y) return !x && !y ? 0 : !x ? 1 : -1;  // 空欄は常に最後
    if (c.type?.startsWith("code:")) {  // マスタの列はマスタの並び順で比べる (コードの文字順ではない)
      const order = c.o().map(([v]) => v), rank = v => (order.includes(v) ? order.indexOf(v) : 1e9);
      return rank(x) - rank(y) || x.localeCompare(y, "ja");
    }
    return kindOf(c) === "num" ? numOf(x, c) - numOf(y, c) : x.localeCompare(y, "ja");
  };
  const sorted = (rows, all) => {
    const idx = new Map(all.map((r, i) => [r, i])), keys = F.sort.filter(s => colBy(s.id));
    return keys.length ? [...rows].sort((a, b) => keys.reduce((acc, s) => acc || s.dir * cmp(a, b, colBy(s.id)), 0) || idx.get(a) - idx.get(b)) : rows;
  };
  const apply = rows => sorted(rows.filter(r => F.pinned.has(r) || passes(r)), rows);
  const active = () => Object.keys(F.filters).length > 0 || !isDefaultSort();
  const changed = () => { F.pinned.clear(); renderGrid("tasks"); };
  /* 作業中の条件 (保存する形)。フィルターは列の名前順にそろえて比べる */
  /* 保存した条件に入るもの: フィルター・並べ替え・表示期間・表の見た目・ガントの表示・バー表示 (列ごとの bar_*) */
  const BAR_F = ["bar_pos", "bar_order", "bar_max", "bar_title", "bar_short"];
  const barOf = c => ({ bar_pos: c.bar_pos || "none", bar_order: c.bar_order || "", bar_max: c.bar_max || "", bar_title: c.bar_title === "no" ? "no" : "yes", bar_short: c.bar_short || "" });
  const viewState = () => ({ col_order: S.settings.grid_col_order || "", frozen: String(S.settings.grid_frozen || "0"), hidden: S.settings.grid_hidden || "" });
  const ganttState = () => ({ zoom: $("#g-zoom").value, project: $("#g-project").value, usefilter: $("#g-usefilter").checked, inazuma: $("#g-inazuma").checked,
    deps: $("#g-deps").checked, todayband: $("#g-todayband").checked, chain: $("#gf-scope").value, effort: $("#g-effort").checked });
  const barState = () => Object.fromEntries((S.data.columns || []).filter(c => c.key).map(c => [c.key, barOf(c)]).sort(([a], [b]) => a.localeCompare(b)));
  const state = () => ({ filters: Object.fromEntries(Object.entries(F.filters).sort(([a], [b]) => a.localeCompare(b))), sort: F.sortDefault ? [] : F.sort, range: F.range,
    view: viewState(), gantt: ganttState(), bars: barState(), tree: F.tree });
  /* ---------- ツリーの開閉 (共通条件): 折りたたんだ親のキー。いまのデータに無い道筋は黙って外す (件数だけ知らせる) ---------- */
  const applyTree = (keys, quiet = false) => {
    const kn = treeNodes(openTasks()), want = [...new Set(keys || [])], ok = want.filter(k => kn.has(k)).sort();
    F.tree = ok;
    const v = ok.join("\n");
    v !== (S.settings.gantt_collapsed || "") && ((S.settings.gantt_collapsed = v), post("/api/settings", { gantt_collapsed: v }));
    want.length > ok.length && !quiet && msg(`ツリーの開閉: いまのデータに無い親 ${want.length - ok.length} 件は無視しました`);
    window.Gantt?.render(); window.GFooter?.refresh(); window.Compare?.render?.(); presetState();
    return want.length - ok.length;  // 外した件数
  };
  const setTree = keys => applyTree(keys, true);
  const toggleTree = k => setTree(F.tree.includes(k) ? F.tree.filter(x => x !== k) : [...F.tree, k]);
  const treeLevel = d => setTree([...treeNodes(openTasks())].filter(([, dd]) => d === "all" || dd === d).map(([k]) => k));  // d 段の親をすべて折りたたむ
  const initTree = st => { F.tree = (st.gantt_collapsed || "").split("\n").filter(Boolean); applyTree(F.tree, true); };
  /* 読み込み: プリセットにある部分だけ当てる (古いプリセットに無い部分はいまのまま) */
  const applyView = v => saveView({ grid_col_order: v.col_order ?? S.settings.grid_col_order, grid_frozen: v.frozen ?? S.settings.grid_frozen, grid_hidden: v.hidden ?? S.settings.grid_hidden });
  const applyGantt = g => {
    const setSel = (s, v) => v !== undefined && [...$(s).options].some(o => o.value === v) && ($(s).value = v);
    const setChk = (s, v) => typeof v === "boolean" && ($(s).checked = v);
    setSel("#g-zoom", g.zoom); setSel("#g-project", g.project); setSel("#gf-scope", g.chain);
    [["#g-usefilter", g.usefilter], ["#g-inazuma", g.inazuma], ["#g-deps", g.deps], ["#g-todayband", g.todayband], ["#g-effort", g.effort]].forEach(([s, v]) => setChk(s, v));
    const deps = $("#g-deps").checked ? "on" : "off";
    deps !== S.settings.gantt_deps && ((S.settings.gantt_deps = deps), post("/api/settings", { gantt_deps: deps }));
    window.Gantt?.G.reveal.clear(); window.Gantt?.render(); window.GFooter?.refresh(); window.Compare?.render?.();
  };
  const applyBars = b => {  // 画面の列定義 (メモリ) に当てる。columns.csv は「保存」したときだけ変わる
    const diff = (S.data.columns || []).some(c => b[c.key] && BAR_F.some(f => f in b[c.key] && barOf(c)[f] !== b[c.key][f]));
    diff && editKind("columns", rows => rows.filter(c => b[c.key]).forEach(c => BAR_F.filter(f => f in b[c.key]).forEach(f => (c[f] = b[c.key][f]))));
  };
  /* ---------- 初期状態に戻す (表示の条件だけ。presets.json・columns.csv は書かない。Ctrl+Z で 1 回で戻る) ---------- */
  const GANTT0 = { zoom: "28", project: "", usefilter: true, inazuma: true, deps: true, todayband: true, chain: "all", effort: false };
  const RESET_ITEMS = [  // [キー, 表示, 既定でチェック, 戻し方]
    ["filters", "絞り込み（フィルター）", true, () => (F.filters = {})],
    ["sort", "並べ替え（No. 順に）", true, () => setUserSort([])],
    ["order", "列の並び（列定義の順に）", true, v => (v.grid_col_order = "")],
    ["frozen", "列の固定（なし）", true, v => (v.grid_frozen = "0")],
    ["hidden", "非表示の列（すべて表示）", true, v => (v.grid_hidden = "")],
    ["tree", "ツリーの開閉（すべて展開）", true, () => applyTree([], true)],
    ["gantt", "ガント表示（週・表示期間 自動・各表示 オン・プロジェクト すべて）", false, () => null],
  ];
  const viewSnap = () => ({ ...structuredClone({ filters: F.filters, sort: F.sort, sortDefault: F.sortDefault, range: F.range }), view: viewState(), gantt: ganttState(), tree: [...F.tree], preset: F.preset });
  const restoreView = s => {
    F.filters = s.filters; F.sort = s.sort; F.sortDefault = s.sortDefault;
    applyRange(s.range); applyView(s.view); applyGantt(s.gantt); applyTree(s.tree, true);
    F.preset = s.preset; changed(); window.Gantt?.render(); presetState();
  };
  const resetView = keys => {
    closeReset();
    if (!keys.length) return;
    S.undo.push({ view: viewSnap() }); S.undo.splice(0, Math.max(0, S.undo.length - 50));
    const v = {};
    RESET_ITEMS.filter(([k]) => keys.includes(k)).forEach(([, , , fn]) => fn(v));
    Object.keys(v).length && saveView(v);
    keys.includes("gantt") && (applyRange(RANGE0), applyGantt(GANTT0));
    close(); changed(); window.Gantt?.render(); presetState();
    msg(`初期状態に戻しました: ${RESET_ITEMS.filter(([k]) => keys.includes(k)).map(([, t]) => t.replace(/（.*$/, "")).join("・")}（Ctrl+Z で取り消し）`);
  };
  let resetPop = null;
  const closeReset = () => { resetPop?.remove(); resetPop = null; };
  const openReset = btn => {
    if (resetPop) return closeReset();
    const box = ([k, t, on]) => el("label", { class: "rv-item" }, el("input", { type: "checkbox", name: k, checked: on ? "checked" : null }), " ", t);
    resetPop = el("div", { class: "fdrop reset-pop", role: "dialog", "aria-label": "初期状態に戻す" },
      el("div", { class: "fd-title", text: "初期状態に戻す" }),
      el("p", { class: "muted", text: "チェックした表示の条件を初期状態に戻します（全タブ共通）。データ・列定義・保存した条件は変わりません。Ctrl+Z で取り消せます。" }),
      ...RESET_ITEMS.map(box),
      el("div", { class: "fd-row fd-actions" },
        el("button", { type: "button", class: "primary", text: "初期状態に戻す", onclick: () => resetView($$("input:checked", resetPop).map(i => i.name)) }),
        el("button", { type: "button", text: "キャンセル", onclick: closeReset })));
    document.body.append(resetPop);
    const r = btn.getBoundingClientRect();
    Object.assign(resetPop.style, { left: `${clamp(r.left, 8, innerWidth - resetPop.offsetWidth - 8)}px`, top: `${r.bottom + 2}px` });
  };
  document.addEventListener("pointerdown", e => resetPop && !resetPop.contains(e.target) && !e.target.closest(".btn-reset-view") && closeReset(), true);
  document.addEventListener("keydown", e => e.key === "Escape" && closeReset());
  /* ツールチップ用の中身の要約 */
  const describe = p => {
    if (!p) return "";
    const g = p.gantt, v = p.view, r = p.range, bars = Object.entries(p.bars || {}).filter(([, x]) => x.bar_pos && x.bar_pos !== "none");
    const lab = id => colBy(id)?.h || id, ZOOM = { 28: "週", 12: "月", 4: "年" }, onoff = x => (x ? "あり" : "なし");
    return [
      `フィルター: ${Object.keys(p.filters || {}).map(lab).join("、") || "なし"}`,
      `並べ替え: ${(p.sort || []).map(s => `${lab(s.id)}${s.dir > 0 ? "▲" : "▼"}`).join("、") || "No. 順"}`,
      r && `表示期間: ${r.mode === "fixed" ? `固定 ${fmtDate(r.from)}〜${fmtDate(r.to)}` : r.mode === "all" ? "全タスク" : "自動（検索条件）"}`,
      v && `表: 列の並び${v.col_order ? "変更あり" : "既定"}・固定 ${v.frozen || 0} 列・隠した列 ${v.hidden ? v.hidden.split(",").map(lab).join("、") : "なし"}`,
      g && `ガント: ${ZOOM[g.zoom] || g.zoom}表示・プロジェクト ${g.project ? S.data.projects.find(x => x.code === g.project)?.name || g.project : "すべて"}・表の条件で絞り込み ${onoff(g.usefilter)}・イナズマ線 ${onoff(g.inazuma)}・影響線 ${onoff(g.deps)}・今日の帯 ${onoff(g.todayband)}・影響タスク欄 ${g.chain === "direct" ? "直接のみ" : "すべての連鎖"}${typeof g.effort === "boolean" ? `・工数・金額 ${onoff(g.effort)}` : ""}`,
      p.bars && `バー表示: ${bars.map(([k, x]) => `${lab(k)}=${Gantt.BAR_POS_JA[x.bar_pos] || x.bar_pos}`).join("、") || "なし"}`,
      Array.isArray(p.tree) && `ツリー: ${p.tree.length ? `折りたたみ ${p.tree.length} か所（${p.tree.map(k => k.split(TREE_SEP).at(-1)).slice(0, 5).join("、")}${p.tree.length > 5 ? "…" : ""}）` : "すべて展開"}`,
      !p.view && "（古い形式: フィルター・並べ替えだけ。ほかはいまの表示のまま）",
    ].filter(Boolean).join("\n");
  };
  const modified = () => !!F.preset && JSON.stringify(state()) !== F.preset.base;

  /* ---------- 見出し ---------- */
  const th = (c, j) => {
    const id = colId(c), si = F.sort.findIndex(s => s.id === id), s = F.sort[si];
    return el("th", { "data-j": j, "data-col": id, class: ["fth", F.filters[id] && "filtered", s && "sorted", s && F.sortDefault && "sort-default"].filter(Boolean).join(" "),
      title: s ? `並べ替え ${F.sortDefault ? "（既定）" : `レベル ${si + 1}`}: クリックで昇順⇔降順（レベルはそのまま）` : "クリックで並べ替えの最後のレベルに追加（昇順）" },
      el("span", { class: "th-l", text: c.h }),
      s && el("span", { class: "th-s", title: F.sortDefault ? "既定の並び（No. 昇順）" : `レベル ${si + 1}`, text: (s.dir > 0 ? "▲" : "▼") + (F.sortDefault ? "" : si + 1) }),
      el("button", { class: `fbtn${F.filters[id] ? " on" : ""}`, "data-fcol": id, title: "並べ替え・フィルター", text: "▾" }));
  };
  /* 見出しクリック (Shift の有無は同じ): ある列 → その位置で向きを反転、無い列 → 最後に追加。既定だけなら置き換え */
  const toggleSort = id => {
    const cur = F.sort.find(s => s.id === id);
    setUserSort(cur ? F.sort.map(s => (s.id === id ? { id, dir: -s.dir } : s)) : F.sortDefault ? [{ id, dir: 1 }] : [...F.sort, { id, dir: 1 }]);
    changed();
  };
  /* ▾ メニュー: 昇順・降順はその列の向きを決める (無ければ追加・既定だけなら置き換え)。0 はこの列だけ外す */
  const setSort = (id, dir) => {
    const has = F.sort.some(s => s.id === id), base = F.sortDefault ? [] : F.sort;
    setUserSort(!dir ? base.filter(s => s.id !== id) : has && !F.sortDefault ? F.sort.map(s => (s.id === id ? { id, dir } : s)) : [...base.filter(s => s.id !== id), { id, dir }]);
  };
  /* 表示期間 (ガントの横軸): 共通条件。設定に残し、プリセットにも入る */
  const RANGE0 = { mode: "auto", from: "", to: "" };
  const applyRange = r => {
    F.range = { ...RANGE0, ...r };
    const s = { gantt_span: F.range.mode, gantt_span_from: F.range.from, gantt_span_to: F.range.to };
    Object.assign(S.settings, s); post("/api/settings", s);
    window.SpanCtl?.sync(); window.Gantt?.render(); window.Compare?.render?.();
  };
  const setRange = r => { applyRange(r); presetState(); };
  const initRange = st => { F.range = { mode: st.gantt_span || "auto", from: st.gantt_span_from || "", to: st.gantt_span_to || "" }; window.SpanCtl?.sync(); };
  const clearAll = () => { F.filters = {}; setUserSort([]); close(); changed(); };  // 解除すると No. 順に戻る
  const clearFilters = () => { F.filters = {}; close(); changed(); };  // 絞り込みだけ外す (並べ替えはそのまま)
  const clearSort = () => { setUserSort([]); close(); changed(); };  // 並べ替えだけ外す (No. 順。フィルターはそのまま)
  const pin = r => active() && F.pinned.add(r);

  /* ---------- チップ (適用中の条件。× で外す・クリックで編集) ---------- */
  const fmtV = (c, v) => (kindOf(c) === "date" ? fmtDate(v) : v);
  const condText = (c, x) => (noValue(x.op) ? opLabel(c, x.op) : kindOf(c) === "num" || kindOf(c) === "date" ? `${opLabel(c, x.op)} ${fmtV(c, x.v)}` : `「${x.v}」${opLabel(c, x.op)}`);
  const chipsOf = (id, f) => {
    const c = colBy(id);
    if (!c) return [];
    const vals = f.vals && [{ text: `${c.h}: ${f.vals.slice(0, 3).map(v => nameOf(c, v)).join(", ")}${f.vals.length > 3 ? ` 他${f.vals.length - 3}件` : ""}${f.vals.length ? "" : "（なし）"}`,
      drop: g => ({ ...g, vals: null }) }];
    const conds = !f.conds?.length ? [] : f.join === "or"
      ? [{ text: `${c.h}: ${f.conds.map(x => condText(c, x)).join(" または ")}`, drop: g => ({ ...g, conds: [] }) }]
      : f.conds.map((x, k) => ({ text: `${c.h} ${condText(c, x)}`, drop: g => ({ ...g, conds: g.conds.filter((_, n) => n !== k) }) }));
    return [...(vals || []), ...conds].map(ch => ({ ...ch, id }));
  };
  const removeChip = ch => {
    const g = ch.drop(F.filters[ch.id]);
    (g.vals || g.conds?.length) ? (F.filters[ch.id] = g) : delete F.filters[ch.id];
    changed();
  };
  const renderChips = () => {
    const sortChip = F.sort.length && !isDefaultSort() && el("span", { class: "chip sort" },
      el("button", { class: "chip-t", text: `並べ替え: ${F.sort.filter(s => colBy(s.id)).map((s, k) => `${k + 1}.${colBy(s.id).h}${s.dir > 0 ? "▲" : "▼"}`).join(" → ")}`, onclick: openSortDialog }),
      el("button", { class: "chip-x", title: "並べ替えを解除（No. 順に戻す）", text: "×", onclick: () => { setUserSort([]); changed(); } }));
    const chips = Object.entries(F.filters).flatMap(([id, f]) => chipsOf(id, f)).map(ch => el("span", { class: "chip", "data-col": ch.id },
      el("button", { class: "chip-t", text: ch.text, title: "クリックで条件を編集", onclick: () => open(ch.id, $(`#grid-tasks th[data-col="${CSS.escape(ch.id)}"] .fbtn`)) }),
      el("button", { class: "chip-x", title: "この条件を外す", text: "×", onclick: () => removeChip(ch) })));
    $("#filter-chips").replaceChildren(...[sortChip, ...chips].filter(Boolean));
    $("#filter-chips").hidden = !sortChip && !chips.length;
    presetState();
  };

  /* ---------- ドロップダウン (列ごと) ---------- */
  const valueList = c => {
    const base = S.data.tasks.filter(r => passes(r, colId(c)));  // ほかの列の条件で絞った行から候補を作る
    const counts = base.map(r => valOf(r, c)).reduce((m, v) => m.set(v, (m.get(v) || 0) + 1), new Map());
    const order = c.o ? c.o().map(([v]) => v) : [];
    const rank = v => (order.indexOf(v) + 1 || 1e9);
    return [...counts.entries()].sort(([a], [b]) => (!a) - (!b) || rank(a) - rank(b) || a.localeCompare(b, "ja"));
  };
  const listUI = (c, f) => {
    const box = el("div", { class: "fd-list" }, ...valueList(c).map(([v, n]) => el("label", { class: "fd-item", "data-label": labelOf(c, v).toLowerCase() },
      el("input", { type: "checkbox", value: v, checked: !f?.vals || f.vals.includes(v) ? "checked" : null }), ` ${labelOf(c, v)} `, el("span", { class: "muted", text: `(${n})` }))));
    const search = el("input", { type: "search", class: "fd-search", placeholder: "一覧から探す" });
    search.addEventListener("input", () => $$(".fd-item", box).forEach(l => (l.hidden = !l.dataset.label.includes(search.value.trim().toLowerCase()))));
    const setAll = on => () => $$(".fd-item:not([hidden]) input", box).forEach(i => (i.checked = on));
    return [el("div", { class: "fd-sub", text: "値の一覧" }), search,
      el("div", { class: "fd-row" }, el("button", { type: "button", text: "全選択", onclick: setAll(true) }), el("button", { type: "button", text: "解除", onclick: setAll(false) })), box];
  };
  const condRow = (c, x = {}) => {
    const ops = opsOf(c), op = x.op || ops[0][0];
    const inp = el("input", { class: "fd-v", value: fmtV(c, x.v ?? ""), placeholder: kindOf(c) === "date" ? "yyyy/mm/dd" : kindOf(c) === "num" ? "数値" : "文字",
      inputmode: kindOf(c) === "num" ? "decimal" : null, hidden: noValue(op) ? "hidden" : null });
    const sel = el("select", { class: "fd-op", onchange: () => (inp.hidden = noValue(sel.value)) }, ...ops.map(([v, t]) => el("option", { value: v, text: t, selected: v === op ? "selected" : null })));
    const row = el("div", { class: "fd-cond" }, sel, inp, el("button", { type: "button", class: "fd-del", title: "この条件を消す", text: "×", onclick: () => row.remove() }));
    return row;
  };
  const condUI = (c, f) => {
    const list = el("div", { class: "fd-conds" }, ...(f?.conds?.length ? f.conds : [{}]).map(x => condRow(c, x)));
    const join = f?.join || "and";
    const quick = c.k === "progress" && el("div", { class: "fd-row" }, el("span", { class: "muted", text: "クイック:" }),
      ...[["完了(100)", [{ op: "eq", v: "100" }]], ["未完了", [{ op: "lt", v: "100" }]], ["50%未満か空欄", [{ op: "lt", v: "50" }, { op: "blank", v: "" }]]].map(([t, conds]) =>
        el("button", { type: "button", text: t, onclick: () => { list.replaceChildren(...conds.map(x => condRow(c, x))); $$("[name=join]", F.drop).forEach(i => (i.checked = i.value === (conds.length > 1 ? "or" : "and"))); } })));
    return [el("div", { class: "fd-sub", text: "条件" }),
      el("div", { class: "fd-row" }, ...[["and", "すべて満たす (AND)"], ["or", "いずれか (OR)"]].map(([v, t]) =>
        el("label", {}, el("input", { type: "radio", name: "join", value: v, checked: join === v ? "checked" : null }), ` ${t}`))),
      list, el("div", { class: "fd-row" }, el("button", { type: "button", text: "＋ 条件を追加", onclick: () => list.append(condRow(c)) })), quick];
  };
  const readConds = (c, d) => $$(".fd-cond", d).map(row => {
    const op = $(".fd-op", row).value, raw = $(".fd-v", row).value.trim();
    const v = noValue(op) ? "" : kindOf(c) === "date" ? normDate(raw) : raw;
    if (!noValue(op) && v && kindOf(c) === "date" && dn(v) === null) throw new Error(`日付が読めません: ${raw}（yyyy/mm/dd）`);
    if (!noValue(op) && v && kindOf(c) === "num" && isNaN(+v)) throw new Error(`数値ではありません: ${raw}`);
    return { op, v };
  }).filter(x => noValue(x.op) || x.v !== "");
  const readFilter = (c, d) => {
    const boxes = $$(".fd-item input", d), on = boxes.filter(i => i.checked).map(i => i.value);
    const vals = boxes.length && on.length < boxes.length ? on : null, conds = readConds(c, d);
    return vals || conds.length ? { vals, conds, join: $("[name=join]:checked", d)?.value || "and" } : null;
  };
  const place = (d, btn) => {
    const r = btn.getBoundingClientRect(), w = d.offsetWidth, h = d.offsetHeight;
    const below = innerHeight - r.bottom - 8, above = r.top - 8, up = h > below && above > below;
    Object.assign(d.style, { left: `${clamp(r.left, 8, innerWidth - w - 8)}px`, top: `${up ? Math.max(8, r.top - Math.min(h, above) - 2) : r.bottom + 2}px`,
      maxHeight: `${Math.max(160, up ? above : below)}px` });
  };
  const close = () => { F.drop?.remove(); F.drop = null; };
  const open = (id, btn) => {
    const reopen = F.drop?.dataset.col === id;
    close();
    if (reopen || !btn) return;
    const c = colBy(id), f = F.filters[id];
    const ok = () => {
      try {
        const nf = readFilter(c, d);
        nf ? (F.filters[id] = nf) : delete F.filters[id];
        close(); changed();
      } catch (err) { msg(err.message, false); }
    };
    const sortBtn = (dir, text) => el("button", { type: "button", class: F.sort.some(s => s.id === id && s.dir === dir) ? "on" : "", text,
      onclick: () => { setSort(id, dir); close(); changed(); } });
    const d = el("div", { class: "fdrop", "data-col": id, role: "dialog" },
      el("div", { class: "fd-title", text: c.h }),
      el("div", { class: "fd-row" }, sortBtn(1, "▲ 昇順"), sortBtn(-1, "▼ 降順"), sortBtn(0, "並べ替え解除（この列）"),
        el("button", { type: "button", text: "並べ替え条件…", onclick: () => { close(); openSortDialog(); } })),
      el("div", { class: "fd-row" }, el("span", { class: "muted", text: "列:" }),
        el("button", { type: "button", text: "ここまで固定", onclick: () => { close(); freezeTo(id); } }),
        el("button", { type: "button", text: "固定解除", disabled: frozenN() ? null : "disabled", onclick: () => { close(); unfreeze(); } }),
        el("button", { type: "button", text: "並びを元に戻す", disabled: viewOrder().length ? null : "disabled", onclick: () => { close(); resetColumns(); } }),
        el("button", { type: "button", text: "この列を隠す", title: "表示だけ（CSV は変わりません）", onclick: () => { close(); hideColumn(id); } })),
      el("hr"), ...condUI(c, f).filter(Boolean),
      ...(["list", "text"].includes(kindOf(c)) ? [el("hr"), ...listUI(c, f)] : []),
      el("div", { class: "fd-row fd-actions" },
        el("button", { type: "button", class: "primary", text: "OK", onclick: ok }),
        el("button", { type: "button", text: "この列のフィルター解除", onclick: () => { delete F.filters[id]; close(); changed(); } }),
        el("button", { type: "button", text: "閉じる", onclick: close })));
    d.addEventListener("keydown", e => e.key === "Enter" && e.target.tagName === "INPUT" && !["checkbox", "radio"].includes(e.target.type) && ok());
    F.drop = d;
    document.body.append(d);
    place(d, btn);
    $(".fd-v:not([hidden])", d)?.focus();
  };

  /* ---------- 並べ替え条件ダイアログ ---------- */
  const openSortDialog = () => {
    close();
    let draft = F.sortDefault ? [] : F.sort.filter(s => colBy(s.id)).map(s => ({ ...s }));
    const sortable = cols();
    const levelRow = (s, k) => el("tr", {},
      el("td", { class: "muted", text: k === 0 ? "最優先" : `次に ${k + 1}` }),
      el("td", {}, el("select", { "data-k": "id", onchange: e => (draft[k].id = e.target.value) },
        ...sortable.map(c => el("option", { value: colId(c), text: c.h, selected: colId(c) === s.id ? "selected" : null })))),
      el("td", {}, el("select", { "data-k": "dir", onchange: e => (draft[k].dir = +e.target.value) },
        el("option", { value: 1, text: "昇順 ▲", selected: s.dir > 0 ? "selected" : null }), el("option", { value: -1, text: "降順 ▼", selected: s.dir < 0 ? "selected" : null }))),
      el("td", {}, el("button", { type: "button", title: "上へ", text: "↑", disabled: k === 0 ? "disabled" : null, onclick: () => move(k, -1) }),
        el("button", { type: "button", title: "下へ", text: "↓", disabled: k === draft.length - 1 ? "disabled" : null, onclick: () => move(k, 1) }),
        el("button", { type: "button", title: "このレベルを削除", text: "削除", onclick: () => { draft.splice(k, 1); paint(); } })));
    const move = (k, dk) => { draft.splice(k + dk, 0, ...draft.splice(k, 1)); paint(); };
    const body = el("tbody");
    const paint = () => body.replaceChildren(...(draft.length ? draft.map(levelRow) : [el("tr", {}, el("td", { colspan: 4, class: "muted", text: "指定なし（既定: No. の昇順）" }))]));
    const unused = () => sortable.map(colId).find(id => !draft.some(s => s.id === id)) ?? colId(sortable[0]);
    const done = () => {
      const seen = new Set();
      setUserSort(draft.filter(s => !seen.has(s.id) && seen.add(s.id)));  // 同じ列は最初のレベルだけ
      shut(); changed();
    };
    const shut = () => { ov.remove(); document.removeEventListener("keydown", esc, true); };
    const esc = e => e.key === "Escape" && (e.stopPropagation(), shut());
    const ov = el("div", { class: "modal-ov", onpointerdown: e => e.target === ov && shut() },
      el("div", { class: "modal", role: "dialog", "aria-label": "並べ替え条件" },
        el("div", { class: "fd-title", text: "並べ替え条件" }),
        el("p", { class: "muted", text: "上のレベルから順に比べます。見出しのクリックとも連動します（無い列は最後のレベルに追加、ある列は昇順⇔降順）。" }),
        el("table", { class: "list sort-levels" }, el("thead", {}, el("tr", {}, ...["", "列", "順序", ""].map(t => el("th", { text: t })))), body),
        el("div", { class: "fd-row" }, el("button", { type: "button", text: "＋ レベルを追加", onclick: () => { draft.push({ id: unused(), dir: 1 }); paint(); } }),
          el("button", { type: "button", text: "すべて削除", onclick: () => { draft = []; paint(); } })),
        el("div", { class: "fd-row fd-actions" }, el("button", { type: "button", class: "primary", text: "OK", onclick: done }),
          el("button", { type: "button", text: "キャンセル", onclick: shut }))));
    paint();
    document.body.append(ov);
    document.addEventListener("keydown", esc, true);
  };

  /* ---------- 条件の保存 (名前を付けて presets.json に残す) ---------- */
  /* 呼び出し中のプリセットの表示: 名前（変更あり）・上書き保存は変更があるときだけ */
  const presetState = () => {
    const sel = $("#preset-sel"), name = F.preset?.name, mod = modified();
    $$("option", sel).forEach(o => (o.textContent = o.value && o.value === name && mod ? `${o.value}（変更あり）` : o.value || "保存した条件…"));
    sel.value = name && S.presets[name] ? name : "";
    sel.classList.toggle("modified", mod);
    $$("option", sel).forEach(o => (o.title = o.value ? describe(S.presets[o.value]) : ""));
    sel.title = name ? `「${name}」の中身:\n${describe(S.presets[name])}${mod ? "\n\n（いまの表示はここから変更あり）" : ""}` : "保存した並べ替え・フィルター・表示の条件を呼び出す";
    $("#btn-preset-over").disabled = !mod;
    $("#btn-preset-del").disabled = !name;
  };
  const fillPresets = () => {
    $("#preset-sel").replaceChildren(el("option", { value: "", text: "保存した条件…" }), ...Object.keys(S.presets).map(n => el("option", { value: n, text: n })));
    F.preset = F.preset && S.presets[F.preset.name] ? F.preset : null;
    presetState();
  };
  const writePreset = async (name, verb) => {  // presets.json に書くのはここだけ (上書き保存・別名で保存)
    const snap = state();
    const r = await post("/api/presets", { name, preset: structuredClone(snap) });
    if (!r.ok) return msg(r.msg, false);
    S.presets = r.presets; F.preset = { name, base: JSON.stringify(snap) }; fillPresets();
    msg(`条件「${name}」を${verb}しました`);
  };
  const saveAs = async () => {
    // 表示の設定 (列・ガント・バー表示) も入るので、フィルターが無くても保存できる
    const name = prompt("新しい名前でこの並べ替え・フィルター条件を保存", F.preset ? `${F.preset.name} のコピー` : "")?.trim();
    if (!name) return;
    if (S.presets[name] && !confirm(`「${name}」は既にあります。上書きしますか？`)) return;
    writePreset(name, "保存");
  };
  const overwrite = () => F.preset && modified() && confirm(`保存した条件「${F.preset.name}」をいまの条件で上書きしますか？`) && writePreset(F.preset.name, "上書き保存");
  const loadPreset = name => {
    const p = S.presets[name];
    if (!name) return (F.preset = null, presetState());  // 「保存した条件…」: 作業中の条件はそのまま、プリセットとの関係だけ外す
    if (!p) return;
    if (modified() && !confirm(`「${F.preset.name}」の変更は保存されていません。破棄して「${name}」を呼び出しますか？`)) return presetState();
    const copy = structuredClone(p);  // 写しを作業中の条件にする (プリセット自体は変えない)
    F.filters = Object.fromEntries(Object.entries(copy.filters || {}).filter(([id]) => colBy(id)));
    setUserSort((copy.sort || []).filter(s => colBy(s.id)));
    copy.range && applyRange(copy.range);  // 無い部分 (古いプリセット) はいまのまま
    copy.view && applyView(copy.view);
    copy.gantt && applyGantt(copy.gantt);
    copy.bars && applyBars(copy.bars);
    const dropped = Array.isArray(copy.tree) ? applyTree(copy.tree, true) : 0;  // 無くなった親は外して当てる (その状態がこのプリセットの基準)
    F.preset = { name, base: JSON.stringify(state()) };
    changed(); msg(`条件「${name}」を呼び出しました（変更しても保存するまでプリセットは変わりません）${dropped ? `。ツリーの開閉: いまのデータに無い親 ${dropped} 件は無視しました` : ""}`);
  };
  const deletePreset = async () => {
    const name = F.preset?.name;
    if (!name || !confirm(`保存した条件「${name}」を削除しますか？`)) return;
    const r = await post("/api/presets", { name, preset: null });
    if (r.ok) { S.presets = r.presets; F.preset = null; fillPresets(); msg(`条件「${name}」を削除しました（作業中の条件はそのまま）`); }
  };

  document.addEventListener("pointerdown", e => F.drop && !F.drop.contains(e.target) && !e.target.closest?.(".fbtn, .chip-t") && close(), true);
  document.addEventListener("keydown", e => e.key === "Escape" && F.drop && close());
  addEventListener("resize", close);
  document.addEventListener("DOMContentLoaded", () => {
    $("#btn-sort-dialog").addEventListener("click", openSortDialog);
    $("#btn-preset-save").addEventListener("click", saveAs);
    $("#btn-preset-over").addEventListener("click", overwrite);
    $("#btn-preset-del").addEventListener("click", deletePreset);
    $("#preset-sel").addEventListener("change", e => loadPreset(e.target.value));
  });
  return { apply, passes: r => passes(r), active, th, toggleSort, setSort, open, close, clearAll, clearFilters, clearSort, resetView, restoreView, openReset, setTree, toggleTree, treeLevel, initTree, setRange, initRange, presetState, describe, state, pin, renderChips, fillPresets, openSortDialog, modified, F };
})();
