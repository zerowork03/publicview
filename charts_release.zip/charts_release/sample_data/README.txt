﻿試し用のデータです。data と master を、アプリのフォルダの data と master に上書きコピーしてから start.bat を実行します。
本番で使うときは、Access から書き出した CSV に置き換えてください（列定義 columns.csv とパラメータ params.csv はアプリ側のものを使います）。
